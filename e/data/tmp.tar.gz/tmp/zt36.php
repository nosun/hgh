<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>纪念毛主席逝世37周年- 红歌会网</title>
        <meta name="description" content="尽管毛主席已经离开我们三十七年，但他从未远去。他始终活在人民心中，活在那些剥削阶级的梦魇中。而且越来越被广大人民群众怀念。三十七年来，资产阶级极其走卒对他的各类泼污和诅咒，谩骂和攻击，丝毫无损于他在人民心中的光辉形象。而且，随着时间的推移，他的身影显的更回伟岸。
" />
        <meta name="keywords" content="" />
        <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
        <link href="http://www.szhgh.com/skin/default/css/topic.css" rel="stylesheet" type="text/css" />
        <script>
            function setTab(name,cursel,n){
                for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
                }
            }
            function change(id){
                if (typeof(isround)!='undefined') clearTimeout(isround);
                var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
                var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
                var text = document.getElementById("focus_text").getElementsByTagName("li");
                for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
                }
                bigimg[id-1].className="dis";
                smallimg[id-1].className="current";
                text[id-1].className="dis";
                if ((next=id+1) > smallimg.length) next = 1;
                isround=setTimeout('change('+next+')', 5000);
            }
        </script>

    </head>
    <body>

        <!--头部开始-->
        <div class="header">
            <div class="hea_1">
                <div class="hea_logo"><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.gif" width="72" height="53" /></a></div>
                <ul>
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页 </a>|</li>
                    <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;学者专栏 </a></li>
                </ul>
                <span>
                    <script>
                        document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                    </script>
                </span>
            </div>
        </div>
        <div class="hea_2">
            <p><img src="http://img3.wyzxwk.com/p/2013/09/cd2f7acb5b045897bf0b9bc519851c62.jpg" width="1000" height="200" /></p>
        </div>
        <div class="hea_3">
            <ul>
                <?
                $ztid=36;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
                $zt_r = $empire->fetch1("select ztpath from {$dbtbpre}enewszt where ztid=" . $ztid);
                $ztpath = $public_r['newsurl'].$zt_r['ztpath'];
                $sql = "select cid,cname,ttype from {$dbtbpre}enewszttype where ztid=$ztid order by myorder ASC";
                $result=$empire->query($sql);    //根据专题id从“专题子类主表”查询出“专题子类id”和“专题子类名称”；
                while($r=$empire->fetch($result)) {       //循环获取查询记录到数组$r,并循环输出子类信息列表
                $cid=$r['cid'];
                $zttypepath = $ztpath.'/type'.$r['cid'].$r['ttype']
                ?>
                <li><a href="<?=$zttypepath?>" target="_blank" title="<?=$r['cname']?>"><?=$r['cname']?></a></li>
                <?
                }
                ?>
            </ul>
        </div>

        <!--头部结束-->
        <!--中间开始-->
        <div class="cont">
            <div class="le_1">

                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 order by newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],52)?></a></h2>
                <div class="smalltext"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;<a href="<?=$bqsr['titleurl']?>" title="点击查看详情" target="_blank">[评细]</a></div>
                <?php
}
}
?>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>=1 and isgood<4 order by newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>					
                </ul>
            </div>
            <div class="ri_1">
                <div id=focus_pic class=right>
                    <div id=focus_big>
                        <ul>
                            <li class=dis><a href="http://mzd.szhgh.com/huainian/201309/30916.html" title="组图:9月9日毛主席纪念堂" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/f6da104bc9cb30340a524c4fb21f079e.jpg" /></a></li>
                            <li class=undis><a href="http://mzd.szhgh.com/huainian/201308/28729.html" title="文革时期的伟人毛泽东" arget=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/aafacdd1a70ceb9aada33023e312d978.jpg" /></a></li>
                            <li class=undis><a href="http://mzd.szhgh.com/maoshidai/23651.html" title="令人怀念的纯朴幸福笑容" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/273e51e42c634107722458464c23c23f.jpg" /></a></li>
                        </ul>
                        <div id=focus_text_bg></div>
                        <div id=focus_text>
                            <ul>
                                <li class=dis><a href="http://mzd.szhgh.com/huainian/201309/30916.html" target=_blank>组图:9月9日毛主席纪念堂</a></li>
                                <li class=undis><a href="http://mzd.szhgh.com/huainian/201308/28729.html" target=_blank>文革时期的伟人毛泽东</a></li>
                                <li class=undis><a href="http://mzd.szhgh.com/maoshidai/23651.html" target=_blank>令人怀念的纯朴幸福笑容</a></li>
                            </ul>
                        </div>
                    </div>
                    <div id=focus_tip>
                        <ul>
                            <li class=current onmouseover=change(1);><a href="http://mzd.szhgh.com/huainian/201309/30916.html" title="组图:9月9日毛主席纪念堂" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/86a791d3471522e92b6629e72c903516.jpg" /></a> </li>
                            <li class=current onmouseover=change(2);><a href="http://mzd.szhgh.com/huainian/201308/28729.html" title="文革时期的伟人毛泽东" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/ae617679628b21cbb13a36ee242fb3eb.jpg" /></a> </li>
                            <li class=current onmouseover=change(3);><a href="http://mzd.szhgh.com/maoshidai/23651.html" title="令人怀念的纯朴幸福笑容" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/4c327445393af7fdc6fc966b209cf96d.jpg" /></a></li>
                        </ul>
                    </div>
                    <script>
                        var isround = setTimeout("change(2)",2500);
                    </script>
                </div>
            </div>
        </div>

        <div class="cont">
            <div class="le_2">
                <h3 class="h3"><a>最新文章</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid order by newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>	
                </ul>
            </div>
            <div class="le_2">
                <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type7.html" title="纪念动态" target="_blank">纪念动态</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(7,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
            <div class="le_2 le_2a">
                <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type8.html" title="网友怀念" target="_blank">网友怀念</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(8,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/mzx37/type11.html" title="图片新闻" target="_blank">图片新闻</a></h2>
                <div class="cont_1a">
                    <!-- 图片列表 end -->
                    <div class="rollBox">
                        <div class="Cont" id="ISL_Cont">
                            <div class="ScrCont">
                                <div class="List1" id="List1">
                                    <!-- 图片列表 begin -->

                                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=11 and b.ispic=1 limit 8",8,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                    <div class="pic">
                                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],200,150,1,'')?>" width="200" height="150" /></a>
                                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],30)?></a>
                                    </div>                                    
                                    <?php
}
}
?>

                                    <!-- 图片列表 end -->
                                </div>
                                <div class="List2" id="List2"></div>
                            </div>
                        </div>
                        <!-- 图片列表 end -->
                    </div>
                </div>

                <script language="javascript" type="text/javascript">
                    <!--//--><![CDATA[/><!--
                    //图片滚动列表 mengjia 070816
                    var Speed = 1; //速度(毫秒)
                    var Space = 4; //每次移动(px)
                    var PageWidth = 240; //翻页宽度
                    var fill = 0; //整体移位
                    var MoveLock = false;
                    var MoveTimeObj;
                    var Comp = 0;
                    var AutoPlayObj = null;
                    GetObj("List2").innerHTML = GetObj("List1").innerHTML;
                    GetObj('ISL_Cont').scrollLeft = fill;
                    GetObj("ISL_Cont").onmouseover = function(){clearInterval(AutoPlayObj);}
                    GetObj("ISL_Cont").onmouseout = function(){AutoPlay();}
                    AutoPlay();
                    function GetObj(objName){if(document.getElementById){return eval('document.getElementById("'+objName+'")')}else{return eval('document.all.'+objName)}}
                    function AutoPlay(){ //自动滚动
                        clearInterval(AutoPlayObj);
                        AutoPlayObj = setInterval('ISL_GoDown();ISL_StopDown();',3000); //间隔时间
                    }
                    function ISL_GoUp(){ //上翻开始
                        if(MoveLock) return;
                        clearInterval(AutoPlayObj);
                        MoveLock = true;
                        MoveTimeObj = setInterval('ISL_ScrUp();',Speed);
                    }
                    function ISL_StopUp(){ //上翻停止
                        clearInterval(MoveTimeObj);
                        if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0){
                            Comp = fill - (GetObj('ISL_Cont').scrollLeft % PageWidth);
                            CompScr();
                        }else{
                            MoveLock = false;
                        }
                        AutoPlay();
                    }
                    function ISL_ScrUp(){ //上翻动作
                        if(GetObj('ISL_Cont').scrollLeft <= 0){GetObj('ISL_Cont').scrollLeft = GetObj('ISL_Cont').scrollLeft + GetObj('List1').offsetWidth}
                        GetObj('ISL_Cont').scrollLeft -= Space ;
                    }
                    function ISL_GoDown(){ //下翻
                        clearInterval(MoveTimeObj);
                        if(MoveLock) return;
                        clearInterval(AutoPlayObj);
                        MoveLock = true;
                        ISL_ScrDown();
                        MoveTimeObj = setInterval('ISL_ScrDown()',Speed);
                    }
                    function ISL_StopDown(){ //下翻停止
                        clearInterval(MoveTimeObj);
                        if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0 ){
                            Comp = PageWidth - GetObj('ISL_Cont').scrollLeft % PageWidth + fill;
                            CompScr();
                        }else{
                            MoveLock = false;
                        }
                        AutoPlay();
                    }
                    function ISL_ScrDown(){ //下翻动作
                        if(GetObj('ISL_Cont').scrollLeft >= GetObj('List1').scrollWidth){GetObj('ISL_Cont').scrollLeft = GetObj('ISL_Cont').scrollLeft - GetObj('List1').scrollWidth;}
                        GetObj('ISL_Cont').scrollLeft += Space ;
                    }
                    function CompScr(){
                        var num;
                        if(Comp == 0){MoveLock = false;return;}
                        if(Comp < 0){ //上翻
                            if(Comp < -Space){
                                Comp += Space;
                                num = Space;
                            }else{
                                num = -Comp;
                                Comp = 0;
                            }
                            GetObj('ISL_Cont').scrollLeft -= num;
                            setTimeout('CompScr()',Speed);
                        }else{ //下翻
                            if(Comp > Space){
                                Comp -= Space;
                                num = Space;
                            }else{
                                num = Comp;
                                Comp = 0;
                            }
                            GetObj('ISL_Cont').scrollLeft += num;
                            setTimeout('CompScr()',Speed);
                        }
                    }
                    //--><!]]>
                </script>

            </div>	
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/mzx37/type7.html" title="各地纪念毛主席活动" target="_blank">各地纪念毛主席活动</a></h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_3"><a href="http://mzd.szhgh.com/jinian/30971.html" title="人民大会堂今举行纪念毛主席活动 嘉宾阵容强大" target=_blank><img src="http://www.szhgh.com/s/mzx37/uploadfile/38ddf6b26b60baec76a51060d514b0b9.jpg" width="315" height="236" /></a></div>
                    <div class="le_3">
                        
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=7 and b.isgood=5 limit 0,2",2,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <h4 class="pad<?=$bqno?>"><a href="<?=$bqsr['titleurl']?>" target="_blank" title="<?=$bqr['title']?>"><?=$bqr['title']?></a></h4>
                        <span><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;[<a href="<?=$bqsr['titleurl']?>" title="点击查看详细内容" target="_blank">评细</a>]</span>                                 
                        <?php
}
}
?>

                    </div>
                    <div class="le_3 le_2a">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=7 and b.isgood=5 limit 2,2",2,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <h4 class="pad<?=$bqno?>"><a href="<?=$bqsr['titleurl']?>" target="_blank" title="<?=$bqr['title']?>"><?=$bqr['title']?></a></h4>
                        <span><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;[<a href="<?=$bqsr['titleurl']?>" title="点击查看详细内容" target="_blank">评细</a>]</span>                                 
                        <?php
}
}
?>		
                    </div>
                </div>
                <div class="cl"></div>
                <div class="ov">
                    <ul class="list fl">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=7 and b.isgood>0 and b.isgood<5 limit 0,3",3,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" target="_blank" title="<?=$bqr['title']?>"><?=esub($bqr['title'],42)?></a></li>
                        <?php
}
}
?>
                    </ul>
                    <ul class="list fl">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=7 and b.isgood>0 and b.isgood<5 limit 3,3",3,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" target="_blank" title="<?=$bqr['title']?>"><?=esub($bqr['title'],42)?></a></li>
                        <?php
}
}
?>
                    </ul>
                    <ul class="list fl">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=7 and b.isgood>0 and b.isgood<5 limit 6,3",3,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" target="_blank" title="<?=$bqr['title']?>"><?=esub($bqr['title'],42)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
            </div>	
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/mzx37/type12.html" title="视频报道" target="_blank">视频报道</a></h2>
                <div class="cont_1a">
                    <!-- 图片列表 end -->
                    <div class="rollBox">
                        <div class="Cont" id="ISL_Cont">
                            <div class="ScrCont">
                                <div class="List1">
                                    <!-- 图片列表 begin -->

                                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select * from {$dbtbpre}enewsztinfo a INNER JOIN {$dbtbpre}ecms_article b ON a.id=b.id where a.ztid=$ztid and a.cid=12 and b.ispic=1 limit 4",4,24,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                    <div class="pic">
                                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],200,150,1,'')?>" width="200" height="150" /></a>
                                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],30)?></a>
                                    </div>                                    
                                    <?php
}
}
?>

                                    <!-- 图片列表 end -->
                                </div>
                                <div class="List2"></div>
                            </div>
                        </div>
                        <!-- 图片列表 end -->
                    </div>
                </div>
            </div>	
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/mzx37/type9.html" title="真实的毛泽东时代" target="_blank">真实的毛泽东时代</a></h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <a href="http://mzd.szhgh.com/maoshidai/22139.html" title="珍贵组图：文革时儿童真实生活写照" target="_blank"><img src="http://www.szhgh.com/s/mzx37/uploadfile/f55f7ef6f30ea91ea219d5a85e3eed1e.jpg" width="200" height="150" /></a>
                        <h4><a href="http://www.szhgh.com/Article/wsds/history/201308/29858.html" target="_blank" title="党报:“饿死三千万”不是事实">党报:“饿死三千万”不是事实</a></h4>
                        <span>造成1960—1964年间我国户籍统计人口(不考虑自然增长)减少了3394万(其中1162万重报虚报户籍人口被注销、750万死亡漏报人口被注销、1482万漏报户籍人口)。这是我国这一期间户籍统计人口数大量减少的真正原因。[<a href="http://www.szhgh.com/Article/wsds/history/201308/29858.html" target="_blank">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://mzd.szhgh.com/maoshidai/201308/28166.html" target="_blank" title="视频]解密关于毛时代“饿死三千万人口”的历史谎言">视频]解密关于毛时代“饿死三千万人口”的历史谎言</a></li>
                            <li><a href="http://www.szhgh.com/article/reading/201308/28237.html" target="_blank" title="国内首部系统批驳“饿死三千万”谣言的专著出版 乌有之乡书店首发">国内首部系统批驳“饿死三千万”谣言的专著出版 乌有之乡书店首发</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/4040.html" target="_blank" title="震撼：邓小平在毛主席手里接过的是怎样的中国？">震撼：邓小平在毛主席手里接过的是怎样的中国？</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/10967.html" target="_blank" title="“崩溃边缘”的毛时代：造的桥地震震不塌 炸药炸不毁 万吨轮撞不垮">“崩溃边缘”的毛时代：造的桥地震震不塌 炸药炸不毁 万吨轮撞不垮</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/13787.html" target="_blank" title="古稀老人：告知后人真实毛时代 撒手西去也心安">古稀老人：告知后人真实毛时代 撒手西去也心安</a></li>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <a href="http://mzd.szhgh.com/maoshidai/23651.html" title="珍贵组图：毛泽东时代的群众-令人怀念的纯朴幸福笑容" target="_blank"><img src="http://www.szhgh.com/s/mzx37/uploadfile/9d4329615a3dbc9964eb443ecda87cd0.jpg" width="200" height="150" /></a>
                        <h4><a href="http://mzd.szhgh.com/maoshidai/21629.html" target="_blank" title="戴旭：中国人一定要知道的真相!">戴旭：中国人一定要知道的真相!</a></h4>
                        <span>我一般讲毛泽东跟别的领导人不一样，他老想改革自己一手创立的制度，1949年之后他有三次大的社会实践，第一次是“百花齐放”，第二次是“大跃进”，第三次是“文革”。“百花齐放”是他的一个试验，他已经意识到中国新建立的…[<a href="http://mzd.szhgh.com/maoshidai/21629.html">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://mzd.szhgh.com/pingshu/22760.html" target="_blank" title="陈云女儿辟谣：谁将李锐反毛言论栽赃给陈云？">陈云女儿辟谣：谁将李锐反毛言论栽赃给陈云？</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/22139.html" target="_blank" title="珍贵组图：文革时儿童真实生活写照">珍贵组图：文革时儿童真实生活写照</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/10067.html" target="_blank" title="组图：毛泽东时代美女都啥样 表情质朴肤色健康">组图：毛泽东时代美女都啥样 表情质朴肤色健康</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/10214.html" target="_blank" title="山东农民：毛泽东时代真得很穷吗?">山东农民：毛泽东时代真得很穷吗?</a></li>
                            <li><a href="http://mzd.szhgh.com/maoshidai/17690.html" target="_blank" title="【看图说话】看！毛泽东时代“崩溃”的经济">【看图说话】看！毛泽东时代“崩溃”的经济</a></li>
                        </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>		
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2>文章汇总</h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type7.html" title="" target="_blank">纪念动态</a><a href="http://www.szhgh.com/s/mzx37/type7.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list  mar_b">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(7,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type8.html" title="" target="_blank">网友怀念</a><a  href="http://www.szhgh.com/s/mzx37/type8.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list mar_b">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(8,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type9.html" title="" target="_blank">真实毛时代</a><a href="http://www.szhgh.com/s/mzx37/type9.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(9,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/mzx37/type10.html" title="" target="_blank">主席著作</a><a href="http://www.szhgh.com/s/mzx37/type10.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(10,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>
        </div>

        <div class="cont_pl">
            <h2>网友评论</h2>
            <div>
                <div class="pl section">
                    <!-- UY BEGIN -->
                    <div id="uyan_frame"></div>
                    <script type="text/javascript" src="http://v2.uyan.cc/code/uyan.js?uid=1686612"></script>
                    <!-- UY END -->
                </div>
            </div>
        </div>
        <!--中间结束-->
        <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1737191719</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>|<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
        <!--底部结束-->
<script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=36></script>
    </body>
</html>