<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
$author=$_GET['author'];
?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo $author;?>- 学者专栏 - <?=$public_r['sitename']?></title>
        <meta name="keywords" content="[!--pagekey--]" />
        <meta name="description" content="[!--pagedes--]" />
        <link href="[!--news.url--]skin/default/css/base.css" rel="stylesheet" type="text/css" />
        <link href="[!--news.url--]skin/default/css/special.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="[!--news.url--]skin/default/js/jquery-1.8.2.min.js"></script>
</head>
<body class="xz_aritcle" onload="iframe_height()">
    
    <!--iframe-->
    <div id="bodyheight">
        <div class="zt_article_list">
         <a name="aalist"  id="aalist"></a>
        [!--empirenews.listtemp--]
            <!--list.var1-->
        [!--empirenews.listtemp--]
        </div>
        <center class="page">文章总数：[!--show.page--]</center>          
    </div>
    <!--iframe-->
    <script type="text/javascript">
        function iframe_height(height) {
            if (!height) {
                var height = document.getElementById('bodyheight').scrollHeight+50;
            }
            top.document.getElementById('article_left').style.height=height+'px';
        }
    </script>

<script type="text/javascript">
$(document).ready(function() {
$(".page a").each(function(){
	if ($(this).attr("href")!=''){
		$(this).attr("href",$(this).attr("href")+"#aalist");
	 }
});
})
</script>
</body>
</html>