<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wb="http://open.weibo.com/wb">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>[!--pagetitle--] - 唱响红歌，弘扬正气！</title>
        <meta name="keywords" content="[!--pagekey--]" />
        <meta name="description" content="[!--pagedes--]" />
        <link rel="shortcut icon" href="[!--news.url--]skin/default/images/favicon.ico" /> 
        <link href="[!--news.url--]skin/default/css/anniversaries_1.css" media="all" rel="stylesheet" type="text/css" />
        <script src="[!--news.url--]skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
        <script src="[!--news.url--]skin/default/js/myfocus-2.0.4.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="[!--news.url--]skin/default/js/mF_tbhuabao.js"></script>
    </head>
    <body>
        
        <!-- header -->      
        <div class="header">
            <div class="nav">
                <div class="navigation clearfix">
                    <ul class="left">
                        <li><a href="[!--news.url--]">首页</a></li>
                        <li><a target="_blank" title="点此进入排行榜" href="http://www.szhgh.com/html/rank.html" class="first">排行榜</a></li>
                        <li><a target="_blank" title="点此进入专题中心" href="http://www.szhgh.com/special">专题中心</a></li>
                        <li><a target="_blank" title="点此进入学者专栏" href="http://www.szhgh.com/columnist/">学者专栏</a></li>                    
                        <li><a target="_blank" title="资讯中心" href="http://www.szhgh.com/Article/news/">资讯中心</a></li>
                        <li><a target="_blank" title="纵论天下" href="http://www.szhgh.com/Article/opinion/">纵论天下</a></li>
                        <li><a target="_blank" title="红色中国" href="http://www.szhgh.com/Article/red-china/">红色中国</a></li>
                        <li><a target="_blank" title="唱读讲传" href="http://www.szhgh.com/Article/cdjc/">唱读讲传</a></li>
                        <li><a target="_blank" title="人民健康" href="http://www.szhgh.com/Article/health/">人民健康</a></li>
                        <li><a target="_blank" title="工农之声" href="http://www.szhgh.com/Article/gnzs/">工农之声</a></li>
                        <li><a target="_blank" title="文史·读书" href="http://www.szhgh.com/Article/wsds/">文史读书</a></li>
                        <li><a target="_blank" title="第三世界" href="http://www.szhgh.com/Article/thirdworld/">第三世界</a></li>
                    </ul>
                    <div class="account right">
                        <script>
                            document.write('<script src="[!--news.url--]e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                        </script>
                    </div>                    
                </div>

            </div>
            <div class="banner"></div>
            
            <div class="wrap">
                <div class="position_cur">
                    <strong>当前位置：[!--newsnav--]</strong>
                </div>
            </div>
            
            <div class="columns">
                <script type="text/javascript">
                    myFocus.set({
                        id:'myFocus',//焦点图盒子ID
                        pattern:'mF_tbhuabao',//风格应用的名称
                        time:3,//切换时间间隔(秒)
                        trigger:'click',//触发切换模式:'click'(点击)/'mouseover'(悬停)
                        width:333,//设置图片区域宽度(像素)
                        height:249,//设置图片区域高度(像素)
                        txtHeight:'default'//文字层高度设置(像素),'default'为默认高度，0为隐藏
                    });
                </script>
                <div id="myFocus" class="scroll">
                    <div class="loading"></div><!--载入画面(可删除)-->
                    <div class="pic"><!--图片列表-->
                        <ul class="scroll_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(58,5,0,1,'isgood>0','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li>
                                <a href="<?=$bqsr['titleurl']?>"><img src="<?=sys_ResizeImg($bqr[titlepic],384,270,1,'')?>" alt="<?=esub($bqr['title'],40)?>" /></a>
                            </li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                </div>
                <div class="news">
                    <div class="head"><strong>最新推荐</strong></div>
                    <ul class="news_list">

                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(58,1,0,0,'firsttitle>0','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li class="topic_firstitle"><h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></h2></li>
                            <?$id_temp=$bqr['id']?>
                        <?php
}
}
?>					

                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(58,9,0,0,'isgood>0 or firsttitle','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                        <?php
}
}
?>

                    </ul>
                </div>
                <div class="flowers">
                    <div><a href="http://jidian.china.com/usermemorial.jsp?urlcode=maozedong" title="毛主席纪念堂（中华网）" target="_blank">（中华网）</a><a href="http://cpc.people.com.cn/GB/69112/113427/" title="毛主席纪念堂（人民网）" target="_blank">（人民网）</a><a href="http://www.mzdsx.net/" title="毛主席纪念堂（乌有之乡）" target="_blank">（乌有之乡）</a></div>
                </div>
            </div>
        </div>
        <!-- header end -->
        
        
        <div class="container ">
            <div class="main">
                <div class="main_top clearfix">
                    <div class="section left dongtai">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=59" title="纪念动态"></a></strong></div>
                        <ul class="news_list">

                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(59,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>

                        </ul>
                    </div>
                    <div class="section right huainian">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=60" title="怀念追思"></a></strong></div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(60,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>                    
                </div>
                <div class="ad_banner"><img src="[!--news.url--]skin/default/images/topic_images/left_banner01.jpg" title="马克思列宁主义、毛泽东思想一定不能丢，丢了就丧失根本！" /></div>
                <div class="main_middle clearfix">
                    <div class="section left houdai">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=61" title="主席后代"></a></strong></div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(61,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="section right maoshidai">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=62" title="毛泽东时代"></a></strong></div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(62,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div> 
                </div>
                <div class="ad_banner"><img src="[!--news.url--]skin/default/images/topic_images/left_banner02.jpg" title="一个没有英雄的民族是不幸的，一个有英雄却不知敬重爱惜的民族是不可救药的；一个有了伟大的人物，而不知拥护，爱戴，崇仰的国家是没有希望的民族之邦！" /></div>
                <div class="main_bottom clearfix">
                    <div class="section left pingshu">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=63" title="评述毛泽东"></a></strong></div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(63,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="section right xuexi">
                        <div class="head"><strong><a href="[!--news.url--]e/action/ListInfo/?classid=64" title="学习毛泽东"></a></strong></div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(64,12,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><span class="time_span"><?=date('m-d',$bqr['newstime'])?></span><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>
                    </div> 
                </div>                
            </div>
            <div class="sidebar">
                <div class="side weibo_ing">
                    <iframe width="100%" height="600"  frameborder="0" scrolling="no" src="http://widget.weibo.com/livestream/listlive.php?language=zh_cn&width=0&height=800&uid=2566813090&skin=1&refer=1&appkey=&pic=0&titlebar=0&border=1&publish=1&atalk=1&recomm=0&at=0&atopic=%E7%BA%AA%E5%BF%B5%E6%AF%9B%E4%B8%BB%E5%B8%AD%E8%AF%9E%E8%BE%B0120%E5%91%A8%E5%B9%B4&ptopic=%E7%BA%AA%E5%BF%B5%E6%AF%9B%E4%B8%BB%E5%B8%AD%E8%AF%9E%E8%BE%B0120%E5%91%A8%E5%B9%B4&dpc=1"></iframe>
                </div>
                <div class="side">
                    <div class="head"><strong>视频推荐</strong></div>
                    <div class="content">
                        <div class="first">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(58,1,0,1,'ttid=1 and firsttitle>0','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><img src="<?=sys_ResizeImg($bqr[titlepic],226,169,1,'')?>" /></a>
                                <h4><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></h4>
                                <div class="transparent_bg"></div>
                            <?php
}
}
?>  
                        </div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(65,8,0,0,'ttid=1 and (isgood>0 or firsttitle>0)','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>                        
                    </div>                    
                </div>
                <div class="side video">
                    <div class="head"><strong>影像资料</strong></div>
                    <div class="content">
                        <div class="first">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(65,1,0,1,'ttid=1','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><img src="<?=sys_ResizeImg($bqr[titlepic],226,169,1,'')?>" /></a>
                                <h4><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></h4>
                                <div class="transparent_bg"></div>
                            <?php
}
}
?>       
                        </div>
                        <ul class="news_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(65,8,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['dtitle']?>" target="_blank" ><?=esub($bqr['title'],42)?></a></li>
                            <?php
}
}
?>
                        </ul>                        
                    </div>
                </div>                
            </div>

            <div class="clear_float"></div>
        </div>


        <div class="footer">
            <div class="friendlink">
                <div class="linkbox">
                    <div class="head"><strong>友情链接：</strong></div>
                    <div class="linklist">
                        <ul>
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('copyfrom',60,18,0,'','isgood DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                <li><a href="<?=$bqr['webaddr']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                            <?php
}
}
?>   
                            <div class="clear_float"></div>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <ul>
                    <li class='copy_left'>
                        <div>
                            <a href="[!--news.url--]" title="红歌会网" target="_blank">红歌会网</a>
                            | <a href="[!--news.url--]" title="网址导航" target="_blank">网址导航</a>
                            | <a href="[!--news.url--]html/rank.html" title="排行榜" target="_blank">排行榜</a>
                            | <a href="[!--news.url--]Article/opinion/wp/20257.html" title="联系我们" target="_blank">联系我们</a>
                            | <a href="[!--news.url--]Article/opinion/zatan/13968.html" title="在线提意见" target="_blank">在线提意见</a>
                        </div>
                        <div>
                            <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>
                            | <script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script>

                        <script type="text/javascript">
                        var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
                        document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F2e62d7088e3926a4639571ba4c25de10' type='text/javascript'%3E%3C/script%3E"));
                        </script>


                        </div>
                    </li>
                    <li class="focusbutton">
                        <a class="rss" href="[!--news.url--]e/web/?type=rss2" title="欢迎订阅红歌会网" target="_blank"></a>
                        <a class="sinaweibo" href="http://weibo.com/szhgh?topnav=1&wvr=5&topsug=1" title="欢迎关注红歌会网新浪微博" target="_blank"></a>
                        <a class="qqweibo" href="http://follow.v.t.qq.com/index.php?c=follow&amp;a=quick&amp;name=szhgh001&amp;style=5&amp;t=1737191719&amp;f=1" title="欢迎关注红歌会网腾讯微博" target="_blank"></a>
                        <a class="qqmsg" href="http://wpa.qq.com/msgrd?Uin=1737191719" title="欢迎通过QQ联系我们" target="_blank"></a>
                        <a class="email" href="mailto:szhgh001@163.com" title="欢迎投稿或反映问题" target="_blank"></a>
                    </li>
                    <li class="focusmsg">
                        <div>网站QQ：<a href="http://wpa.qq.com/msgrd?Uin=1737191719" title="欢迎通过QQ联系我们" target="_blank">1737191719</a>&nbsp;&nbsp;红歌会网粉丝QQ群：166238344</div>
                        <div>(投稿)邮箱：<a href="mailto:szhgh001@163.com" title="欢迎投稿或反映问题" target="_blank">szhgh001@163.com</a></div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>

        <script src="[!--news.url--]skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
        <div id="loginmodal" class="loginmodal" style="display:none;">
            <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
            <form class="clearfix" name=login method=post action="[!--news.url--]e/member/doaction.php">
                <div class="login left">
                    <strong>会员登录</strong>
                    <input type=hidden name=enews value=login>
                    <input type=hidden name=ecmsfrom value=9>
                    <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                    <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                    <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                    <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
                </div>
                <div class="reg right">
                    <div class="regmsg"><span>还不是会员？</span></div>
                    <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('[!--news.url--]e/member/register/');" />
                </div>
            </form>
        </div>
        <script type="text/javascript">
            $(function(){
              $('#loginform').submit(function(e){
                return false;
              });

              $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
              $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

              $('#username input').OnFocus({ box: "#username" });
              $('#password input').OnFocus({ box: "#password" });
            });
        </script>

        
    </body>
</html>