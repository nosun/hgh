<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>东莞扫黄风暴 - 红歌会网</title>
    <meta name="keywords" content="" />
    <meta name="description" content="导言：2月9日，随着央视对东莞色情业的曝光，一场声势浩大的扫黄行动，迅速席卷这个昔日被许多人所熟知的“性都”。尽管南方系的诸多媒体与各路公知大V齐声高呼“东莞挺住”、“东莞加油”、“东莞不哭”，但面对以央视和人民日报领军的国家媒体的一路穷追猛打，这股势力很快便溃不成军，无力招架。面对这场突如其来的东莞扫黄风暴，或许还有许多东西值得人们关注和期待。" />
    <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
    <link href="http://www.szhgh.com/skin/default/css/topic_DongguanEvent.css" rel="stylesheet" type="text/css" />
    <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="http://www.szhgh.com/e/data/js/ajax.js"></script>
    <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
    <!--[if !IE]>|xGv00|ef6f6f4cf55337e8218c7e4915dd8658<![endif]-->
    <script>
    function setTab(name,cursel,n){
            for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
            }
    }
    function change(id){
            if (typeof(isround)!='undefined') clearTimeout(isround);
            var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
            var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
            var text = document.getElementById("focus_text").getElementsByTagName("li");
            for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
            }
            bigimg[id-1].className="dis";
            smallimg[id-1].className="current";
            text[id-1].className="dis";
            if ((next=id+1) > smallimg.length) next = 1;
            isround=setTimeout('change('+next+')', 5000);
    }
    </script>
</head>
<?
        $ztid=39;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
        $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);
        
        $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
?>
<body closepl="<?=$zt_r['closepl']?>">
    <!--头部开始-->
    <div class="header">
        <div class="hea_1 clearfix">
            <div class="pleft">
                <div class="hea_logo pleft"><a href="http://www.szhgh.com/" target="_blank" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></a></div>
                <ul class="pleft">
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                </ul>                
            </div>
            <div class="account pright">
                <script>
                    document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                </script>
            </div>
        </div>
    </div>
    <div class="hea_2">
        <p><img src="http://img3.wyzxwk.com/p/2014/02/87a657e7b2e1892535ec56adb86055ad.jpg" width="1000" height="200" /></p>
    </div>
        <div class="hea_3">
            <ul>
                <?
                $ztpath = $public_r['newsurl'].$zt_r['ztpath'];
                $sql = "select cid,cname,ttype from {$dbtbpre}enewszttype where ztid=$ztid order by myorder ASC";
                $result=$empire->query($sql);    //根据专题id从“专题子类主表”查询出“专题子类id”和“专题子类名称”；
                while($r=$empire->fetch($result)) {       //循环获取查询记录到数组$r,并循环输出子类信息列表
                $cid=$r['cid'];
                $zttypepath = $ztpath.'/type'.$r['cid'].$r['ttype']
                ?>
                <li><a href="<?=$zttypepath?>" target="_blank" title="<?=$r['cname']?>"><?=$r['cname']?></a></li>
                <?
                }
                ?>
            </ul>
        </div>

    <!--头部结束-->
    <!--中间开始-->
    <div class="cont">
        <div class="daoy pad_t">导言：2月9日，随着央视对东莞色情业的曝光，一场声势浩大的扫黄行动，迅速席卷这个昔日被许多人所熟知的“性都”。尽管南方系的诸多媒体与各路公知大V齐声高呼“东莞挺住”、“东莞加油”、“东莞不哭”，但面对以央视和人民日报领军的国家媒体的一路穷追猛打，这股势力很快便溃不成军，无力招架。面对这场突如其来的东莞扫黄风暴，或许还有许多东西值得人们关注和期待。</div>
    </div>

    <div class="cont">
        <div class="le_1">
            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 order by newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
            <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],52)?></a></h2>
            <div class="smalltext"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;<a href="<?=$bqsr['titleurl']?>" title="点击查看详情" target="_blank">[评细]</a></div>
            <?php
}
}
?>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>=1 and isgood<4 order by newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>					
            </ul>
        </div>

        <div class="ri_1">
            <div id=focus_pic class=right>
                <div id=focus_big>
                    <ul>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li class="<?if($bqno===1){echo 'dis';}else{echo 'undis';}?>"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><img title="<?=$bqr['title']?>" src="<?=$bqr['titlepic']?>" /></a></li>
                        <?php
}
}
?>	
                    </ul>
                    <div id=focus_text_bg></div>
                    <div id=focus_text>
                        <ul>
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li class="<?if($bqno===1){echo 'dis';}else{echo 'undis';}?>"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><?=$bqr['title']?></a></li>
                            <?php
}
}
?>	
                        </ul>
                    </div>
                </div>
                <div id=focus_tip>
                    <ul>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li class="current" onmouseover=change(<?=$bqno?>);><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><img title="<?=$bqr['title']?>" src="<?=sys_ResizeImg($bqr[titlepic],120,90,1,'')?>" /></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
                <script>
                    var isround = setTimeout("change(2)",2500);
                </script>
            </div>
        </div>
    </div>

    <div class="cont">
        <div class="le_2">
            <h3 class="h3"><a href="http://www.szhgh.com/s/dgshfb/type29.html" title="新闻报道" target="_blank">新闻报道</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(29,10,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
        <div class="le_2">
            <h3 class="h3"><a href="http://www.szhgh.com/s/dgshfb/type30.html" title="网友观点" target="_blank">网友观点</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(30,10,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
        <div class="le_2 le_2a">
            <h3 class="h3"><a href="http://www.szhgh.com/s/dgshfb/type31.html" title="官媒评析" target="_blank">官媒评析</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(31,10,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],36)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2><a title="图片新闻">图片新闻</a></h2>
            <div class="cont_1a clearfix">
                <ul id="flexisel_live0">
                  <!-- 图片列表 begin -->
                  
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and b.ispic=1 order by b.newstime desc limit 20",20,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=$bqr['titlepic']?>" width="200" height="150" title="<?=$bqr['title']?>" style="cursor:pointer;" /></a> 
                        <div class="title"><a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></div> 
                    </li>
                    <?php
}
}
?>

                  <!-- 图片列表 end -->
                </ul>
                <script language="javascript" type="text/javascript">
                    $("#flexisel_live0").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,            
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: { 
                            portrait: { 
                                changePoint:480,
                                visibleItems: 1
                            }, 
                            landscape: { 
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: { 
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });
                </script>
            </div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>东莞扫黄，剑指何方</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">伴随着东莞市公安局局长被免，多名派出所所长被停职调查，四镇党委书记公开道歉，潜藏在幕后披着人大代表、成功企业家外衣的操控色情业的黑恶势力的头目被媒体不断点名和深挖，一场扫黄、反腐、打黑，净化社会环境，重筑道德堤坝的运动，正在慢慢展开。</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/news/politics/2014-02-20/44969.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq4oh2wpyj208r06kglw.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/news/politics/2014-02-20/44969.html" target="_blank" title="中青报：东莞扫黄目的在于反腐 “官场大地震”刚开始">中青报：东莞扫黄目的在于反腐</a></h4>
                    <span>随着官方严查幕后“保护伞”的态度，以及一批官员与相关部门人员被处理，许多人相信，此轮扫黄目的在于反腐，是一项大的反腐行动，由扫黄引起的“官场大地震”才刚刚开始。…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-20/44969.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/news/politics/2014-02-17/44681.html" target="_blank" title="公安部:严打黄赌毒 坚决打击幕后"保护伞"">公安部:严打黄赌毒 坚决打击幕后"保护伞"</a></h4>
                    <span>公安部要求坚决打击卖淫嫖娼活动的组织者、经营者及幕后“保护伞”，并派出督导组赶赴广东指导督办案件查处、问题整治和责任追究工作。建议广东严肃追究东莞市公安局主要领导和其他有关负责人、民警的责任。…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-17/44681.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/news/politics/2014-02-15/44532.html" target="_blank" title="东莞人事“大动作”:多位负责人、一把手被免">东莞人事“大动作”:多位负责人、一把手被免</a></h4>
                    <span>免去卢伟琪市公安局党委副书记、副局长职务;免去黎志辉中堂镇党委书记职务;免去何成中堂公安分局局长职务;免去邓金祥黄江公安分局局长职务;免去张国贤虎门公安分局博涌派出所所长职务;免去王沛基厚街公安分局厚街…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-15/44532.html" target="_blank">评细</a>]</span>	
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/news/politics/2014-02-10/44099.html" target="_blank" title="东莞涉黄五星级酒店老总系人大代表 涉足石油业">东莞涉黄五星级酒店老总系人大代表</a></h4>
                    <span>据央视记者日前在广东东莞的多个乡镇进行了暗访，发现多个娱乐场所存在卖淫嫖娼等违法行为。其中太子酒店和喜来登大酒店颇受关注。太子酒店董事长梁耀辉，42岁，担任中源石油集团董事长，主要涉足石油及酒店行业。”…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-10/44099.html" target="_blank">评细</a>]</span>		
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/news/politics/2014-02-13/44402.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1edq544p54ij208m0640sv.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/news/politics/2014-02-13/44402.html" target="_blank" title="这次不是小姐！首个酒店大股东被带走审查">首个酒店大股东被带走审查 </a></h4>
                    <span>2月9日，执法人员即对新世界酒店五至十三楼旅业共188间客房实施查封，并将该酒店主要股东郑某林带回派出所审查，抓获酒店桑拿部副经理胡某强。经确认，新世界酒店由多名股东合资，其中郑某林是大股东，占股约50%…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-13/44402.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/news/politics/2014-02-16/44616.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq5450dk4j208m064mx6.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/news/politics/2014-02-16/44616.html" target="_blank" title="盘点靠酒店发家的东莞隐性富豪(组图)">盘点靠酒店发家的东莞隐性富豪(组图)</a></h4>
                    <span>随着东莞扫黄的进行，隐藏在霓虹灯后的东莞富豪群逐渐浮出水面。这些富豪依靠投资当地酒店发家，其中包括央视曝光的太子酒店投资人梁耀辉等。这些商人多数极为低调，与其投资的酒店奢华张扬的风格形成强烈反差…[<a href="http://www.szhgh.com/Article/news/politics/2014-02-16/44616.html">评细</a>]</span>
                </div>
            </div>
            <div class="cl"></div>
        </div>
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>扫黄何以会触痛公知大V</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">不管是东方文化还是西方文化的价值观，对待妓女和色情的态度，从来没有像中国当下的公知大V这样理直气壮、振振有词。莫泊桑笔下的羊脂球，《魂断蓝桥》里的玛拉，不管她们的道德品质如何，同样不被社会所接受和认可。灵魂不可以出卖，肉体同样不可以出卖。雨果曾经说过，“女人、没有力量的、贫困的和没有知识的人的不幸和苦难，都是男人、豪强者、有钱的和有学问的人的过失错误造成的。”有学问的公知大V或许应当好好反思一下自己，对于妓女的不幸和苦难，难道你们没有责任。当你们高呼“卖淫无罪，嫖娼有理”的时候，能否亮明一下你妻子女儿的妓女身份或者你的嫖客身份，那怕只是出于声援卖淫嫖娼人员的目的，当你们站在他们中间时，你们的口号才能有说服力，你们才能赢得尊重。</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/news/comments/2014-02-10/44076.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq4ohiwjdj208r06kmyn.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/news/comments/2014-02-10/44076.html" target="_blank" title="南都评论回应央视东莞色情业报道：东莞挺住！">南都回应央视东莞色情业报道:东莞挺住！</a></h4>
                    <span>东莞挺住!舆论对央视暗访东莞色情业的揶揄和反弹，不仅是对报道本身的不满，更是对权力僭越要管住公民下半身的恐惧的本能反应。媒体不是不能报道色情业，这个原始行业是否仍存在暴力血泪、娼妓们的生存状态…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-10/44076.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/opinion/weibo/2014-02-10/44098.html" target="_blank" title=""广东扫黄":微博大V喊“东莞挺住”惹争议">微博大V喊“东莞挺住”惹争议</a></h4>
                    <span>“平安东莞!!!天佑东莞!!!东莞挺住!!!东莞不哭!!!”截至发稿时，作业本的这条微博已经转发超过3万次。大V账号吴主任的“东莞挺住，今夜我们都是东莞人!”倡议也已转发超过1万次。南都的“东莞挺住”微博则于今天凌晨被删除。…[<a href="http://www.szhgh.com/Article/opinion/weibo/2014-02-10/44098.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/news/comments/2014-02-14/44520.html" target="_blank" title="人民日报痛批“东莞挺住”怪象:竟如此荒唐 令人诧异">人民日报痛批“东莞挺住”怪象</a></h4>
                    <span>当一些微博大V娱乐化地调侃“人间有爱”，可曾以一份同情之心，想想那些被明码标价像商品一样叫卖的失足妇女?当一些所谓意见领袖陶醉于“群起挺黄”的幻觉时，可曾审视一下无节操之论对网络生态的扭曲，对世道人心的污染?…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-14/44520.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/news/comments/2014-02-17/44730.html" target="_blank" title="央视新闻联播连续3天 猛烈抨击"无良大V"">新闻联播连续3天 猛烈抨击"无良大V"</a></h4>
                    <span>卖淫嫖娼在大部分西方国家也属违法。一些“大V”以“顺应市场”“选择自由”之名贩卖歪理邪说，说明他们全然无视法治常识，罔顾社会良知。对这些“大V”，真应该猛击一掌、断喝一声：醒醒，不要触碰道德和法律的底线！…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-17/44730.html" target="_blank">评细</a>]</span>		
                </div>
            </div>
            <div class="mar_b"></div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/opinion/zatan/2014-02-17/44702.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1edq543sns5j205k046glr.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/2014-02-17/44702.html" target="_blank" title="从“东莞扫黄”看公知们的卑鄙面目">从“东莞扫黄”看公知们的卑鄙面目</a></h4>
                    <span>央视的曝光报道2014年2月9日播出，第二天(2月10日)有关方即发表微博“力挺东莞”：“东莞你好”、“不要害怕嘲笑”、“不要害怕质疑”、“不要害怕污蔑”、“不要害怕批判”、“不要害怕轻视”、“不要害怕诋毁”、“我们不会出卖灵魂”…[<a href="http://www.szhgh.com/Article/opinion/zatan/2014-02-17/44702.html">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1edq5447lzjj205k046dfz.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html" target="_blank" title="刘仰：无良大V的黄色情结">刘仰：无良大V的黄色情结</a></h4>
                    <span>一些网络大V在强行推动“为反对而反对”在中国舆论场有规模的存在，并宣扬这就是“言论自由”的核心元素。“黄色情结”这么烂的东西也想披上道德的外衣，可见他们是多么狂妄、嚣张、荒唐。我们相信公众的判断力不会被少数大V的私利绑架…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html">评细</a>]</span>
                </div>
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/opinion/zatan/201402/44241.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1edq545n99uj208m064mxq.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201402/44241.html" target="_blank" title="谁把“改革开放”搞成了“改革开房”？">谁把“改革开放”搞成了“改革开房”？</a></h4>
                    <span>色情业绝不是促进经济发展的正道。色情业带来的严重社会后果，绝不是几个GDP就能够来弥补的。黄、赌、毒的泛滥，伤害的不仅是女人的尊严，导致违法犯罪行行为的增加，更为严重的是它毒化社会风气…[<a href="http://www.szhgh.com/Article/opinion/zatan/201402/44241.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/news/comments/2014-02-12/44304.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq5461rv8j208m064aar.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/news/comments/2014-02-12/44304.html" target="_blank" title="环球时报评“挺东莞反央视”怪象：反主流，别上瘾!">环球时报：反主流，别上瘾!</a></h4>
                    <span>中国主流社会亦不完美，整个国家也问题重重。但如果一个人为中国的一个问题而跳下这个国家前进的列车，进而培养出自己站在一边为唱反调而唱反调的习惯，以此为乐为荣，这样的选择尽管可以找一些唬人的流行政治词汇来美化…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-12/44304.html">评细</a>]</span>
                </div>
            </div>

            <div class="cl"></div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>反思：色情业何以愈演愈烈</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">色情业，这个曾被新中国成功铲除的毒瘤，伴随着资本主义的扩张，再次死灰复燃，愈演愈烈。国企下岗，将多少人逼良为娼。教育、医疗、住房、物价四座大山压迫，资本权贵的剥削，使多少人堕入风尘。如果我们曾经的千百万国企没有被外资和体私企瓜分，我们的公有制基础没有被破坏，我们的社会主义福利体系能不断得到完善，我们工厂企业生产的利润不被少数人掠夺窃取，那还会有这么多的妇女进入这一行业吗！</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/news/comments/2014-02-11/44147.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq4oigst4j208r06kq3m.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/news/comments/2014-02-11/44147.html" target="_blank" title="党报:东莞对色情业表现出不可思议的宽容">党报:东莞对色情业表现出不可思议的宽容</a></h4>
                    <span>尽管各种扫黄打非行动时常进行，但最后的结果，是从业人员号称不怕警察怕记者，平日里招摇过市、肆无忌惮；是拨打报警电话，犹如石沉大海，再无音讯；是色情服务在一座城市司空见惯，甚至以“性都”之名积聚人气。
…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-11/44147.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/cdjc/jingdian/201402/44130.html" target="_blank" title="恩格斯：只有公有制才能消灭卖淫">恩格斯：只有公有制才能消灭卖淫</a></h4>
                    <span>这一代男子一生中将永远不会用金钱或其他社会权力手段去买得妇女的献身；而这一代妇女除了真正的爱情以外，也永远不会再出于其他某种考虑而委身于男子，或者由于担心经济后果而拒绝委身于她所爱的男子。…[<a href="http://www.szhgh.com/Article/cdjc/jingdian/201402/44130.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/news/comments/2014-02-11/44170.html" target="_blank" title="央视质问：到底是谁的失职与纵容，才造成今天的东莞?">央视:谁的失职与纵容造成今天的东莞</a></h4>
                    <span>这显然是整个东莞公安系统都已经达成共识和默契，甚至可以说东莞政府对这个现象采取的是睁一只眼闭一只眼甚至是默许存在的态度。如果没有得到更高级别的默认或是允许的话，整个东莞公安系统不可能对于卖淫嫖娼行为…[<a href="http://www.szhgh.com/Article/news/comments/2014-02-11/44170.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/opinion/zatan/201402/44217.html" target="_blank" title="前锋：央视质问东莞，当应问其“根”">前锋：央视质问东莞，当应问其“根”</a></h4>
                    <span>为什么不问问根本原因出在哪儿?广东是不是坚持马列毛主义的共产党领导?广东所走的还是毛泽东共产党的路线吗?怎么不问问创建广东经验的主子及追随者?央视质问东莞，当应问其“根”，才问到实质和要害。…[<a href="http://www.szhgh.com/Article/opinion/zatan/201402/44217.html" target="_blank">评细</a>]</span>			
                </div>
            </div>
           
            <div class="cl"></div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>回顾：建国之初的扫黄缘何取得巨大成功</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">新中国诞生之初就能一举涤清妓院这个存在了千年的污泥浊水，主要有几个方面值得思考。一、新生的无产阶级政权对遭受最深重压迫的妇女的朴素的阶级感情，采用强大的国家力量让她们回归和融入社会。二、重塑思想观念，对妓女进行教育改造，让她们成为自食其力的劳动者，重拾做人的尊严，过上有意义有价值的生活。三、严惩妓院老板，对其财产予以没收。</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/wsds/history/2014-02-10/44089.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1edq4okskg1j208r06k752.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/2014-02-10/44089.html" target="_blank" title="“姐姐妹妹站起来”：新中国初期的扫黄记实">新中国初期的扫黄记实</a></h4>
                    <span>治疗性病最有效的药品是青霉素，由于西方封锁也无法进口，只有从国民党那里缴获的为数不多的一些，还预备留给负重伤的抗美援朝志愿军。上海市市长陈毅了解此事后立即批示：“先给教养院，志愿军战士另想办法。”…[<a href="http://www.szhgh.com/Article/wsds/history/2014-02-10/44089.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/wsds/history/2014-02-20/44991.html" target="_blank" title="新中国的第一次"扫黄"">新中国的第一次"扫黄"</a></h4>
                    <span>老街坊们都很关照，言语中从不触及她们的过去。倘若邻里纠纷，“亲娘祖奶奶”骂出口在所难免，但谁要是语出“妓女”、“窑姐”一类的龌龊话，就会立犯众怒，这种缺德的、挨千刀的骂人话，在“八大胡同”一带往往被视为绝骂。…[<a href="http://www.szhgh.com/Article/wsds/history/2014-02-20/44991.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/2014-02-20/44994.html" target="_blank" title="一夜之间关闭北京所有妓院">一夜之间关闭北京所有妓院</a></h4>
                    <span>一夜之间将224家妓院全部封闭,妓院老板、领家454人全部集中,1290个陷入火坑的姐妹们从此得到解放。与此同时,政府组织医务人员给每名妓女进行体检,发现仅有44人未患性病,而逾千名妓女需要接受医治…[<a href="http://www.szhgh.com/Article/wsds/history/2014-02-20/44994.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/opinion/zatan/2014-02-16/44612.html" target="_blank" title="前后三十年扫黄对比">前后三十年扫黄对比</a></h4>
                    <span>首先，行动的目的不同，前者的目的是彻底消灭社会丑恶现象，后者行动的目的是惩罚妓女。对妓女的处理不同，前者是学习、治病、找工作、找婆家，后者是罚款、判刑。前者视妓女为姐妹，后者是贱货…[<a href="http://www.szhgh.com/Article/opinion/zatan/2014-02-16/44612.html" target="_blank">评细</a>]</span>			
                </div>
            </div>

            <div class="cl"></div>
        </div>	
    </div>

   
    <div class="cont">
        <div class="daoy"><?=ReturnZtAddField(0,'conclusion')?></div>
    </div>

    <div class="cont_pl">
        <div id="plpost" class="pl_list">
            <!-- 评论 -->
            <div id="tosaypl" class="pl section">
               <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
            </div>
            <div class="section_content">
                <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
            </div>
        </div>
    </div>
    
    <!--中间结束-->
    
    
    <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1962727933</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
        });
    </script>
    <!--底部结束-->
    

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=39></script>

</body>
</html>