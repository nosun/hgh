<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>2014两会观察 - 红歌会网</title>
    <meta name="keywords" content="" />
    <meta name="description" content="改革是目的还是手段？改革是对社会主义制度的自我完善还是自我否定？当一部分人已经先富起来后，实现共同富裕的改革目标是不是可以提上日程？" />
    <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
    <link href="http://www.szhgh.com/skin/default/css/topic_sessions.css" rel="stylesheet" type="text/css" />
    <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/myfocus-2.0.4.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/mF_tbhuabao_fortopic_sessions.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/newsScroll.js" type="text/javascript"></script>
    <script type="text/javascript" src="http://www.szhgh.com/e/data/js/ajax.js"></script>
    <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
    <!--[if !IE]>|xGv00|ef6f6f4cf55337e8218c7e4915dd8658<![endif]-->
    <script>
    function setTab(name,cursel,n){
            for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
            }
    }
    function change(id){
            if (typeof(isround)!='undefined') clearTimeout(isround);
            var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
            var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
            var text = document.getElementById("focus_text").getElementsByTagName("li");
            for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
            }
            bigimg[id-1].className="dis";
            smallimg[id-1].className="current";
            text[id-1].className="dis";
            if ((next=id+1) > smallimg.length) next = 1;
            isround=setTimeout('change('+next+')', 5000);
    }
    </script>
</head>
<?
        $ztid=40;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
        $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);
        
        $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
?>
<body closepl="<?=$zt_r['closepl']?>">
    <!--头部开始-->
    <div class="header">
        <div class="hea_1 clearfix">
            <div class="pleft">
                <div class="hea_logo pleft"><a href="http://www.szhgh.com/" target="_blank" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></a></div>
                <ul class="pleft">
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                </ul>                
            </div>
            <div class="account pright">
                <script>
                    document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                </script>
            </div>
        </div>
    </div>
    <div class="hea_2"></div>

    <!--头部结束-->
    <!--中间开始-->

    <div class="wrap width clearfix margin-t">
        <div class="mainbox left">
            <div class="section sectionA">
                <div class="section_header">头条文章</div>
                <div class="section_content">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>5 order by isgood desc limit 4",4,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <div class="txt">
                            <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></h2>
                        </div>
                        <p>
                        <?php
                            $zt_link_r = $empire->fetch1("select keyid from {$dbtbpre}ecms_article_data_1 where id=" . $bqr[id]);
                            $links_id_r = explode(",",$zt_link_r[keyid]);
                            for($i=0;$i<6;$i++) {
                                $zar = $empire->fetch1("select * from {$dbtbpre}ecms_article where id=" . $links_id_r[$i]);
                                if($zar and $i%2===0){
                        ?>
                            <a href="<?=$zar['titleurl']?>" title="<?=$zar['title']?>" target="_blank"><?=esub($zar['title'],28)?></a>
                            <span>|</span>
                        <?php
                                }elseif($zar and $i%2===1){
                        ?>
                            <a href="<?=$zar['titleurl']?>" title="<?=$zar['title']?>" target="_blank"><?=esub($zar['title'],28)?></a></p><p>
                        <?php
                        }
                            }
                        ?>
                    <?php
}
}
?>
                </div>                
            </div>
            <div class="section sectionB">
                <div class="section_header"><a href="http://www.szhgh.com/s/sessions/type33.html" title="两会报道" target="_blank">两会报道</a></div>
                <div class="section_content quotationbg">
                    <div class="bg_quotation_top"></div>
                    <div class="txt">
                        <p>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 and cid=33 order by newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <?php
                                if($bqno%2===1){
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a>
                            <span>|</span>
                            <?php
                                }else{
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></p><p>
                            <?php
                                }
                            ?>
                        <?php
}
}
?>
                    </div>
                    <div class="bg_quotation_bottom"></div>
                </div>                
            </div>
            <div class="section sectionB">
                <div class="section_header"><a href="http://www.szhgh.com/s/sessions/type34.html" title="学者评析" target="_blank">学者评析</a></div>
                <div class="section_content quotationbg">
                    <div class="bg_quotation_top"></div>
                    <div class="txt">
                        <p>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 and cid=34 order by newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <?php
                                if($bqno%2===1){
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a>
                            <span>|</span>
                            <?php
                                }else{
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></p><p>
                            <?php
                                }
                            ?>
                        <?php
}
}
?>
                    </div>
                    <div class="bg_quotation_bottom"></div>
                </div>                
            </div>            
            <div class="section sectionB">
                <div class="section_header"><a href="http://www.szhgh.com/s/sessions/type35.html" title="网友之声" target="_blank">网友之声</a></div>
                <div class="section_content quotationbg">
                    <div class="bg_quotation_top"></div>
                    <div class="txt">
                        <p>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 and cid=35 order by newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <?php
                                if($bqno%2===1){
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a>
                            <span>|</span>
                            <?php
                                }else{
                            ?>
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></p><p>
                            <?php
                                }
                            ?>
                        <?php
}
}
?>
                    </div>
                    <div class="bg_quotation_bottom"></div>
                </div>                
            </div>            
        </div>
        <div class="sidebox right">
            <div class="section pic">
                <div class="section_header"><a href="#" title="" target="_blank">图片文章</a></div>
                <div id="myFocus" class="scroll">
                    <div class="loading"></div><!--载入画面(可删除)-->
                    <div class="pic"><!--图片列表-->
                        <ul class="scroll_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>=4 and b.ispic=1 order by b.newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li>
                                <a href="<?=$bqsr['titleurl']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],380,285,1,'')?>" alt="<?=$bqr['title']?>" /></a>
                            </li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="scroll_bg"></div>
                </div>
                
                <script type="text/javascript">
                    myFocus.set({
                        id: 'myFocus', //焦点图盒子ID
                        pattern: 'mF_tbhuabao', //风格应用的名称
                        time: 3, //切换时间间隔(秒)
                        trigger: 'click', //触发切换模式:'click'(点击)/'mouseover'(悬停)
                        width: 380, //设置图片区域宽度(像素)
                        height: 285, //设置图片区域高度(像素)
                        txtHeight: 'default'//文字层高度设置(像素),'default'为默认高度，0为隐藏
                    });
                </script>
                
            </div>
            <div class="section video">
                <div class="section_header"><a href="#" title="" target="_blank">视频</a></div>
                <div class="section_content">
                    <div class="clearfix">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>=4 and b.ispic=1 and ttid=1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <a class="zoompic left" href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],192,144,1,'')?>" /><div class="icovideo"></div></a>
                            <div class="titleintro right">
                                <h4><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],20)?></a></h4>
                                <div class="intro"><?=$bqr['smalltext ']?> <a href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                            </div>
                        <?php
}
}
?>
                    </div>
                    <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and ttid=1 order by b.newstime desc limit 5",5,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],48)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>                   
            </div>            
            <div class="section vote">
                <div class="section_header"><a href="#" title="" target="_blank">调查</a></div>
                <div class="section_content">
                    <div id="news_rolling_up" class="prebutton"></div>
                    <div id="news_rolling">
                        <ul class="list">
                            <li>
                                <script type="text/javascript" src="http://www.szhgh.com/d/js/vote/vote10.js"></script>
                            </li>
                            <li>
                                <script type="text/javascript" src="http://www.szhgh.com/d/js/vote/vote9.js"></script>
                            </li>
                
                        </ul>                        
                    </div>
                    <div id="news_rolling_down" class="nextbutton"></div>
                </div>

                
            </div>             
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="#">高层论改革</a></div><div class="linebg"></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <a href="http://www.szhgh.com/Article/news/leaders/2014-03-01/45752.html" title="习近平：重大改革要于法有据" target="_blank" class="title-absolute1"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eeezdm2c2pj20fa0bh0tg.jpg" /><div class="title">习近平：重大改革要于法有据</div><div class="opacitybg"></div></a>
                <div class="intro">习近平指出，对重大改革尤其是涉及人民群众切身利益的改革决策，要建立社会稳定评估机制。遇到关系复杂、牵涉面广、矛盾突出的改革，要及时深入了解群众实际生活情况怎么样，群众诉求是什么，改革能给群众带来的利益有多少，从人民利益出发谋划思路、制定举措、推进落实。要建立科学评价机制，对改革效果进行全面评估。</div>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/news/leaders/2014-03-10/46625.html" title="习近平:不能把国企改革变成谋暴利机会" target="_blank">“习近平:不能把国企改革变成谋暴利机会</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/news/leaders/2014-03-10/46625.html" title="习近平:不能把国企改革变成谋暴利机会" target="_blank" class="pic left"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eeezoqc89tj208r06oglo.jpg" /></a>
                            <div class="intro right">习近平指出，要吸取过去国企改革经验和教训，不能在一片改革声浪中把国有资产变成谋取暴利的机会。改革关键是公开透明。<a class="readmore" href="http://www.szhgh.com/Article/news/leaders/2014-03-10/46625.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/news/leaders/2014-03-05/46189.html" title="李克强：以背水一战的气概 全面深化改革" target="_blank">“李克强：以背水一战的气概 全面深化改革</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/news/leaders/2014-03-05/46189.html" title="李克强：以背水一战的气概 全面深化改革" target="_blank" class="pic left"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eeezzw1f8dj207s05u0sx.jpg" /></a>
                            <div class="intro right">改革是最大的红利。当前改革已进入攻坚期和深水区，必须紧紧依靠人民群众，以壮士断腕的决心、背水一战的气概，冲破思想 <a class="readmore" href="http://www.szhgh.com/Article/news/leaders/2014-03-05/46189.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>                    
                </ul>
                <ul class="title">
                    <li><a href="http://www.szhgh.com/Article/news/leaders/2014-03-08/46473.html" title="习近平忆插队岁月:对贫困群众有天然感情" target="_blank">习近平忆插队岁月:对贫困群众有天然感情</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/leaders/2014-03-12/46829.html" title="李克强忆插队岁月:曾因生产队缺粮开“逃春荒”证明" target="_blank">李克强忆插队岁月:曾因生产队缺粮开“逃春荒”证明</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/leaders/2014-02-24/45276.html" title="李克强：市场主体“法无禁止即可为" target="_blank">李克强：市场主体“法无禁止即可为”</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/leaders/2014-03-06/46293.html" title="李克强77次提“改革” 超过朱镕基温家宝" target="_blank">李克强77次提“改革” 超过朱镕基温家宝</a></li>                        
                    <li><a href="http://www.szhgh.com/Article/news/leaders/2014-02-12/44262.html" title="李克强主持座谈会 工商联主席:“民资进入某些领域还有困难" target="_blank">李克强主持座谈会 工商联主席:“民资进入某些领域还有困难”</a></li>
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <a href="http://www.szhgh.com/Article/news/leaders/2014-03-13/46947.html" title="李克强答中外记者问（全文）" class="pic" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eef03jvy37j207s05u74m.jpg" /></a>
                    <strong class="title"><a href="http://www.szhgh.com/Article/news/leaders/2014-03-13/46947.html" title="李克强答中外记者问（全文）" target="_blank" rel="nofollow">李克强答中外记者问（全文）</a></strong>
                </div>
                <ul class="pictitle-video">
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/news/leaders/2014-03-11/46790.html" title="习近平出席解放军团会议 谈雷锋精神" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eef0te1de3j203c02iwec.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/news/leaders/2014-03-11/46790.html" title="习近平出席解放军团会议 谈雷锋精神" target="_blank" rel="nofollow">习近平出席解放军团会议 谈雷锋精神</a></strong>
                    </li>
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/news/leaders/2014-03-14/47015.html" title="视频：张德江作全国人大常委会工作报告（全程）" class="pic left" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eef12hoezyj203c02i745.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/news/leaders/2014-03-14/47015.html" title="视频：张德江作全国人大常委会工作报告（全程）" target="_blank" rel="nofollow">视频：张德江作全国人大常委会工作报告（全程）</a></strong>
                    </li>                    
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/news/leaders/2014-03-04/46016.html" title="俞正声首次政协讲话：鼓励尖锐而不极端的批评" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eef17zh8swj203c02i745.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/news/leaders/2014-03-04/46016.html" title="俞正声首次政协讲话：鼓励尖锐而不极端的批评" target="_blank" rel="nofollow">俞正声首次政协讲话：鼓励尖锐而不极端的批评</a></strong>
                    </li>                    
                </ul>
            </div>
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="#">民间看两会</a></div><div class="linebg"></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-03-10/46693.html" title="张宏良：左翼代表的缺席和习总声音的孤单" target="_blank" class="title-absolute1"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eef1kkndy4j208w06ogm5.jpg" /><div class="title">张宏良：左翼代表的缺席和习总声音的孤单</div><div class="opacitybg"></div></a>
                <div class="intro">当今中国最需要的一项重要改革，就是改革两会代表的构成。在社会构成上，大幅增加底层工农民众的代表，即使不能够恢复到毛泽东时代比重，不能够按照各阶层人口数量设置代表比重，至少先恢复到三分之一以上;在政治构成上，必须要有左翼力量的代表，左翼力量代表人数，至少应该相等于那些著名极右人士。</div>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" title="两会“反毛提案”曝光 网友刊文怒斥" target="_blank">“两会“反毛提案”曝光 网友刊文怒斥</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" title="两会“反毛提案”曝光 网友刊文怒斥" target="_blank" class="pic left"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eef3u0y3psj203c02i0sl.jpg" /></a>
                            <div class="intro right">爱国学者张宏良在其文章《左翼代表的缺席和习总声音的孤单》中提到，此次两会有人提交了“极其恶毒的反毛提案”，但未提具 <a class="readmore" href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/opinion/zatan/201403/46855.html" title="梅子：西山的太阳就要落山了" target="_blank">“梅子：西山的太阳就要落山了</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/opinion/zatan/201403/46855.html" title="梅子：西山的太阳就要落山了" target="_blank" class="pic left"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eef3u1c7ujj203c02i0so.jpg" /></a>
                            <div class="intro right">为公者失，为私者得；为理想者苦，为物欲者福；为民者穷，为贪者富；为天下者塞，为同党者通；为公者狱，为己者达。 <a class="readmore" href="http://www.szhgh.com/Article/opinion/zatan/201403/46855.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>                    
                </ul>
                <ul class="title">
                    <li><a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-02-27/45583.html" title="卢麒元：关于国企，再次提醒中央领导" target="_blank">卢麒元：关于国企，再次提醒中央领导</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/2014-03-04/46041.html" title="美华：关于政协委员的外国身份，你懂的" target="_blank">美华：关于政协委员的外国身份，你懂的</a></li>
                    <li><a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-03-06/46280.html" title="赵磊评委员建议“禁《水浒》维稳”:历史真是惊人相似" target="_blank">赵磊评委员建议“禁《水浒》维稳”:历史真是惊人相似</a></li>
                    <li><a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-03-01/45789.html" title="杜建国：中石化引进民资对谁有利？" target="_blank">杜建国：中石化引进民资对谁有利？</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/wenyi/201403/46654.html" title="网友自创相声小段揭露混合所有制本质" target="_blank">网友自创相声小段揭露混合所有制本质</a></li>                        
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <a href="http://www.szhgh.com/Article/opinion/xuezhe/201403/46509.html" title="顽石：关于两会，答网友问" class="pic" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eef47gigblj205k0460t4.jpg" /></a>
                    <strong class="title"><a href="http://www.szhgh.com/Article/opinion/xuezhe/201403/46509.html" title="顽石：关于两会，答网友问" target="_blank" rel="nofollow">顽石：关于两会，答网友问</a></strong>
                </div>
                <ul class="pictitle-video">
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-03-08/46520.html" title="张宏良评2014年政府工作报告" class="pic left" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eef9rlf37wj203c02idfs.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-03-08/46520.html" title="张宏良评2014年政府工作报告" target="_blank" rel="nofollow">张宏良评2014年政府工作报告</a></strong>
                    </li>
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/opinion/xuezhe/201403/46901.html" title="" class="pic left" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eef9rlujqtj203c02ijre.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/opinion/xuezhe/201403/46901.html" title="余额宝引发的是共和国历史上最大的货币空转" target="_blank" rel="nofollow">余额宝引发的是共和国历史上最大的货币空转</a></strong>
                    </li>                    
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/wsds/wenyi/2014-03-08/46491.html" title="" class="pic left" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eef9rm8rlqj203c02imx3.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/wsds/wenyi/2014-03-08/46491.html" title="胥渡吧吐槽犀利，配音王道说当下，大快人心" target="_blank" rel="nofollow">胥渡吧吐槽犀利，配音王道说当下，大快人心</a></strong>
                    </li>                    
                </ul>
            </div>
        </div>
    </div>

<div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="#">聚焦转基因</a></div><div class="linebg"></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46334.html" title="" target="_blank" class="title-absolute1"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefc5ofydoj208w06ogmp.jpg" /><div class="title">崔永元首次公开发布关于转基因问题的政协提案</div><div class="opacitybg"></div></a>
                <div class="intro">中国大地一旦布满转基因种子，中国农业和粮食生产会丧失自主权，走向一条被跨国公司控制的“永远不归路”!民以食为天，食以安为先。为此，吁请政府目前坚决禁止转基因主粮商业化，稳妥地处理转基因专项的研究方向，立即终止种子企业的转基因项目，加强常规品种培育和特种植物品种培育，确保中国粮食安全。</div>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46318.html" title="农业部韩长赋谈转基因：我也在吃转基因豆油" target="_blank">农业部韩长赋谈转基因：我也在吃转基因豆油</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46318.html" title="" target="_blank" class="pic left"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eefc5oulqdj203c02it8m.jpg" /></a>
                            <div class="intro right">我现在在吃转基因原料加工的食品，具体来讲就是大豆。我们国家的豆油主要是用进口大豆制作的，进口大豆主要是转基因大豆。 <a class="readmore" href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46318.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <li>
                        <h3><a href="http://www.szhgh.com/Article/health/zjy/201403/46896.html" title="柴卫东：谨以此文，声援崔永元" target="_blank">“柴卫东：谨以此文，声援崔永元</a></h3>
                        <div class="picintro clearfix">
                            <a href="http://www.szhgh.com/Article/health/zjy/201403/46896.html" title="" target="_blank" class="pic left"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eefc5ple14j203c02it8n.jpg" /></a>
                            <div class="intro right">当前我国糖尿病发病率超过11.7%，心脑血管疾病发病率超过13%，慢性肾病人口达到10%，不孕不育症人数超过5000万。 <a class="readmore" href="http://www.szhgh.com/Article/health/zjy/201403/46896.html" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>                    
                </ul>
                <ul class="title">
                    <li><a href="http://www.szhgh.com/Article/health/zjy/2014-03-08/46521.html" title="蒋高明：中国人多地少不是发展转基因的理由" target="_blank">蒋高明：中国人多地少不是发展转基因的理由</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/zjy/2014-03-05/46149.html" title="崔永元政协会连续发问：部委食堂是否食用转基因" target="_blank">崔永元政协会连续发问：部委食堂是否食用转基因</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/zjy/2014-03-12/46837.html" title="农业部副部长：市场上转基因食品可放心买 应向孟山都学习" target="_blank">农业部副部长：市场上转基因食品可放心买 应向孟山都学习</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/zjy/2014-03-04/46030.html" title="农业部副部长谈"转基因大米销往超市被曝光":那是违法行为" target="_blank">农业部副部长谈"转基因大米销往超市被曝光":那是违法行为</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/zjy/2014-03-12/46833.html" title="科技副部长谈转基因食品：没那么多担心好吃就行" target="_blank">科技副部长谈转基因食品：没那么多担心好吃就行</a></li>                        
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <a href="http://www.szhgh.com/Article/health/zjy/2014-03-01/45783.html" title="崔永元赴美国考察转基因纪录片" class="pic" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefc5q88wxj205k046wek.jpg" /></a>
                    <strong class="title"><a href="http://www.szhgh.com/Article/health/zjy/2014-03-01/45783.html" title="崔永元赴美国考察转基因纪录片" target="_blank" rel="nofollow">崔永元赴美国考察转基因纪录片</a></strong>
                </div>
                <ul class="pictitle-video">
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/health/zjy/153.html" title="风靡网络的视频:《转基因的前世今生》" class="pic left" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefc5qsc42j203c02imx4.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/health/zjy/153.html" title="风靡网络的视频:《转基因的前世今生》" target="_blank" rel="nofollow">风靡网络的视频:《转基因的前世今生》</a></strong>
                    </li>
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/health/zjy/2014-02-16/44637.html" title="挺转派与反转派在东方卫视正面交锋" class="pic left" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eefc5r54r2j203c02i3yg.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/health/zjy/2014-02-16/44637.html" title="挺转派与反转派在东方卫视正面交锋" target="_blank" rel="nofollow">挺转派与反转派在东方卫视正面交锋</a></strong>
                    </li>                    
                    <li class="clearfix">
                        <a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46312.html" title="崔永元两会谈食品安全 继续质疑转基因" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eefc5rmi8uj203c02i3yg.jpg" /></a>
                        <strong class="title right"><a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46312.html" title="崔永元两会谈食品安全 继续质疑转基因" target="_blank" rel="nofollow">崔永元两会谈食品安全 继续质疑转基因</a></strong>
                    </li>                    
                </ul>
            </div>
        </div>
    </div>

    <div class="wrap width wrap-2">
        <div class="wrap_header clearfix"><div class="txt"><a href="#">民众期待</a></div><div class="linebg"></div></div>
        <div class="wrap_content clearfix margin_t0">
            <dl class="left">
                <dt><a href="http://www.szhgh.com/Article/opinion/zatan/201402/45240.html" title="致全国人大:民众期盼这十个问题被高度关注" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eefie3lhm5j2040030dfs.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201402/45240.html" title="致全国人大:民众期盼这十个问题被高度关注" target="_blank" rel="nofollow">致全国人大:民众期盼这十个问题被高度关注</a></h4>
                    <div class="intro">要深化改革首先必须明确共产党人的崇高信仰和立党宗旨，在所有制问题上必须遵照宪法与党章规定，坚持两个毫不动摇的原则，才能维护<a href="http://www.szhgh.com/Article/opinion/zatan/201402/45240.html" class="readmore" title="致全国人大:民众期盼这十个问题被高度关注" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>
            <dl class="right">
                <dt><a href="http://www.szhgh.com/Article/health/food/2014-02-25/45411.html" title="两地爱国学者献策：提请国务院与人大高度关注" class="pic left" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eefie41noaj20400300sq.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/health/food/2014-02-25/45411.html" title="两地爱国学者献策：提请国务院与人大高度关注" target="_blank" rel="nofollow">两地爱国学者献策：提请国务院与人大高度关注</a></h4>
                    <div class="intro">2013 年 12 月举行的中央经济工作会议将这一问题提到了前所未有的重要位置，提出了实施以我为主、立足国内、确保产能<a href="http://www.szhgh.com/Article/health/food/2014-02-25/45411.html" class="readmore" title="两地爱国学者献策：提请国务院与人大高度关注" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>            
            <dl class="left">
                <dt><a href="http://www.szhgh.com/Article/news/politics/24738.html" title="" class="pic left" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefie4sh2wj2040030q2w.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/news/politics/24738.html" title="马宾等2993人发出呼吁:高举马列主义毛泽东思想伟大旗帜，挽救国家和民族" target="_blank" rel="nofollow">马宾等2993人发出呼吁:高举马列主义毛泽东思想伟大旗帜，挽救国家和民族</a></h4>
                    <div class="intro">国内危机。国内已经出现公有制经济主体地位丧失、贫富两极分化、环境资源破坏、对外经济依赖、许多资本家进入党内、工农大众<a href="http://www.szhgh.com/Article/news/politics/24738.html" class="readmore" title="马宾等2993人发出呼吁:高举马列主义毛泽东思想伟大旗帜，挽救国家和民族" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>
            <dl class="right">
                <dt><a href="http://www.szhgh.com/Article/opinion/xuezhe/201311/38468.html" title="" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eefie5iyetj2040030mx6.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/xuezhe/201311/38468.html" title="曹建海呼吁:应即刻叫停大拆大建的城镇化方式" target="_blank" rel="nofollow">曹建海呼吁:应即刻叫停大拆大建的城镇化方式</a></h4>
                    <div class="intro">毛泽东临终时流泪了，武装革命了一辈子，他仍想要文化大革命。为什麽要搞文化大革命，为什麽有人一听到文革就发抖，那是他们心中的魔鬼<a href="http://www.szhgh.com/Article/opinion/xuezhe/201311/38468.html" class="readmore" title="曹建海呼吁:应即刻叫停大拆大建的城镇化方式" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>            
            <dl class="left">
                <dt><a href="" title="http://www.szhgh.com/Article/opinion/xuezhe/2014-02-25/45410.html" class="pic left" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2gw1eefie65j2qj2040030q2v.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-02-25/45410.html" title="学者呼吁：必须高度重视农民寿命下降现象" target="_blank" rel="nofollow">学者呼吁：必须高度重视农民寿命下降现象</a></h4>
                    <div class="intro">过去20年中，中国人平均寿命中，男性为72.05，女性为75.35。与全国平均值相比，该村庄男性寿命下降了1.42岁，女性下降4.36岁。<a href="http://www.szhgh.com/Article/opinion/xuezhe/2014-02-25/45410.html" class="readmore" title="学者呼吁：必须高度重视农民寿命下降现象" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>
            <dl class="right">
                <dt><a href="http://www.szhgh.com/Article/opinion/zatan/201401/42289.html" title="恽仁祥：关于从严治党的一点建议" class="pic left" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefie6i33nj2040030dfu.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201401/42289.html" title="恽仁祥：关于从严治党的一点建议" target="_blank" rel="nofollow">恽仁祥：关于从严治党的一点建议</a></h4>
                    <div class="intro">毛泽东临终时流泪了，武装革命了一辈子，他仍想要文化大革命。为什麽要搞文化大革命，为什麽有人一听到文革就发抖，那是他们心中的魔鬼<a href="http://www.szhgh.com/Article/opinion/zatan/201401/42289.html" class="readmore" title="恽仁祥：关于从严治党的一点建议" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>            
            <dl class="left">
                <dt><a href="http://www.szhgh.com/Article/opinion/zatan/201402/44415.html" title="再向两会建议：草根平民希望的改革之路" class="pic left" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefie71l9pj2040030jrc.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201402/44415.html" title="再向两会建议：草根平民希望的改革之路" target="_blank" rel="nofollow">再向两会建议：草根平民希望的改革之路</a></h4>
                    <div class="intro">毛泽东临终时流泪了，武装革命了一辈子，他仍想要文化大革命。为什麽要搞文化大革命，为什麽有人一听到文革就发抖，那是他们心中的魔鬼<a href="http://www.szhgh.com/Article/opinion/zatan/201402/44415.html" class="readmore" title="再向两会建议：草根平民希望的改革之路" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>
            <dl class="right">
                <dt><a href="http://www.szhgh.com/Article/opinion/zatan/201402/45309.html" title="点子牛为两会建言：农民团结联合起来，建桥造船过大江" class="pic left" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eefie7g2waj2040030jrd.jpg" /></a></dt>
                <dd>
                    <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201402/45309.html" title="点子牛为两会建言：农民团结联合起来，建桥造船过大江" target="_blank" rel="nofollow">点子牛为两会建言：农民团结联合起来，建桥造船过大江</a></h4>
                    <div class="intro">中国是农业大国，也是发展中国家，贫困人口1.2亿主要是农民。农民富裕是我们保持政治稳定，经济繁荣，进入发达国家，实现民族复兴最关键<a href="http://www.szhgh.com/Article/opinion/zatan/201402/45309.html" class="readmore" title="点子牛为两会建言：农民团结联合起来，建桥造船过大江" target="_blank" rel="nofollow">[详细]</a></div>
                </dd>
            </dl>
        </div> 
    </div>
    
    <div class="wrap width wrap-3">
        <div class="wrap_header clearfix"><div class="txt"><a href="#">两会提案</a></div><div class="linebg"></div></div>
        <div class="wrap_content clearfix">
            <div class="left textpic-box2 quotationbg">
                <a class="pic" href="http://www.szhgh.com/Article/news/politics/2014-03-14/47067.html" title="" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefk18djvkj206o050jrp.jpg" /></a>
                 <div class="author"><span>姜明</span></div>
                <div class="bg_quotation_top"></div>
                <div class="intro">混合所有制、国企改革、民营银行，当一伙资本家成了人民大会堂的主人，那些议题和议案，也就成了他们抢劫和瓜分国有资产的工具。当国家主席不得不高声喝斥“不能把国企改革变成谋暴利机会”，人们就不难理解这些窃国大盗有多猖獗。</div>
                <div class="bg_quotation_bottom"></div>
            </div>
            <div class="right list4">
                <dl class="left">
                    <dt><a href="#" title="" target="_blank" class="pictitle"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefkdw7pvaj201o01ot8i.jpg" /><div>崔永元</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46334.html" title="崔永元首次公开发布关于转基因问题的政协提案" target="_blank" rel="nofollow">崔永元首次公开发布关于转基因问题的政协提案</a></h4>
                            <div class="intro">吁请政府目前坚决禁止转基因主粮商业化，稳妥地处理转基因专项的研究方向 <a href="http://www.szhgh.com/Article/health/zjy/2014-03-06/46334.html" class="readmore" title="崔永元首次公开发布关于转基因问题的政协提案" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="#" title="" target="_blank" class="pictitle"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefkdviufgj201o01odfn.jpg" /><div>李彦宏</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/news/politics/2014-03-04/46048.html" title="百度董事长李彦宏提案：鼓励民企进入航天领域" target="_blank" rel="nofollow">百度董事长李彦宏提案：鼓励民企进入航天领域</a></h4>
                            <div class="intro">李彦宏建议国家相关主管部门鼓励民营企业开展火箭、卫星等的研制、生产和发 <a href="http://www.szhgh.com/Article/news/politics/2014-03-04/46048.html" class="readmore" title="点此查看详细内容" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/health/zjy/2014-03-14/47069.html" title="" target="_blank" class="pictitle"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefl307ibzj201o01ojr7.jpg" /><div>宗庆后</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/health/zjy/2014-03-14/47069.html" title="宗庆后：建议严格落实转基因产品标识制度" target="_blank" rel="nofollow">宗庆后：建议严格落实转基因产品标识制度</a></h4>
                            <div class="intro">转基因产品现在是一个争议话题。欧洲人和非洲人不食用转基因食品，在美国也<a href="http://www.szhgh.com/Article/health/zjy/2014-03-14/47069.html" class="readmore" title="点此查看详细内容" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" title="" target="_blank" class="pictitle"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefl31oxntj201o01oglf.jpg" /><div>章立凡</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" title="两会“反毛提案”曝光 网友刊文怒斥" target="_blank" rel="nofollow">两会“反毛提案”曝光 网友刊文怒斥</a></h4>
                            <div class="intro">早就风传有人主张把毛主席纪念堂清空改做他用，但是我并未看见有文字公布 <a href="http://www.szhgh.com/Article/opinion/zatan/201403/46806.html" class="readmore" title="两会“反毛提案”曝光 网友刊文怒斥" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47071.html" title="农民工代表易凤娇：让员工宿舍有免费WIFI" target="_blank" class="pictitle"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eefl30oqwzj201o01o3yb.jpg" /><div>易凤娇</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47071.html" title="农民工代表易凤娇：让员工宿舍有免费WIFI" target="_blank" rel="nofollow">农民工代表易凤娇：让员工宿舍有免费WIFI</a></h4>
                            <div class="intro">建议民企特殊工种享受与国企同等退休政策，可提前五年退休 <a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47071.html" class="readmore" title="农民工代表易凤娇：让员工宿舍有免费WIFI" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/news/politics/2014-03-05/46153.html" title="全国政协委员联名提案呼吁建立"抗日战争胜利纪念碑"" target="_blank" class="pictitle"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2gw1eeflodjml1j201o01o0sj.jpg" /><div>许进</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/news/politics/2014-03-05/46153.html" title="全国政协委员联名提案呼吁建立"抗日战争胜利纪念碑"" target="_blank" rel="nofollow">全国政协委员联名提案呼吁建立"抗日战争胜利纪念碑"</a></h4>
                            <div class="intro">毛泽东临终时流泪了，武装革命了一辈文化大革命，为什麽有人一听到文革就发 <a href="http://www.szhgh.com/Article/news/politics/2014-03-05/46153.html" class="readmore" title="全国政协委员联名提案呼吁建立"抗日战争胜利纪念碑"" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/news/politics/2014-03-06/46351.html" title="毛新宇提案关注司法腐败" target="_blank" class="pictitle"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2gw1eefloe9jhlj201o01oglf.jpg" /><div>毛新宇</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/news/politics/2014-03-06/46351.html" title="" target="_blank" rel="nofollow">毛新宇提案关注司法腐败</a></h4>
                            <div class="intro">今年对法制建设很重视。我认为维护司法清正廉洁，是遏制我们党和国家腐 <a href="http://www.szhgh.com/Article/news/politics/2014-03-06/46351.html" class="readmore" title="毛新宇提案关注司法腐败" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
                <dl class="left">
                    <dt><a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47083.html" title="刘白驹：建议制定《城市流浪乞讨救助管理细则》" target="_blank" class="pictitle"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2gw1eeflof4j2kj201o01oa9v.jpg" /><div>刘白驹</div></a></dt>
                    <dd>
                        <div class="box">
                            <h4><a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47083.html" title="" target="_blank" rel="nofollow">刘白驹：建议制定《城市流浪乞讨救助管理细则》</a></h4>
                            <div class="intro">毛泽东临终时流泪了，武装革命了一辈文化大革命，为什麽有人一听到文革就发 <a href="http://www.szhgh.com/Article/news/politics/2014-03-14/47083.html" class="readmore" title="刘白驹：建议制定《城市流浪乞讨救助管理细则》" target="_blank" rel="nofollow">[详细]</a></div>                            
                        </div>
                    </dd>
                </dl>
            </div>            
        </div>
    </div>

    <div class="wrap width wrap-5">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/sessions/type37.html" title="视频报道" target="_blank">视频报道</a></div><div class="linebg"></div></div>
        <div class="wrap_content clearfix">
            <div class="left pictitle">
				<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood=4 and cid=37 and b.ispic=1 and ttid=1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
					<a class="zoompic left" href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],320,240,1,'')?>" /><strong><?=$bqr['title']?></strong><div class="titlebg"></div><div class="icovideo"></div></a>
				<?php
}
}
?>
            </div>
            <ul class="right list3"> 
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and cid=37 and b.ispic=1 and ttid=1 order by b.newstime desc limit 8",8,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
				<li>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1">
                        <img src="<?=sys_ResizeImg($bqr[titlepic],150,113,1,'')?>" />
                        <div class="title"><?=$bqr['title']?></div>
                        <div class="opacitybg"></div>
                    </a>
                </li>
				<?php
}
}
?>
            </ul>            
        </div>
    </div>
    
    <div class="cont_pl">
        <div id="plpost" class="pl_list">
            <!-- 评论 -->
            <div id="tosaypl" class="pl section">
               <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
            </div>
            <div class="section_content">
                <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
            </div>
        </div>
    </div>
    
    <!--中间结束-->
    
    
    <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：166238344&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1962727933</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
        });
    </script>
    <!--底部结束-->
    

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=40></script>

</body>
</html>