<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<style>
		html,body, div, span, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, address, code,em, img, q, dl, dt, dd, ol, ul, li, form, label, table, caption, tbody, tfoot, thead, tr, th, td{margin:0;padding:0;}
		img{border:none;}
		li{list-style:none;}
		table{ border-collapse:collapse; width:100%;}
		body{ font-family: Arial,'宋体'; font-size:14px; color:#000; background-color:#FFF;}
		a{ text-decoration:none;color:#000;}
		a:hover{text-decoration:underline;}
		a:active{color:green;}

		.hide{ display:none;}
		.gray-bg{ background-color:#EFEDED;}
		.em{color:#054da1;}
		.cls:after{content:"";display:block;height:0;clear:both;visibility:hidden;}
		.cls{zoom:1;}
		/*---all---*/
		.hd,.bd,.ft{text-align:center;}
		.hd{border-bottom:2px solid #32AF00;background:url(http://www.hao123.com/redian/images/m-hd-main-bg.png) repeat-x;height:89px;}
		.hd-inner{width:960px;margin:0 auto;position:relative;}
		.ft{ text-align:center; color:#999; font-size:12px; margin-top:15px; padding-bottom:15px;}

		.searchfod1 {font-weight: bold; color: #05974c; text-align:center; width:49px; font-size:14px}
		.searchfod2 {cursor: pointer; text-align:center; width:49px; font-size:14px}

		.logo{position:absolute; top:20px; left:0;}
		.m-hd-search{position:absolute; top:42px; left:240px;}
		.m-hd-search_color_gray{ color:#CECECE;}
		.m-hd-search_d{ display:block; background:url(http://www.hao123.com/redian/images/m-hd-search-decorated-bg.png) no-repeat; height:28px; width:2px;}/*d-> decorated*/
		.m-hd-search_text{background:url(http://www.hao123.com/redian/images/m-hd-search-text-bg.png) repeat-x; width:342px; outline:none; padding:7px 0px 6px 7px;border:none; height:28px}
		.m-hd-search_btn{ height:28px; width:95px;background:url(http://www.hao123.com/redian/images/m-hd-search-btn-bg.png) no-repeat; border:none; outline:none; cursor:pointer;}/*btn-button*/
		.m-hd-search_table{ width:auto;}

		.search-list{position:absolute;left:240px;top:20px;}
		.search-list li{float:left;}

		.ft .links{height:24px;}
		.ft .links a{color:#666;}
		.ft .feedback a{color:#0053a5;}
		/*---content---*/
		.main{width:960px;text-align:left;margin:15px auto 0;color:#666;font-size:14px;}
		.topbar{margin:8px 0;font-size:12px;}
		.content{width:958px;border:solid 1px #dfdfe0;border-top:none;}
		.location{float:left;}
		.tool-box{float:right;}
		.set-home,.response,.font{display:inline-block;padding:0 5px 0 20px;background:url(http://www.hao123.com/redian/images/icon.png) no-repeat;}
		.set-home{background-position:0 -40px;}
		.response{background-position:6px -70px;padding-left:24px;}
		.font{background-position:8px -101px;}


		.title-bar .item-content{padding:0 70px 25px;background-color:#f8fafc;height:65px;}
		.title-bar .item-title{height:39px;line-height:38px;font-size:14px;font-weight:bold;background:url(http://www.hao123.com/redian/images/bg_sprites.png) repeat-x;}
		.title-bar .item-inner{padding-top:25px;}
		.title-bar .item-inner-title{margin-bottom:10px;}


		.item{margin-bottom:2px;}
		.item .item-content .item-inner{padding:0 70px 25px;}
		.item .item-intro{height:36px;margin:13px;padding-left:40px;line-height:36px;background-color:#f1f1f1;}
		.item .item-title{display:block;height:42px;line-height:42px;color:#054da1;font-size:14px;}

		.icon-title{display:inline-block;float:left;height:38px;width:45px;background:url(http://www.hao123.com/redian/images/icon.png) no-repeat 13px 8px;}
		/*展开样式*/
		.extend{background:url(http://www.hao123.com/redian/images/bg_title.png) repeat-x 0px 0px;}
		.extend:hover{background-color:#f0f0f0;background-position:0 -72px;}
		.extend .icon-title{background:url(http://www.hao123.com/redian/images/icon_extend.png) no-repeat 11px 9px;}
		.extend:hover .icon-title{background-position:11px -76px;}
		/*收缩样式*/
		.folder{background:url(http://www.hao123.com/redian/images/bg_title.png) repeat-x 0px -141px;}
		.folder:hover{background-color:#f0f0f0;background-position:0 -72px;}
		.folder .icon-title{background:url(http://www.hao123.com/redian/images/icon_extend.png) no-repeat 11px -33px;}
		.folder:hover .icon-title{background-position:11px -120px;}

		.item .item-inner{position:relative;}
		.item .item-inner .down-img{position:absolute;top:5px;right:20px;line-height:41px;}
		.item .item-inner-title{margin-bottom:10px;line-height:34px;}

		a.link-img{display:inline-block;outline:none;text-indent:-999em;height:32px;width:177px;background:url(http://www.hao123.com/redian/images/quick.png) no-repeat 0 7px;}
		a.link-hao123img{display:inline-block;outline:none;text-indent:-999em;height:32px;width:177px;background:url(http://www.hao123.com/redian/images/hao123browser.png) no-repeat 0 1px;}
		/*浏览器icon*/
		.icon-bro{display:inline-block;height:38px;width:27px;float:left;background:url(http://s0.hao123img.com/res/images/icon_browser04.png) no-repeat;}
		.ico-liebao{display:inline-block;height:38px;width:27px;float:left;background:url(http://www.hao123.com/redian/images/liebao.JPG) no-repeat 0 10px;}
        .ico-hao123{display:inline-block;height:38px;width:27px;float:left;background:url(http://www.hao123.com/redian/images/baidu.png) no-repeat 0 10px;}
		.ico-ie{background-position:0 10px;}
		.ico-360{display:inline-block;height:38px;width:27px;float:left;background:url(http://www.hao123.com/redian/images/360.png) no-repeat 0 10px;}
		.ico-360js{background-position:0 -70px;}		
		.ico-aoyou{display:inline-block;height:38px;width:27px;float:left;background:url(http://www.hao123.com/redian/images/aoyou.png) no-repeat 0 10px;}
		.ico-sougou{background-position:0 -151px;}
		.ico-qq{background-position:0 -194px;}
		.ico-tt{background-position:0 -231px;}
		.ico-ff{display:inline-block;height:38px;width:27px;float:left;background:url(http://www.hao123.com/redian/images/huohu2014.png) no-repeat 0 10px;}
		.ico-chrome{background-position:0 -317px;}
		.ico-opera{background-position:0 -357px;}
		.ico-world{background-position:0 -400px;}
		.ico-safari{background-position:0 -440px;}
		.ico-green{background-position:0 -480px;}
                .ico-worldjs{background-position:0 -555px;}
		.ico-kr{background-position:0 -520px;}
		.ico-greenjs{background-position:0 -480px;}
		

	</style>
        <base target="_blank">
        <title>如何在360浏览器、傲游、搜狗等浏览器中设红歌会网址导航为主页 - 红歌会网址导航</title>

</head>
<body>
  <div class="bd">
	<div class="main">
		<div class="content" id="content">
			<div class="title-bar">
				<h3 class="item-title" style="position:relative;"><span class="icon-title"></span>如何在百度浏览器、360、搜狗、谷歌等浏览器中设红歌会网址导航为首页&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如果仍有问题，请<a href="http://www.szhgh.com/e/tool/gbook/?bid=1" style="line-height:15px;position:absolute;top:12px;right:140px;" class="response em">告诉我们</a></h3>
			</div>
			<div class="item">
				<a href="#01" target="_self" name="01" class="item-title extend"><span class="icon-title"></span><span class="icon-bro ico-ie"></span>IE浏览器</a>
				<div style="display: block;" class="item-content">
					
					<div class="item-inner">						
						<div class="item-inner-title">
						  <p>或按照如下方式操作：<br>
						  1、打开IE浏览器，点击菜单里的工具 - Internet选项，如图所示：<br>
						  <img src="http://www.hao123.com/redian/images/sy_21.jpg" class="pcbottom" height="287" width="447"><br>
						  2、选择常规选项， 在地址栏里输入<a class="em" href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>。<br>
						  <img class="pcbottom" src="http://www.hao123.com/redian/images/sy_22.jpg" height="451" width="430"><br>
						  3、点击确定后，重启浏览器后主页就是 hao123 了。</p>
						  <br>
						              <p style=" color:#FF0000"><b>*&nbsp;&nbsp; 如果您的电脑安装了以下安全软件，请点击以下相应链接，查看hao123主页锁定方法。 </b></p>
            <p></p><div><img src="http://www.hao123.com/soft/images/360anquanweishi16.jpg" border="0" height="16px" width="16px">&nbsp;&nbsp;<a href="http://www.hao123.com/redian/360suoding8.0.htm">360安全卫士锁定主页</a></div>
			<div style=" margin-top:4px "><img src="http://www.hao123.com/soft/images/jinshanweishi16.jpg" border="0" height="16px" width="16px">&nbsp;&nbsp;<a href="http://www.hao123.com/redian/jinshansuoding.htm">金山卫士锁定主页</a></div>
			<div style=" margin-top:4px "><img src="http://www.hao123.com/redian/images/qq_anquan_20120417.jpg" border="0" height="16px" width="16px">&nbsp;&nbsp;<a href="http://www.hao123.com/redian/qqsuoding.htm">QQ电脑管家锁定主页</a></div>
			<div style=" margin-top:4px "><img src="http://www.hao123.com/soft/images/jinshanduba16.jpg" style="margin-left:2px" border="0" height="14px" width="14px">&nbsp;&nbsp;<a href="http://www.hao123.com/redian/jinshansheshouye.htm">金山毒霸锁定主页</a></div>
			<p></p>

						</div>	
					</div>
				</div>
			</div>
            <div class="item">
				<a href="#17" target="_self" name="17" class="item-title folder"><span class="icon-title"></span><span class="ico-hao123"></span>百度浏览器(hao123专版浏览器)</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>打开百度浏览器（hao123专版）， 菜单-选项，如图所示：<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/baidusheshou1.JPG" height="300" width="412"><br>
2、点示修改主页，在设置主页内输入<a href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>或点击下面“使用hao123后，确定即可。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/baidusheshou2.JPG" height="384" width="531">
						  <br><br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					  </div>	
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#02" target="_self" name="02" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-360"></span>360浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开浏览器，工具-选项（注意是选项，不是internet选项）<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/360liulanqisheshou1.JPG" height="361" width="432"><br>
2、依次点击，基本设置&mdash;&mdash;主页&mdash;&mdash;输入<a href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>确定后重新打开即可。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/360liulanqisheshou2.JPG" height="210" width="611">
						  <br><br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）在360安全卫士内重新锁定主页。</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					  </div>	
					</div>
				</div>
			</div>

			<div class="item">
				<a href="#03" target="_self" name="03" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-aoyou"></span>傲游浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、	打开傲游浏览器，点右侧菜单-设置，如图所示：<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/aoyousheshou1.JPG" height="424" width="612"><br>
2、在主页设置内添加<a href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>后,删掉其它主页，关闭重新打开即可 ，如下图： <br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/aoyousheshou2.JPG" height="310" width="554"><br>
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
</div>	
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#04" target="_self" name="04" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-sougou"></span>搜狗浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开搜狗浏览器，点击菜单里的工具 - 搜狗高速浏览器选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_5.jpg" height="328" width="465"><br>2、选择常规选项， 在启动设置里选择自定义网址，并输入http://www.hao123.com/ ，点击确定，就可以设定hao123为主页了。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_6.jpg" height="300" width="514"></div>
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#05" target="_self" name="05" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-qq"></span>QQ浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>打开QQ浏览器，点击菜单 &ndash; QQ浏览器选项设置，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/qqliulanqisheshou1.JPG">
<br>2、常规设置-自定义网页内输入<a href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>,点击确定。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/qqliulanqisheshou2.JPG"><br>
</div>	
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#06" target="_self" name="06" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-tt"></span>TT浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开TT浏览器，选择工具 - TT选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_9.jpg" height="331" width="535"><br>2、选择启动和退出，输入http://www.hao123.com/ 为主页，勾选启动时打开主页。最后别忘了点击保存按钮。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_10.jpg" height="502" width="580"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#ff" target="_self" name="ff" id="ff" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-ff"></span>Firefox浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、1、	打开浏览器，选择菜单工具 - 选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/firefoxsheshou1.JPG" height="325" width="553"><br>2、选择常规，依次选择显示我的主页；输入http://www.hao123.com/主页地址，点击确定。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/firefoxsheshou2.JPG" height="489" width="589"></div>	
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
                            <li>（2）查看是否扩展插件影响： 菜单-附加组件-扩展内禁用相关插件测试</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#08" target="_self" name="08" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-chrome"></span>Chrome浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开谷歌浏览器-点右上角小扳手-设置，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_13_0522.jpg" height="523" width="501"><br>2、外观内-勾选 显示主页按钮-点更改<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_14_0522.jpg" height="180" width="368"><br>3、在打开此页后输入 www.hao123.com 确定即可。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/sy_15_0522.jpg" height="176" width="403"></div>	
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#13" target="_self" name="13" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-360js"></span>360极速浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开360极速浏览器-点击小扳手-选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/360js_1.jpg" height="373" width="553"><br>2、基本设置-打开此页里输入<a class="em" href="http://hao.szhgh.com/"> http://hao.szhgh.com/ </a>，宽屏版为<a class="em" href="http://www.hao123.com/indexk.html"> http://www.hao123.com/indexk.html </a> 。 <br><img class="pcbottom" src="http://www.hao123.com/redian/images/360js_2.jpg" height="373" width="553"><br>3、输入完以后,关闭浏览器,重新打开即可。</div>	
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>						
			<div class="item">
				<a href="#14" target="_self" name="14" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-worldjs"></span>世界之窗极速版浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开浏览器，然后选择工具 - 选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/world-11101001.jpg" height="440" width="372"><br>
						  2、选择基本设置，选择“打开主页”，并把主页设置为www.hao123.com，就可以了

。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/world-11101002.jpg" height="418" width="668"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			
			<div class="item">
				<a href="#16" target="_self" name="16" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-liebao"></span>猎豹浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开猎豹浏览器输入并访问 <a href="http://www.hao123.com">www.hao123.com</a>后，点击左上角豹头&gt;&gt;选项<br><img class="pcbottom" src="http://www.hao123.com/redian/images/liebao01.JPG" height="550" width="786"><br>
						  2、基本设置&gt;&gt;打开主页&gt;&gt;使用当前已打开网页，关闭即可。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/liebao02.JPG" height="607" width="785"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			
			<div class="item">
				<a href="#09" target="_self" name="09" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-opera"></span>Opera浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、1.	打开opera浏览器-左上角菜单-设置-首选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/opera-11101001.jpg" height="515" width="554"><br>
						  2、常规-启动内选择-打开主页,主页内输入<a href="http://www.hao123.com">www.hao123.com</a>。最后确定保存就可以了。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/opera-11101002.jpg" height="410" width="554"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#10" target="_self" name="10" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-world"></span>世界之窗浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：1、打开浏览器，选择菜单 &ndash; 设置，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/shijiezhichuangsheshou1.JPG" height="440" width="372"><br>
						  2、选择常规设置，点击设置网页-输入<a href="http://www.hao123.com">www.hao123.com</a>，确定。 <br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/shijiezhichuangsheshou2.JPG" height="418" width="668"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#11" target="_self" name="11" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-safari"></span>Safari浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开浏览器-菜单-偏好设置，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/safarisheshou1.JPG" height="354" width="554"><br>
						  2、常规-主页内输入<a href="http://www.hao123.com">www.hao123.com</a>,关闭即可 。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/safarisheshou2.JPG" height="432" width="554"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			<div class="item">
				<a href="#12" target="_self" name="12" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-green"></span>绿色浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开绿色浏览器-工具-GREENBROWSER选项，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/green-11101001.jpg" height="446" width="553"><br>2、常规-启动/退出-自定义主页内输入 www.hao123.com 确定即可。<br><img class="pcbottom" src="http://www.hao123.com/redian/images/green-11101002.jpg" height="441" width="576"></div>	
												  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
			</div>
			
<div class="item">
				<a href="#15" target="_self" name="15" class="item-title folder"><span class="icon-title"></span><span class="icon-bro ico-kr"></span>KR浏览器</a>
				<div style="display: none;" class="item-content">
					
					<div class="item-inner">
						<div class="item-inner-title">或按照如下方式操作：<br>1、打开KR浏览器-工具-修改主页，如图所示：<br><img class="pcbottom" src="http://www.hao123.com/redian/images/kr-11101001.jpg" height="392" width="554"><br>
						  2、在当前主页内输入 www.hao123.com 确定即可。<br>
<img class="pcbottom" src="http://www.hao123.com/redian/images/kr-11101002.jpg" height="186" width="369"></div>	
						  <br>
						  <p style=" color:#FF0000"><b>*&nbsp;&nbsp;如仍然无法解决，请参考以下方法:</b></p>
						  <ul>
                            <li>（1）用杀毒软件、安全软件查杀病毒木马后重新启动电脑</li>
                            <li>（2）删掉桌面浏览器快捷方式后，重新创建快捷方式（开始程序-浏览器上右键-发送到桌面快捷方式）</li>
					      </ul>
					</div>
				</div>
		  </div>

		</div>
	</div>
  </div>
<div class="ft">
   <div class="feedback">&copy;2014 红歌会网&nbsp;&nbsp;<a href="http://feedback.hao123.com/?catalog_id=3">反馈</a></div>
</div>
<div style="display: none;"></div>
</body>

</html>