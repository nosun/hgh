<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>纪念毛主席诞辰120周年 - 红歌会网</title>
    <meta name="keywords" content="" />
    <meta name="description" content="导言：对于爱他的人来说，他是希望和明灯。对于恨他的人来说，他是梦魇和灾难。毛泽东！一个响亮的名字，一个永恒的话题。哪里有腐朽和落没，哪里有丑陋和肮脏，哪里有黑暗和不公，哪里有剥削和压迫，哪里就呼唤着他的名字，显现着他的身影。这些年来，他一刻也没有远去，反倒离我们越来越近。当这个社会重现“百年魔怪舞翩跹”时，当那些土豪劣绅、贪官污吏经过短暂沉寂又开始扬眉吐气，横行无阻时，当黄、赌、毒等社会恶疾重新蔓延肆虐时，当资本与权贵勾结无恶不作时，当弱肉强食变的理所当然时，当道德和良知无法彰显时，越来越多的人开始选择毛泽东思想。而这种选择，正在汇聚成“敢叫日月换新天”滚滚洪流。" />
    <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
    <link href="http://www.szhgh.com/skin/default/css/topic_mao120.css" rel="stylesheet" type="text/css" />
    <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="http://www.szhgh.com/e/data/js/ajax.js"></script>
    <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
    <!--[if !IE]>|xGv00|ef6f6f4cf55337e8218c7e4915dd8658<![endif]-->
    <script>
    function setTab(name,cursel,n){
            for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
            }
    }
    function change(id){
            if (typeof(isround)!='undefined') clearTimeout(isround);
            var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
            var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
            var text = document.getElementById("focus_text").getElementsByTagName("li");
            for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
            }
            bigimg[id-1].className="dis";
            smallimg[id-1].className="current";
            text[id-1].className="dis";
            if ((next=id+1) > smallimg.length) next = 1;
            isround=setTimeout('change('+next+')', 5000);
    }
    </script>
</head>
<?
        $ztid=38;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
        $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);
        
        $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
?>
<body closepl="<?=$zt_r['closepl']?>">
    <!--头部开始-->
    <div class="header">
        <div class="hea_1 clearfix">
            <div class="pleft">
                <div class="hea_logo pleft"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></div>
                <ul class="pleft">
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                </ul>                
            </div>
            <div class="account pright">
                <script>
                    document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                </script>
            </div>
        </div>
    </div>
    <div class="hea_2">
        <p><img src="http://img3.wyzxwk.com/topic/mao120/banner.jpg" width="1000" height="200" /></p>
    </div>
        <div class="hea_3">
            <ul>
                <?
                $ztpath = $public_r['newsurl'].$zt_r['ztpath'];
                $sql = "select cid,cname,ttype from {$dbtbpre}enewszttype where ztid=$ztid order by myorder ASC";
                $result=$empire->query($sql);    //根据专题id从“专题子类主表”查询出“专题子类id”和“专题子类名称”；
                while($r=$empire->fetch($result)) {       //循环获取查询记录到数组$r,并循环输出子类信息列表
                $cid=$r['cid'];
                $zttypepath = $ztpath.'/type'.$r['cid'].$r['ttype']
                ?>
                <li><a href="<?=$zttypepath?>" target="_blank" title="<?=$r['cname']?>"><?=$r['cname']?></a></li>
                <?
                }
                ?>
            </ul>
        </div>

    <!--头部结束-->
    <!--中间开始-->
    <div class="cont">
        <div class="daoy pad_t">导言：对于爱他的人来说，他是希望和明灯。对于恨他的人来说，他是梦魇和灾难。毛泽东！一个响亮的名字，一个永恒的话题。哪里有腐朽和落没，哪里有丑陋和肮脏，哪里有黑暗和不公，哪里有剥削和压迫，哪里就呼唤着他的名字，显现着他的身影。这些年来，他一刻也没有远去，反倒离我们越来越近。当这个社会重现“百年魔怪舞翩跹”时，当那些土豪劣绅、贪官污吏经过短暂沉寂又开始扬眉吐气，横行无阻时，当黄、赌、毒等社会恶疾重新蔓延肆虐时，当资本与权贵勾结无恶不作时，当弱肉强食变的理所当然时，当道德和良知无法彰显时，越来越多的人开始选择毛泽东思想。而这种选择，正在汇聚成“敢叫日月换新天”滚滚洪流。</div>
    </div>

    <div class="cont">
        <div class="le_1">
            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 order by newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
            <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],52)?></a></h2>
            <div class="smalltext"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;<a href="<?=$bqsr['titleurl']?>" title="点击查看详情" target="_blank">[评细]</a></div>
            <?php
}
}
?>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>=1 and isgood<4 order by newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>					
            </ul>
        </div>

        <div class="ri_1">
            <div id=focus_pic class=right>
                <div id=focus_big>
                    <ul>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li class="<?if($bqno===1){echo 'dis';}else{echo 'undis';}?>"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><img title="<?=$bqr['title']?>" src="<?=$bqr['titlepic']?>" /></a></li>
                        <?php
}
}
?>	
                    </ul>
                    <div id=focus_text_bg></div>
                    <div id=focus_text>
                        <ul>
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li class="<?if($bqno===1){echo 'dis';}else{echo 'undis';}?>"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><?=$bqr['title']?></a></li>
                            <?php
}
}
?>	
                        </ul>
                    </div>
                </div>
                <div id=focus_tip>
                    <ul>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>2 and b.ispic=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li class="current" onmouseover=change(<?=$bqno?>);><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target=_blank><img title="<?=$bqr['title']?>" src="<?=sys_ResizeImg($bqr[titlepic],120,90,1,'')?>" /></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
                <script>
                    var isround = setTimeout("change(2)",2500);
                </script>
            </div>
        </div>
    </div>

    <div class="cont">
        <div class="le_2">
            <h3 class="h3"><a href="http://www.szhgh.com/s/mzd120/type21.html" title="纪念活动" target="_blank">纪念活动</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(21,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
        <div class="le_2">
            <h3 class="h3"><a href="http://www.szhgh.com/s/mzd120/type22.html" title="怀念追思" target="_blank">怀念追思</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(22,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],40)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
        <div class="le_2 le_2a">
            <h3 class="h3"><a href="http://www.szhgh.com/s/mzd120/type26.html" title="评述毛泽东" target="_blank">评述毛泽东</a></h3>
            <ul class="list">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(26,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],36)?></a></li>
                <?php
}
}
?>
            </ul>
        </div>
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2><a href="http://www.szhgh.com/s/mzd120/type28.html" title="精彩图集" target="_blank">精彩图集</a></h2>
            <div class="cont_1a clearfix">
                <ul id="flexisel_live0">
                  <!-- 图片列表 begin -->
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(28,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=$bqr['titlepic']?>" width="200" height="150" title="<?=$bqr['title']?>" style="cursor:pointer;" /></a> 
                        <div class="title"><a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></div> 
                    </li>
                    <?php
}
}
?>
                  <!-- 图片列表 end -->
                </ul>
                <script language="javascript" type="text/javascript">
                    $("#flexisel_live0").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,            
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: { 
                            portrait: { 
                                changePoint:480,
                                visibleItems: 1
                            }, 
                            landscape: { 
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: { 
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });
                </script>
            </div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>立志篇：埋骨何须桑梓地，人生无处不青山</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">青年人求学，大多喜欢谈立志，诸如将来要当军事家、政治家、教育家等。毛泽东认为，离开真理来谈立志，只是对前人中有成就者的简单模仿。真正的立志，首先是寻找真理，然后按它去做，若“十年未得真理，即十年无志；终身未得，即终身无志”一九一五年九月，在给好朋友萧子升的信中，他提出有“为人之学”、“为国人之学”、“为世界人之学”。这以前不久，他在另一封信中说：“齑其躬（意思是：即便自己粉身碎骨）而有益于国与群，仁人君子所欲为也。”</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-13/39578.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg152t93j208r06kq2z.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40040.html" target="_blank" title="少年立志出乡关">少年立志出乡关</a></h4>
                    <span>一九一○年四月，长沙发生了饥民暴动。起因是荒年粮价飞涨，有人率全家投塘自尽。饥民们涌到巡抚衙门请愿，反而遭到枪击，当场打死十四人，打伤的更多。他们在忍无可忍的情况下，放火烧了巡抚衙门，捣毁了外国洋行…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40040.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40044.html" target="_blank" title="求学之路——师范生毛泽东">求学之路——师范生毛泽东</a></h4>
                    <span>在毛泽东周围，逐渐聚集起一批追求进步、志同道合的青年。他们大多是杨昌济的学生，都有一种“奋斗的和向上的人生观”。他们多来自农村，了解民间疾苦，充满着以天下为己任的社会责任感…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40044.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-13/39591.html" target="_blank" title="毛泽东——叛逆的少年时代">毛泽东——叛逆的少年时代</a></h4>
                    <span>天亮后不久，泽东就出了韶山。这是一个凉爽的金秋的早晨。肩上还是那根用惯了的扁担，但两头挑的不是粪筐。一头是一个包袱，里面装着一件长袍、两条床单和一顶蚊帐;另一头是装有《水浒传》和《三国演义》的筐子…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-13/39591.html" target="_blank">评细</a>]</span>	
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40085.html" target="_blank" title="五四大潮的洗礼">五四大潮的洗礼</a></h4>
                    <span>从十月革命和五四运动的历史实际中，他开始看到过去他没有发现的人民大众显示出来的巨大力量，开始觉得许多人虽然“办了些教育，却无甚效力”，从而明确提出实行社会改造的“根本的一个方法，就是民众的大联合”…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40085.html" target="_blank">评细</a>]</span>		
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40050.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg15jqnoj205k0460sr.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40050.html" target="_blank" title="携手杨开慧—建党初期的毛泽东">携手杨开慧—建党初期的毛泽东 </a></h4>
                    <span>这是一次年轻人的会议。最年长的何叔衡不过四十五岁，最年轻的刘仁静只有十九岁。十五位与会者的平均年龄二十八岁，正巧是毛泽东的年龄。以后改变整个中国面貌的中国共产党，最初就是由这样一些年轻人成立起来的…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40050.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40092.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1600adj205k046wem.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40092.html" target="_blank" title="电影:烈火中永生">走向农民运动</a></h4>
                    <span>当时党内的第一种倾向，以陈独秀为代表，只注意同国民党合作，忘记了农民，这是右倾机会主义。第二种倾向，以张国焘为代表，只注意工人运动，同样忘记了农民，这是‘左’倾机会主义。这两种机会主义都感觉自己力量不足，而不知道…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40092.html">评细</a>]</span>
                </div>
            </div>
            <div class="ov pad">
                <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40044.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg16ajaoj205k046wef.jpg" width="200" height="150" border="0"class="pad_le" /></a>
                <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-13/39591.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg17o3utj205k046a9z.jpg" width="200" height="150" border="0" class="pad_le" /></a>
                <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40050.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg17x0xrj205k046jrf.jpg" width="200" height="150" border="0"class="pad_le"  /></a>
                <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/40040.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg187wl6j205k0463yf.jpg" width="200" height="150" border="0"class="pad_le"  /></a>
            </div>
            <div class="cl"></div>
        </div>
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>革命篇：为有牺牲多壮士，敢叫日月换新天</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">在一些公知和精英看来，革命就是杀戮、流血、牺牲、内斗、兄弟相残、父子反目、骨肉分离、中国人打中国人。但对于广大的无产阶级群众来说，革命是百万农奴大翻身，从此当家作主人。是几亿农民拥有自己的土地，实现千年梦想。是工人成为工厂的主人，不用担心失业，不会沦为包身工，不会惨死黑砖窑和黑煤矿。是妇女不再需要出卖肉体，是儿童不再会沦为童工，是老人不再流落街头。是没有朱门酒肉臭，路有冻死骨的社会不公。是全国只有极少数人上学识字，到绝大多数人口都能受到教育。是全国人口平均寿命从革命前的三十多岁，迅速上升到七十多岁。你可以说毛泽东共产党饿死了三千万，但你却无法解释中国人口，从革命前蒋介石统治下二十多年，一直徘徊在四亿多，但在革命后毛泽东统治二十多年，爆发式增长到七亿多。什么是革命，这就是革命！</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/38186.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg18sblrj208r06kjrv.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40108.html" target="_blank" title="霹雳一声暴动">霹雳一声暴动</a></h4>
                    <span>我是一个知识分子，当一个小学教员，也没学过军事，怎么知道打仗呢?就是由于国民党搞白色恐怖，把工会、农会都打掉了，把五万共产党员杀了一大批，抓了一大批，我们才拿起枪来，上山打游击。…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-19/40108.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40111.html" target="_blank" title="纪录片:长征">纪录片:长征</a></h4>
                    <span>毛泽东登上六盘山顶峰时，心潮澎湃，写下了《清平乐?六盘山》词：天高云淡，望断南飞雁。不到长城非好汉，屈指行程二万。六盘山上高峰，红旗漫卷西风。今日长缨在手，何时缚住苍龙?…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40111.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40110.html" target="_blank" title="星星之火，可以燎原">星星之火，可以燎原</a></h4>
                    <span>伴随着帝国主义和中国民族工业的矛盾而来的，是中国民族工业得不到帝国主义的让步的事实，这就发展了中国资产阶级和中国工人阶级之间的矛盾，中国资本家从拚命压榨工人找出路，中国工人则给以抵抗…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40110.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201310/35347.html" target="_blank" title="重温毛主席所作老三篇">重温毛主席所作老三篇</a></h4>
                    <span>旧世界有三个大矛盾：第一个是帝国主义国家中的无产阶级和资产阶级的矛盾，第二个是帝国主义国家之间的矛盾，第三个是殖民地半殖民地国家和帝国主义宗主国之间的矛盾。这三种矛 盾不但依然存在…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201310/35347.html" target="_blank">评细</a>]</span>		
                </div>
            </div>
            <div class="mar_b"></div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/38186.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg19emuij205k046dfs.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/38186.html" target="_blank" title="毛泽东1938年在中央党校讲话稿全文首次发表">毛泽东1938年在中央党校讲话</a></h4>
                    <span>你们在学校已经学了马克思主义，将来继续学习，向工人学，向农民学，向知识分子学。还要向资本家学，就是研究资本家如何剥削的一套;还要向土豪劣绅学习，他们的鬼鬼怪怪要研究一下，他们为什么能富，为什么能讨小…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/38186.html">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg19teenj205k04674e.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html" target="_blank" title="毛泽东:在延安文艺座谈会上的讲话">毛泽东:在延安文艺座谈会上的讲话全文</a></h4>
                    <span>文艺是为资产阶级的，这是资产阶级的文艺。像鲁迅所批评的梁实秋一类人，他们虽然在口头上提出什么文艺是超阶级的，但是他们在实际上是主张资产阶级的文艺，反对无产阶级的文艺的。文艺是为帝国主义者的，周作人、张资平…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/21667.html">评细</a>]</span>
                </div>
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40132.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1azbgcj205k0460sq.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40132.html" target="_blank" title="中国革命战争的战略问题">中国革命战争的战略问题</a></h4>
                    <span>只有无产阶级和共产党能够领导农民、城市小资产阶级和资产阶级，克服农民和小资产阶级的狭隘性，克服失业者群的破坏性，并且还能够克服资产阶级的动摇和不彻底性(如果共产党的政策不犯错误的话)，而使革命和战争走上胜利的道路。…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-19/40132.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/16874.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1bmngbj205k0460sw.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/16874.html" target="_blank" title="1949年新年献词：《将革命进行到底》">1949年新年献词：《将革命进行到底》</a></h4>
                    <span>一九四九年将要召集没有反动分子参加的以完成人民革命任务为目标的政治协商会议，宣告中华人民共和国的成立，并组成共和国的中央政府。这个政府将是一个在中国共产党领导之下的、有各民主党派各人民团体的适当的代表人物参加…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/16874.html">评细</a>]</span>
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39838.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1c8rbcj205k046glo.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/1252.html" target="_blank" title="孔庆东讲座视频：生生死死九十年">孔庆东讲座视频：生生死死九十年</a></h4>
                    <span>抗日战争为什么这么难打?今天歌颂国民党抗战甚嚣尘上。国民党抗战如果抗得好的话，用抗八年吗?广大国民党下层官兵是有英勇抗战的事实，国民党的将令也有抗战的，不乏其人，但整个国民党的抗战路线是投降、逃跑路线，是“反共…[<a href="http://www.szhgh.com/Article/wsds/history/1252.html">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/opinion/xuezhe/2013-12-16/39818.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1d5t2ij205k04674d.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/opinion/xuezhe/2013-12-16/39818.html" target="_blank" title="老田：共产党领导人民“革命有理”">老田：共产党领导人民“革命有理”</a></h4>
                    <span>在精英们越来越多地攻击中国革命和真正的共产党人的事业的时候，人民群众会越来越多地想起毛泽东和解放这样的词汇。在精英们告别革命并清算革命“罪恶”一直清算到法国大革命头上的时候,底层民众越来越认……[<a href="http://www.szhgh.com/Article/opinion/xuezhe/2013-12-16/39818.html">评细</a>]</span>
                </div>
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39838.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg14lrncj205k046aa6.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39838.html" target="_blank" title="【芭蕾舞剧】 红色娘子军">【芭蕾舞剧】 红色娘子军</a></h4>
                    <span>该剧以第二次国内革命战争时期海南红色娘子军的斗争业绩为素材，围绕吴琼花从奴隶成长为共产主义战士的经历，表现了旧社会妇女在中国共产党的领导下，为自由而战、为妇女解放而战的革命精神和英雄气节…[<a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39838.html">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.m1905.com/vod/play/85678.shtml?__hz=d9fc5b73a8d78fad#guessYouLike" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg13segsj205k0460sv.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.m1905.com/vod/play/85678.shtml?__hz=d9fc5b73a8d78fad#guessYouLike" target="_blank" title="电影:烈火中永生">电影:烈火中永生</a></h4>
                    <span>本片根据罗广斌、杨益言所著的红色经典小说《红岩》改编;影片以许云峰、江姐的斗争活动为中心，表现出当时艰难的地下革命斗争和严酷的狱中斗争的情景，以及身陷囹圄的共产党人坚贞不屈的革命信念和献身精神。…[<a href="http://www.m1905.com/vod/play/85678.shtml?__hz=d9fc5b73a8d78fad#guessYouLike">评细</a>]</span>
                </div>
            </div>
            <div class="cl"></div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>建国篇：春风杨柳万千条，六亿神州尽舜尧</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">自从中国人学会了马克思列宁主义以后，中国人在精神上就由被动转入主动。从这时起，近代世界历史上那种看不起中国人，看不起中国文化的时代应当完结了。伟大的胜利的中国人民解放战争和人民大革命，已经复兴了并正在复兴着伟大的中国人民的文化。</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/201310/33258.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1eezzgj208r06kt94.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/201311/37158.html" target="_blank" title="孔庆东发表专文纪念毛主席诞辰120周年">孔庆东发表专文纪念毛主席诞辰120周年</a></h4>
                    <span>文艺是为资产阶级的，这是资产阶级的文艺。像鲁迅所批评的梁实秋一类人，他们虽然在口头上提出什么文艺是超阶级的，但是他们在实际上是主张资产阶级的文艺，反对无产阶级的文艺的…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/201311/37158.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-17/39893.html" target="_blank" title="毛主席险棋：回眸中苏核战或将爆发前">毛主席险棋：回眸中苏核战或将爆发前</a></h4>
                    <span>毛泽东在说“原子弹是纸老虎”后，并未看轻原子弹，而是调集精兵强将去占领两弹的制高点。1964年，中国便有了原子弹和运载导弹，1967年又有了氢弹。至此时，没有人可以再挥舞着原子弹对中国进行恫吓了…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-17/39893.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/201310/35405.html" target="_blank" title="中央党校原副校长李君如：民族英雄--毛泽东">中央党校原副校长李君如：民族英雄--毛泽东</a></h4>
                    <span>毛泽东在处理与社会主义国家和资本主义国家关系的时候，既坚持意识形态斗争的基本原则，又不拘泥于一成不变的意识形态公式，社会主义国家的政策伤害了我们的国家利益他敢于斗，资本主义国家的政策有利于…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/201310/35405.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/26145.html" target="_blank" title="毛主席谈抗美援朝">毛主席谈抗美援朝</a></h4>
                    <span>毛主席说：“时间要打多久，我想我们不要做决定。过去是由杜鲁门，以后是由艾森豪威尔，还是以后由美国的什么总统，他们去做决定。他们要打多久，我们就打多久，一直打到完全胜利为止。”…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/26145.html" target="_blank">评细</a>]</span>			
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/201310/33258.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1eqjqsj205k046wek.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/201310/33258.html" target="_blank" title="1949年毛主席主持开国大典实况录像">1949年毛主席主持开国大典实况录像</a></h4>
                    <span>不循常规的性格。“有虎气也有猴气”，这是毛泽东对自己性格的评价。前者表现为权威、霸气、豪放、严厉、庄重，后者表现为即兴随意，浪漫洒脱，不拘成规，灵活多变。正因为他的这种性格，在重大关头才有了惊世骇俗之举，如四渡…[<a href="http://www.szhgh.com/Article/wsds/wenyi/22778.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/wsds/wenyi/22778.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg1fdc31j205k046weg.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/13292.html" target="_blank" title="纪录片:《走近毛泽东》">纪录片:《走近毛泽东》</a></h4>
                    <span>不循常规的性格。“有虎气也有猴气”，这是毛泽东对自己性格的评价。前者表现为权威、霸气、豪放、严厉、庄重，后者表现为即兴随意，浪漫洒脱，不拘成规，灵活多变。正因为他的这种性格，在重大关头才有了惊世骇俗之举，如四渡…[<a href="http://www.szhgh.com/Article/wsds/wenyi/22778.html" target="_blank">评细</a>]</span>
                </div>

                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39835.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg1fnuz0j205k046jrj.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39835.html" target="_blank" title="音乐舞蹈史诗《东方红》">音乐舞蹈史诗《东方红》</a></h4>
                    <span>整个大歌舞的演出，是一部中国革命的颂歌，毛泽东思想的颂歌。从第一场《东方的曙光》中升起红旗开始，每一场都鲜明地反映了毛泽东思想在中国革命和建设的过程中所产生的巨大的历史作用。当天幕上出现作为中国革命历史转折点的遵义…[<a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-16/39835.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/wsds/wenyi/2013-12-17/39890.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1fxhb8j205k046weg.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/wsds/wenyi/2013-12-17/39890.html" target="_blank" title="《百花争艳》1975年中国艺术团演出">《百花争艳》1975年中国艺术团演出</a></h4>
                    <span>影片选录了中国艺术团演出的主要节目：京剧《红灯记》，舞剧《白毛女》、《红色娘子军》的选段、选曲的演唱或演奏，鼓乐合奏《渔舟凯歌》，琵琶演奏《十面埋伏》，板胡独奏《大起板》、《庆翻身》，笙独奏《大寨红花遍地开》…[<a href="http://www.szhgh.com/Article/wsds/wenyi/2013-12-17/39890.html">评细</a>]</span>
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/wsds/history/1331.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1gjv91j205k0463yn.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/1331.html" target="_blank" title="集体化时期农村合作医疗制度评析">集体化时期农村合作医疗制度评析</a></h4>
                    <span>集体化时期的合作医疗制度始终坚持缓解农村医疗困境的大方向，通过发挥集体经济的优势、进行医务人员“在地化”培训以及坚持“预防为主”等方式，让有史以来人数最多的农民有了制度化的健康保障，充分体现了社会主义制度的优越性…[<a href="http://www.szhgh.com/Article/wsds/history/1331.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/201311/36873.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1gwi90j205k046q2z.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/201311/36873.html" target="_blank" title="视频:毛泽东另类工业化道路思想再回顾">视频:毛泽东另类工业化道路思想再回顾</a></h4>
                    <span>毛泽东讲的大跃进，是说中国要尽量采用先进技术，快速推进中国的工业化进程，在一个不太长的时间内就主要工业品产量赶上或者超过英国，从毛泽东时代的经济发展进程看，随后二十多年确实是以毛泽东提出的发展目标来安排中国稀缺资源…[<a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/201311/36873.html">评细</a>]</span>
                </div>
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/wsds/history/8928.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg1h9lu0j205k046mx7.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/8928.html" target="_blank" title="视频：农业学大寨—陈永贵">视频：农业学大寨—陈永贵</a></h4>
                    <span>我这一辈子能够和毛主席连在一起，也算是不枉活了一场了。人是注定要死的，我没有给毛主席丢脸。我作为一个农民，成为党中央的政治局委员，谁能想到呢？我敢说，我是前无古人，后无来者的一个农民。今后，再也不会有毛主席那样…[<a href="http://www.szhgh.com/Article/wsds/history/8928.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/html/47/n-21247.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1hj7rtj205k046gll.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/html/47/n-21247.html" target="_blank" title="全面理解雷锋精神，继承雷锋未竟事业">全面理解雷锋精神，继承雷锋未竟事业</a></h4>
                    <span>“对待同志要像春天般温暖,对待工作要像夏天一样火热,对待个人主义要像秋风扫落叶一样,对待阶级敌人要像严冬一样残酷无情。”雷锋精神是带有阶级性的，他是爱憎分明的。雷锋是和阶级，阶级斗争，革命，共产主义联系在一起的[<a href="http://www.szhgh.com/html/47/n-21247.html">评细</a>]</span>
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-17/39940.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg1hvgmaj205k046t8p.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-17/39940.html" target="_blank" title="1971年，毛泽东的外交大反攻">1971年，毛泽东的外交大反攻</a></h4>
                    <span>1970年12月18日，毛泽东颇为悠然自得地对埃德加 斯诺说：“一九七二年美国要大选，这年的上半年，尼克松可能派人来。”令人疑惑的关节点在于：彼时是1970年底，距离乒乓外交还有三个月。那么，是什么使得毛泽东胸有成竹地预见到…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-17/39940.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/17148.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1ihk04j205k046aa2.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/17148.html" target="_blank" title="毛泽东与中国第一颗原子弹爆炸">毛泽东与中国第一颗原子弹爆炸</a></h4>
                    <span>1961年深冬，在中南海怀仁堂召开了一次由中央军委的老总们和国务院一些部门领导出席的不寻常的会议，讨论中国核导弹工业的建设和发展问题，实际就是中国还有没有能力、要不要马上发展导弹核武器。会议由刘少奇主持，周恩来…[<a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/17148.html">评细</a>]</span>
                </div>
            </div>
            <div class="cl"></div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2>济世篇：如今天下红遍， 江山靠谁守？</h2>
            <div class="cl"></div>
            <div class="daoy pad_t">毛泽东临终时流泪了，武装革命了一辈子，他仍想要文化大革命。为什麽要搞文化大革命，那是剿灭世人心魔的最后努力。很多革命者已经无法理解了，革命到最后革到自己头上了。为什麽有人一听到文革就发抖，那是他们心中的魔鬼在颤栗。然而，人间正道是沧桑，宿业如山难净除，世人再入轮回何尝不是一种修行。</div>
            <div class="ov">
                <div class="le_3"><a href="http://www.szhgh.com/html/04/n-24204.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1jq21gj208r06kjrk.jpg" width="315" height="236" border="0" /></a></div>
                <div class="le_3">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39983.html" target="_blank" title="一支清荷：历史书上没有的文革史">一支清荷：历史书上没有的文革史</a></h4>
                    <span>文革需要实事求是地展现，而不是简单粗暴地被定性成一个笼统的结论。这不仅是对文革负责，更是对历史负责，是对人民负责。文革是属于我们国史不可分割的一部分。毕竟彻底否定文革，就会使后人无法正确理解党的历史…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39983.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/html/04/n-24204.html" target="_blank" title="党刊刊发李慎明重磅文章,全面为毛泽东辩护">党刊刊发李慎明重磅文章,为毛泽东辩护</a></h4>
                    <span>国际共产主义运动历史经验反复证明，要搞垮一个社会主义国家，首先就要攻击这个国家执政的共产党；要搞垮这个国家执政的共产党，首先就要丑化这个执政党的主要领袖。这是国内外敌对势力企图西化、分化我们的最直接…[<a href="http://www.szhgh.com/html/04/n-24204.html" target="_blank">评细</a>]</span>			
                </div>
                <div class="le_3 le_2a">
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-18/39986.html" target="_blank" title="毛泽东七十三岁生日与王力关于文革的重要谈话">毛泽东七十三岁生日与王力关于文革的重要谈话</a></h4>
                    <span>毛主席说是抓革命才能促进生产，人的思想革命化了，才能解决生产的方向道路问题，才能把妨碍生产力发展的旧的框框搞掉，搞出一套新的规章制度，才能推动生产力的发展。毛主席说，有人借口抓生产来压革命…[<a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/2013-12-18/39986.html" target="_blank">评细</a>]</span>
                    <h4 class="pad"><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39993.html" target="_blank" title="老田:为什么毛泽东无需精英们的“公正对待”">老田:为什么毛泽东无需精英们的“公正对待”</a></h4>
                    <span>从人类历史记录看，还没有一个人对于统治阶级的剥夺像毛泽东那样彻底，也没有出现过毛时代那样一种精英阶层权力利益最小化的社会，毛泽东对于精英阶层权力和利益要求不仅体现在思想理论上，而且直接贯彻到社会实践…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39993.html" target="_blank">评细</a>]</span>			
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/37375.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1keneuj205k046dfv.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/xuexi/201311/37375.html" target="_blank" title="经济学雄文：毛泽东《论十大关系》">经济学雄文：毛泽东《论十大关系》</a></h4>
                    <span>重工业是我国建设的重点。必须优先发展生产资料的生产，这是已经定了的。但是决不可以因此忽视生活资料尤其是粮食的生产。如果没有足够的粮食和其他生活必需品,首先就不能养活工人，还谈什么发展重工业?所以，重工业和轻工业…[<a href="http://www.szhgh.com/Article/wsds/wenyi/22778.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/wsds/history/201309/31511.html" target="_blank"><img src="http://ww1.sinaimg.cn/mw690/98fe75a2jw1ebtg1l8ajcj205k046jrl.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/wsds/history/201309/31511.html" target="_blank" title="毛泽东：搞一辈子革命，却搞了资本主义，怎么行？">毛泽东：官僚主义的二十种表现</a></h4>
                    <span>第一种，高高在上，孤陋寡闻，不了解下情，不调查研究，不抓具体政策，不做政治思想工作，脱离群众，脱离实际，一旦发号施令，必将误国误民。这是脱离领导、脱离群众的官僚主义。第二种，狂妄自大，骄傲自满;主观片面，粗枝大叶…[<a href="http://www.szhgh.com/Article/wsds/history/201309/31511.html" target="_blank">评细</a>]</span>
                </div>
            </div>
            <div class="ov">
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39997.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1k1foyj205k0463yi.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39997.html" target="_blank" title="电影：金光大道">电影：金光大道</a></h4>
                    <span>  《金光大道》是当代文学史上一部曾经无限辉煌此后又备受非议、至今仍存在争议的作品，也是一部被时代的浮云遮掩了光芒，被狭隘的政治偏见所歧视、并被经常误读和曲解的作品，更是一切仇视共产党和社会主义制度的邪恶势力恨得要死…[<a href="http://www.szhgh.com/Article/red-china/mzd/pingshu/2013-12-18/39997.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/2013-12-18/39999.html" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1ebtg1lp4itj205k046t8r.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/2013-12-18/39999.html" target="_blank" title="电影:《艳阳天》1973年 ">电影:《艳阳天》1973年 </a></h4>
                    <span>1956年秋，东山坞农业合作社遭受了一场严重的自然灾害。民兵排长肖长春带领广大群众决心克服一切困难，通过生产自救战胜灾荒。可是，当时的党支部书记兼社主任马之悦却放弃农业生产，利用国家贷款跑买卖…[<a href="http://www.szhgh.com/Article/red-china/mzd/maoshidai/2013-12-18/39999.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-18/40019.html" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1ebtg1nsb8qj205k046weg.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-18/40019.html" target="_blank" title="电影：牛角石">电影：牛角石</a></h4>
                    <span>1962年的中国农村，围绕着是否搞“三自一包”，在牛角石大队展开了一场针锋相对的政治斗争。以地委副部长陈秉仁、大队支委何一得为代表的一批当权派积极贯彻，以支部书记石兰子为首的一批群众坚决反对。…[<a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-18/40019.html" target="_blank">评细</a>]</span>
                </div>
                <div class="le_5 le_2a">
                    <a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/201310/33258.html" target="_blank"><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1ebtg1mkvmxj205k0460ss.jpg" width="200" height="150" border="0" /></a>
                    <h4><a href="http://www.szhgh.com/Article/red-china/mzd/yingxiang/2013-12-18/40019.html" target="_blank" title="1949年毛主席主持开国大典实况录像">电影：决裂</a></h4>
                    <span>共大是一所真正的毛泽东思想的大学，共大是毛主席无产阶级教育革命领域里的长征，共大师生深刻理解和正确诠释了毛主席的革命教育路线，指出了无产阶级在取得了领导地位之后，我们的教育是为了提高千百万工农兵群众的知识水平…[<a href="http://www.szhgh.com/Article/wsds/wenyi/22778.html" target="_blank">评细</a>]</span>
                </div>
            </div>
            <div class="daoy pad_t"></div>
            <div class="cl"></div>
        </div>	
    </div>

    <div class="cont">
        <div class="cont_1">
            <h2><a href="http://www.szhgh.com/s/mzd120/type25.html" title="影视资料" target="_blank">影视资料</a></h2>
            <div class="cont_1a clearfix">
                <ul id="flexisel_live1">
                  <!-- 图片列表 begin -->
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=25 and b.ispic=1 order by b.newstime desc",8,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=$bqr['titlepic']?>" width="200" height="150" title="<?=$bqr['title']?>" style="cursor:pointer;"/></a> 
                        <div class="title"><a href="<?=$bqr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],28)?></a></div> 
                    </li>
                    <?php
}
}
?>
                  <!-- 图片列表 end -->
                </ul>
                <script language="javascript" type="text/javascript">
                    $("#flexisel_live1").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,            
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: { 
                            portrait: { 
                                changePoint:480,
                                visibleItems: 1
                            }, 
                            landscape: { 
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: { 
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });
                </script>
            </div>
        </div>	
    </div>
    
    <div class="cont">
        <div class="cont_1">
            <h2>文章汇总</h2>
            <div class="cl"></div>
            <div class="ov">
                <div class="le_5">
                    <h3 class="h3 clearfix"><a class="pleft" href="http://www.szhgh.com/s/mzd120/type23.html" title="学习毛泽东" target="_blank">学习毛泽东</a><a href="http://www.szhgh.com/s/mzd120/type23.html" title="点击查看更多" class="more pright">更多&nbsp;>></a></h3>
                    <ul class="list  mar_b">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(23,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],60)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
                <div class="le_5 le_2a">
                    <h3 class="h3 clearfix"><a class="pleft" href="http://www.szhgh.com/s/mzd120/type27.html" title="谣言澄清" target="_blank">谣言澄清</a><a href="http://www.szhgh.com/s/mzd120/type27.html" title="点击查看更多" class="more pright">更多&nbsp;>></a></h3>
                    <ul class="list  mar_b">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(27,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],60)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
                <div class="le_5">
                    <h3 class="h3 clearfix"><a class="pleft" href="http://www.szhgh.com/s/mzd120/type24.html" title="红色经典" target="_blank">红色经典</a><a href="http://www.szhgh.com/s/mzd120/type24.html" title="点击查看更多" class="more pright">更多&nbsp;>></a></h3>
                    <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(24,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],60)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
                <div class="le_5 le_2a">
                    <h3 class="h3 clearfix"><a class="pleft" href="http://www.szhgh.com/s/mzd120/type25.html" title="影像资料" target="_blank">影像资料</a><a href="http://www.szhgh.com/s/mzd120/type25.html" title="点击查看更多" class="more pright">更多&nbsp;>></a></h3>
                    <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(25,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],60)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>
            </div>
            <div class="cl"></div>
        </div>
    </div>

    <div class="cont">
        <div class="daoy"><?=ReturnZtAddField(0,'conclusion')?></div>
    </div>

    <div class="cont_pl">
        <div id="plpost" class="pl_list">
            <!-- 评论 -->
            <div id="tosaypl" class="pl section">
               <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
            </div>
            <div class="section_content">
                <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
            </div>
        </div>
    </div>
    
    <!--中间结束-->
    
    
    <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1737191719</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
        });
    </script>
    <!--底部结束-->
    

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=38></script>

</body>
</html>