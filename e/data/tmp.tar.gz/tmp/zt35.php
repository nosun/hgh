<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>薄熙来案济南公审- 红歌会网</title>
        <meta name="description" content="全球瞩目的薄熙来案，党中央决定公开审理并进行了微博直播，引发各界评议。2013年9月22日，薄熙来涉嫌被判无期徒刑，剥夺政治权利终身。随后，薄熙来不服一审判决上诉，山东高院受理。二审维持原判。" />
        <meta name="keywords" content="" />
        <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
        <link href="http://www.szhgh.com/skin/default/css/topic.css" rel="stylesheet" type="text/css" />
        
        <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
        <script src="http://www.szhgh.com/e/data/js/ajax.js" type="text/javascript"></script>
        <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
        <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
        
        <script>
            function setTab(name,cursel,n){
                for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
                }
            }
            function change(id){
                if (typeof(isround)!='undefined') clearTimeout(isround);
                var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
                var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
                var text = document.getElementById("focus_text").getElementsByTagName("li");
                for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
                }
                bigimg[id-1].className="dis";
                smallimg[id-1].className="current";
                text[id-1].className="dis";
                if ((next=id+1) > smallimg.length) next = 1;
                isround=setTimeout('change('+next+')', 5000);
            }
        </script>

    </head>
    <body>
        <!--头部开始-->
        <div class="header">
            <div class="hea_1 clearfix">
                <div class="pleft">
                    <div class="hea_logo pleft"><a href="http://www.szhgh.com/" target="_blank" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></a></div>
                    <ul class="pleft">
                        <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                        <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>&nbsp;&nbsp;|</li>
                        <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                        <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                    </ul>                
                </div>
                <div class="account pright">
                    <script>
                        document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                    </script>
                </div>
            </div>
        </div>
        <div class="hea_2">
            <p><img src="http://img3.wyzxwk.com/p/2013/09/0e93e5f7630dd66d9890081674b25f50.jpg" width="1000" height="200" /></p>
        </div>
        <div class="hea_3">
            <ul>
                <li><a href="http://www.szhgh.com/s/bxl/type1.html" target="_blank" title="最新报道">最新报道</a></li>
                <li><a href="http://www.szhgh.com/s/bxl/type6.html" target="_blank" title="官媒报道">官媒报道</a></li>
                <li><a href="http://www.szhgh.com/s/bxl/type4.html" target="_blank" title="网友评论">网友评论</a></li>
                <li><a href="http://www.szhgh.com/s/bxl/type3.html" target="_blank" title="学者评析">学者评析</a></li>
                <li><a href="http://www.szhgh.com/s/bxl/type2.html" target="_blank" title="庭审回顾">庭审回顾</a></li>
                <li><a href="http://www.szhgh.com/s/bxl/type5.html" target="_blank" title="高清图集">高清图集</a></li>
            </ul>
        </div>

        <?
            $ztid=35;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
            $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);

            $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
        ?>

        <!--头部结束-->
        <!--中间开始-->
        <div class="cont">
            <div class="le_1">

                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from hgh_enewsztinfo where ztid=$ztid and isgood=4 order by newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],50)?></a></h2>
                        <div class="smalltext"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?><a href="<?=$bqsr['titleurl']?>"" title="点击查看详情" target="_blank">[评细]</a></div>
                    <?php
}
}
?>
                    <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from hgh_enewsztinfo where ztid=$ztid and isgood>=1 and isgood<4 order by newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>					
                    </ul>
            </div>
            <div class="ri_1">
                <div id=focus_pic class=right>
                    <div id=focus_big>
                        <ul>
                            <li class=dis><a href="http://www.szhgh.com/Article/news/politics/201308/29245.html" title="高清组图：庭审现场中的薄熙来(新增)" target=_blank><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1e7vrbyadfzj20ir0dzwg4.jpg" /></a></li>
                            <li class=undis><a href="http://www.szhgh.com/Article/news/politics/201308/29227.html" title="高清组图：直击济南中院现场" arget=_blank><img src="http://img3.wyzxwk.com/p/2013/09/small22d8ad776903c7487966579f73625d891378385218.jpg" /></a></li>
                            <li class=undis><a href="http://www.szhgh.com/Article/news/politics/201308/29796.html" title="薄熙来庭审最后一天现场照片(图集" target=_blank><img src="http://i.guancha.cn/News/2013/8/27/6351319056707667791.jpg" /></a></li>
                        </ul>
                        <div id=focus_text_bg></div>
                        <div id=focus_text>
                            <ul>
                                <li class=dis><a href="http://www.szhgh.com/Article/news/politics/201308/29245.html" target=_blank>高清组图：庭审现场中的薄熙来(新增)</a></li>
                                <li class=undis><a href="http://www.szhgh.com/Article/news/politics/201308/29227.html" target=_blank>高清组图：直击济南中院现场</a></li>
                                <li class=undisundis><a href="http://www.szhgh.com/Article/news/politics/201308/29796.html" target=_blank>薄熙来庭审最后一天现场照片(图集)</a></li>
                            </ul>
                        </div>
                    </div>
                    <div id=focus_tip>
                        <ul>
                            <li class=current onmouseover=change(1);><a href="http://www.szhgh.com/Article/news/politics/201308/29245.html" title="高清组图：庭审现场中的薄熙来(新增)" target=_blank><img src="http://ww3.sinaimg.cn/mw690/98fe75a2jw1e7vrbyadfzj20ir0dzwg4.jpg" /></a> </li>
                            <li class=current onmouseover=change(2);><a href="http://www.szhgh.com/Article/news/politics/201308/29227.html" title="高清组图：直击济南中院现场" target=_blank><img src="http://img3.wyzxwk.com/p/2013/09/small22d8ad776903c7487966579f73625d891378385218.jpg" /></a> </li>
                            <li class=current onmouseover=change(3);><a href="http://www.szhgh.com/Article/news/politics/201308/29796.html" title="薄熙来庭审最后一天现场照片(图集" target=_blank><img src="http://i.guancha.cn/News/2013/8/27/6351319056707667791.jpg" /></a></li>
                        </ul>
                    </div>
                    <script>
                        var isround = setTimeout("change(2)",2500);
                    </script>
                </div>
            </div>
        </div>
        
        <div class="cont">
            <div class="le_2">
                <h3 class="h3"><a>最新文章</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from hgh_enewsztinfo where ztid=$ztid order by newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>	
                </ul>
            </div>
            <div class="le_2">
                <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type3.html" title="学者评析" target="_blank">学者评析</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(3,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
            <div class="le_2 le_2a">
                <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type2.html" title="庭审回顾" target="_blank">庭审回顾</a></h3>
                <ul class="list">
                    <li><a href="http://www.szhgh.com/Article/news/politics/201308/29356.html" target="_blank" title="庭审第一天(8月22日)">庭审第一天(8月22日)</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/201308/29402.html" target="_blank" title="庭审第二天(8月23日)">庭审第二天(8月23日)</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/201308/29511.html" target="_blank" title="庭审第三天(8月24日)">庭审第三天(8月24日)</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/201308/29556.html" target="_blank" title="庭审第四天(8月25日)">庭审第四天(8月25日)</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/201308/29650.html" target="_blank" title="庭审第五天(8月26日)">庭审第五天(8月26日)</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/read/201308/29674.html" target="_blank" title="五天庭审全程实录">五天庭审全程实录</a></li>
                </ul>
            </div>
        </div>
        
        <div class="cont">
            <div class="cont_1">
                <h2>图片新闻</h2>
                <div class="cont_1a">
                    <!-- 图片列表 end -->
                    <div class="rollBox">
                    <div class="Cont" id="ISL_Cont">
                        <div class="ScrCont">
                            <div class="List1" id="List1">
                                <!-- 图片列表 begin -->
                                <div class="pic"><a href="http://www.szhgh.com/Article/news/politics/201308/29577.html" title="文汇报评薄熙来庭审:依法审辩,何来“翻倒”?" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1eypxtr3uoij208g05pt8p.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/comments/201308/29577.html" title="文汇报评薄熙来庭审:依法审辩,何来“翻倒”?" target="_blank">文汇报评薄熙来庭审:依法审辩,何来“翻倒”?</a></div>
                                <div class="pic"><a href="http://www.szhgh.com/Article/news/politics/201308/29642.html" title="薄熙来揭示王立军叛逃真正原因 令人震惊!" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1eypxw4eitqj20hy0c5gmg.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics/201308/29642.html" title="薄熙来揭示王立军叛逃真正原因 令人震惊!" target="_blank">薄熙来揭示王立军叛逃真正原因 令人震惊!</a></div>
                                <div class="pic"><a href="http://www.szhgh.com/Article/opinion/xuezhe/201308/29798.html" title="韩德强谈薄熙来案济南公审" target="_blank"><img src="http://img3.wyzxwk.com/p/2013/09/0d72cc4bbe290c0d37cb6930d71de4f7.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/opinion/xuezhe/201308/29798.html" title="韩德强谈薄熙来案济南公审" target="_blank">韩德强谈薄熙来案济南公审</a></div>
                                <div class="pic"><a href="http://www.szhgh.com/Article/news/politics//201308/29704.html" title="薄熙来最后陈述：坦诚作自我批评 反省治家无方" target="_blank"><img src="http://ww2.sinaimg.cn/mw690/98fe75a2jw1eypy1jiqmgj208b05k3yi.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics//201308/29704.html" title="薄熙来最后陈述：坦诚作自我批评 反省治家无方" target="_blank">薄熙来最后陈述：坦诚作自我批评 反省治家无方</a></div>
                                <!-- 图片列表 end -->
                            </div>
                            <div class="List2" id="List2"></div>
                        </div>
                    </div>
                    <!-- 图片列表 end -->
                </div>
                </div>
            </div>	
        </div>
        
        <div class="cont">
                <div class="cont_1">
                        <h2><a href="http://www.szhgh.com/s/bxl/type2.html" title="庭审回顾" target="_blank">庭审回顾</a></h2>
                        <div class="cl"></div>
                        <div class="ov">
                                <div class="le_3"><img src="http://img3.wyzxwk.com/p/2013/09/6f7005d5d5dc4929883ccc3a9b9fa5c8.jpg" width="315" height="236" /></div>
                        <div class="le_3">
                                        <h4><a href="http://www.szhgh.com/Article/news/fanfu/201308/29423.html" target="_blank" title="薄熙来否认贪污指控：500万贪污不存在(图)">薄熙来否认贪污指控：500万贪污不存在(图)</a></h4>
                                        <span>8月23日，薄熙来案庭审继续进行法庭调查。下午，法庭对薄熙来贪污犯罪的指控进行了第一阶段

        调查，时任大连市城乡规划土地局局长的王正刚出庭作证。薄熙来当庭否认贪污500万元公款的行为。[<a href="http://www.szhgh.com/Article/news/fanfu/201308/29423.html" target="_blank">评细</a>]</span>
                                        <h4 class="pad"><a href="http://www.szhgh.com/Article/news/politics/201308/29391.html" target="_blank" title="薄熙来长子李望知济南发声明">薄熙来长子李望知济南发声明</a></h4>
                                <span>8月22日，薄熙来的儿子李望知多年来头一次见到父亲。当天济南庭审结束后，李望知向中外媒体媒体发出声明。声明中说：“感谢党中央、感谢法庭给予了被告人比他预期更多的辩护权利和自由，使得我父亲可以讲出真心话”
        [<a href="http://www.szhgh.com/Article/news/politics/201308/29391.html" target="_blank">评细</a>]</span>			</div>
                                <div class="le_3 le_2a">
                                        <h4><a href="http://www.szhgh.com/Article/news/politics/201308/29704.html" target="_blank" title="薄熙来最后陈述：自我批评 反省治家无方">薄熙来最后陈述：自我批评 反省治家无方</a></h4>
                                        <span>8月26日，薄熙来案庭审进入第五日，薄在庭上作了最后陈述。薄熙来进行了自我反省，坦诚作自我批评，他说“王立军叛逃在中外形成了恶劣的影响，给党和国家带来了影响上的损失，我在这个过程中严重误判，我深感愧疚”。[<a href="http://www.szhgh.com/Article/news/politics/201308/29704.html" target="_blank">评细</a>]</span>
                                        <h4 class="pad"><a href="http://www.szhgh.com/Article/wsds/read/201308/29674.html" target="_blank" title="薄熙来案庭审全程实录(8月22-26日全收录)">薄熙来案庭审全程实录(8月22-26日全收录)</a></h4>
                                <span>薄熙来受贿、贪污、滥用职权案，经过近5天公开开庭审理，8月26日13时04分一审庭审结束，法庭宣布择期宣判。党中央决定在济南公开审理高官薄熙来案件并进行了微博直播，引发各界广泛好评。[<a href="http://www.szhgh.com/Article/wsds/read/201308/29674.html" target="_blank">评细</a>]</span>			</div>
                        </div>
                        <div class="cl"></div>
                        <div class="ov">
                                <ul class="list fl">
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29255.html" target="_blank" title="薄熙来对两千万受贿指控发表重要辩护">薄熙来对两千万受贿指控发表重要辩护</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29456.html" target="_blank" title="薄熙来向证人连发27问并充分辩驳">薄熙来向证人连发27问并充分辩驳</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29378.html" target="_blank" title="薄熙来再对薄谷开来证言陈述 透露重大信息">薄熙来再对薄谷开来证言陈述 透露重大信息</a></li>
                                </ul>
                                <ul class="list fl">
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29471.html" target="_blank" title="薄熙来对贪污指控举证发表长篇辩驳意见">薄熙来对贪污指控举证发表长篇辩驳意见</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29492.html" target="_blank" title="实录:薄熙来与王立军现场对质 透露重大信息">实录:薄熙来与王立军现场对质 透露重大信息</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29623.html" target="_blank" title="公诉人称薄熙来罪行极其严重又拒不认罪">公诉人称薄熙来罪行极其严重又拒不认罪</a></li>
                                </ul>
                                <ul class="list fl">
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29335.html" target="_blank" title="薄熙来:很好,恰恰还原事情本目">薄熙来:很好,恰恰还原事情本目</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29659.html" target="_blank" title="薄熙来辩护人作最后重要辩护 希望得到公正判决">薄熙来辩护人作最后重要辩护 希望得到公正判决</a></li>
                                        <li><a href="http://www.szhgh.com/Article/news/politics/201308/29365.html" target="_blank" title="庭审现场：法庭首次公布薄谷开来证言录音录像">庭审现场：法庭首次公布薄谷开来证言录音录像</a></li>
                                </ul>
                        </div>
                </div>	
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2>视频报道</h2>
                <div class="cont_1a">
                    <!-- 图片列表 end -->
                    <div class="rollBox">
                    <div class="Cont" id="ISL_Cont">
                        <div class="ScrCont">
                            <div class="List1" id="List1">
                                <!-- 图片列表 begin -->
                                <div class="pic"> <a href="http://www.szhgh.com/Article/news/politics/201308/29788.html" title="[视频]央视播发薄熙来案庭审纪实 薄熙来原声首次曝光" target="_blank"><img src="http://img3.wyzxwk.com/p/2013/09/77d5889c68c26cb764e88ed6c978452e.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics/201308/29788.html" title="[视频]央视播发薄熙来案庭审纪实 薄熙来原声首次曝光" target="_blank">[视频]央视播发薄熙来案庭审纪实 薄熙来原声首次曝光</a></div>
                                <div class="pic"> <a href="http://www.szhgh.com/Article/news/politics/201308/29554.html" title="[视频]央视曝光薄熙来案25日庭审现场实况录像" target="_blank"><img src="http://ww4.sinaimg.cn/mw690/98fe75a2jw1eypy6jo1trj20fg09s74q.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics/201308/29554.html" title="[视频]央视曝光薄熙来案25日庭审现场实况录像" target="_blank">[视频]央视曝光薄熙来案25日庭审现场实况录像</a></div>
                                <div class="pic"> <a href="http://www.szhgh.com/Article/news/politics/201308/29407.html" title="[拍客视频]举世瞩目的济南中院 现场实况" target="_blank"><img src="http://img3.wyzxwk.com/p/2013/08/addc4c965ca24c9dd09c45e35828f619.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics/201308/29407.html" title="[拍客视频]举世瞩目的济南中院 现场实况" target="_blank">[拍客视频]举世瞩目的济南中院 现场实况</a></div>
                                <div class="pic"> <a href="http://www.szhgh.com/Article/news/politics/201308/29493.html" title="[视频]薄熙来案继续开庭 王立军出庭作证" target="_blank"><img src="http://img3.wyzxwk.com/p/2013/09/small1b9af6ba4c9bd5444fb7151b643b8c2a1378394738.jpg" width="200" height="150" /></a><a href="http://www.szhgh.com/Article/news/politics/201308/29493.html" title="[视频]薄熙来案继续开庭 王立军出庭作证" target="_blank">[视频]薄熙来案继续开庭 王立军出庭作证</a></div>
                                <!-- 图片列表 end -->
                            </div>
                            <div class="List2" id="List2"></div>
                        </div>
                    </div>
                    <!-- 图片列表 end -->
                </div>
                </div>
            </div>	
        </div>
        
        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/bxl/type6.html" title="官媒报道薄熙来案" target="_blank">官媒报道薄熙来案</a></h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <img src="http://img3.wyzxwk.com/p/2013/09/96af1d1383962cc5746660d864528477.jpg" width="200" height="150" />
                        <h4><a href="http://www.szhgh.com/Article/news/politics/201308/29783.html" target="_blank" title="新华社播发近万字薄熙来案庭审纪实">新华社播发近万字薄熙来案庭审纪实</a></h4>
                        <span>新华社8月27日晚刊发长约一万字左右文章《薄熙来受贿、贪污、滥用职权案庭审纪实》，文中用庭审进行时、涉嫌受贿、涉嫌贪污、涉嫌滥用职权、庭审前后5个小标题进行报道。据@央视新闻微博，央视新闻频道明天将播出纪实视频。[<a href="http://www.szhgh.com/Article/news/politics/201308/29783.html" target="_blank">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29350.html" target="_blank" title="人民网：从薄熙来案公审感受法治中国的力量">人民网：从薄熙来案公审感受法治中国的力量</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/comments/201308/29675.html" target="_blank" title="人民日报：用法治思维和法治方式反腐败">人民日报：用法治思维和法治方式反腐败</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/comments/201308/29672.html" target="_blank" title="环球时报：薄熙来案,用依法审理回答各种猜测">环球时报：薄熙来案,用依法审理回答各种猜测</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29676.html" target="_blank" title="《新闻联播》首次报道薄熙来案庭审">《新闻联播》首次报道薄熙来案庭审</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/comments/201309/30193.html" target="_blank" title="求是理论网：外媒关注并评价薄熙来案">求是理论网：外媒关注并评价薄熙来案</a></li>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <img src="http://img3.wyzxwk.com/p/2013/09/1a6517a4581d427815036118674a94aa.jpg" width="200" height="150" />
                        <h4><a href="http://www.szhgh.com/Article/news/politics/201308/29577.html" target="_blank" title="文汇报:薄熙来依法审辩,何来“翻倒”?">文汇报:薄熙来依法审辩,何来“翻倒”?</a></h4>
                        <span>公开审理，审的是证据，是法律事实，而不是薄熙来本人的“认罪态度”。通过审判，在证据链的基础上，还原犯罪的所有细节，定罪量刑。“蔑视事实翻供就会翻倒自己”，此言莫名，一无法治精神，二无逻辑。啥叫“蔑视事实”?[<a href="http://www.szhgh.com/Article/news/politics/201308/29577.html">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29552.html" target="_blank" title="新华网发布关于25日薄熙来案审理通稿">新华网发布关于25日薄熙来案审理通稿</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29707.html" target="_blank" title="新华网发布薄熙来案一审五日庭审通稿">新华网发布薄熙来案一审五日庭审通稿</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29494.html" target="_blank" title="新华网发布24日薄熙来案庭审通稿(现场薄王对质实况视频)">新华网发布24日薄熙来案庭审通稿(现场薄王对质实况视频)</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/comments/201308/29461.html" target="_blank" title="《环球时报》报道薄熙来长子李望知声明">《环球时报》报道薄熙来长子李望知声明</a></li>
                            <li><a href="http://www.szhgh.com/Article/news/politics/201308/29375.html" target="_blank" title="[央视视频]薄熙来22日庭审现场否认受贿指控 与徐明当庭对质">[央视视频]薄熙来22日庭审现场否认受贿指控 与徐明当庭对质</a></li>
                        </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>	
        </div>
        
        <div class="cont">
            <div class="cont_1">
                <h2>文章汇总</h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type1.html" title="" target="_blank">最新报道</a><a href="http://www.szhgh.com/s/bxl/type1.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list  mar_b">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(1,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type3.html" title="" target="_blank">学者评析</a><a  href="http://www.szhgh.com/s/bxl/type3.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list mar_b">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(3,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type4.html" title="" target="_blank">网友评论</a><a href="http://www.szhgh.com/s/bxl/type4.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(4,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a href="http://www.szhgh.com/s/bxl/type2.html" title="" target="_blank">庭审回顾</a><a href="http://www.szhgh.com/s/bxl/type2.html" title="点击查看更多" class="more">更多&nbsp;>></a></h3>
                        <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(2,8,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>
                        </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>
        </div>

        <div class="cont_pl">
            <div id="plpost" class="pl_list">
                <!-- 评论 -->
                <div id="tosaypl" class="pl section">
                   <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
                </div>
                <div class="section_content">
                    <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                    <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
                </div>
            </div>
        </div>
        

        <!--中间结束-->
        
    <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1962727933</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
        });
    </script>
    <!--底部结束-->
     

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=35></script>
    </body>
</html>