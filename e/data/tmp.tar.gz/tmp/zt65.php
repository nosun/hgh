<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>纪念毛主席诞辰121周年 - 红歌会网</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
    <link href="http://www.szhgh.com/skin/default/css/topic-20141225.css" rel="stylesheet" type="text/css" />
    <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/myfocus-2.0.4.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/mF_tbhuabao_fortopic_sessions.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/newsScroll.js" type="text/javascript"></script>
    <script type="text/javascript" src="http://www.szhgh.com/e/data/js/ajax.js"></script>
    <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
    <!--[if !IE]>|xGv00|ef6f6f4cf55337e8218c7e4915dd8658<![endif]-->
    <script>
        function setTab(name,cursel,n){
            for(i=1;i<=n;i++){
                var menu=document.getElementById(name+i);
                var con=document.getElementById("con_"+name+"_"+i);
                menu.className=i==cursel?"current":"";
                con.style.display=i==cursel?"block":"none";
            }
        }
        function change(id){
            if (typeof(isround)!='undefined') clearTimeout(isround);
            var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
            var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
            var text = document.getElementById("focus_text").getElementsByTagName("li");
            for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
            }
            bigimg[id-1].className="dis";
            smallimg[id-1].className="current";
            text[id-1].className="dis";
            if ((next=id+1) > smallimg.length) next = 1;
            isround=setTimeout('change('+next+')', 5000);
        }
    </script>
</head>
<?
        $ztid=65;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
        $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);
        
        $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
?>
<body closepl="<?=$zt_r['closepl']?>">
    <!--头部开始-->
    <div class="header">
        <div class="hea_1 clearfix">
            <div class="pleft">
                <div class="hea_logo pleft"><a href="http://www.szhgh.com/" target="_blank" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></a></div>
                <ul class="pleft">
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                </ul>                
            </div>
            <div class="account pright">
                <script>
                    document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                </script>
            </div>
        </div>
    </div>
    <div class="hea_2"></div>

    <!--头部结束-->
    <!--中间开始-->

    <div class="wrap width clearfix margin-t">
        <div class="mainbox left">
            <div class="section sectionA">
                <div class="section_header">头条文章</div>
                <div class="section_content">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>=5 order by isgood desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <div class="txt">
                            <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],50)?></a></h2>
                        </div>
                       
                        <?php
                            $zt_link_r = $empire->fetch1("select keyid from {$dbtbpre}ecms_article_data_1 where id=" . $bqr[id]);
                            $links_id_r = explode(",",$zt_link_r[keyid]);
                            for($i=0;$i<6;$i++) {
                                $zar = $empire->fetch1("select * from {$dbtbpre}ecms_article where id=" . $links_id_r[$i]);
                                if($zar and $i%2===0){
                        ?>
                             <p><a href="<?=$zar['titleurl']?>" title="<?=$zar['title']?>" target="_blank"><?=esub($zar['title'],34)?></a>
                            <span>|</span>
                        <?php
                                }elseif($zar and $i%2===1){
                        ?>
                            <a href="<?=$zar['titleurl']?>" title="<?=$zar['title']?>" target="_blank"><?=esub($zar['title'],34)?></a></p>
                        <?php
                        }
                            }
                        ?>
                    <?php
}
}
?>
                </div>                
            </div>
            <div class="section sectionC">
                <div class="section_header"><a href="http://mzd.szhgh.com/jinian/" title="最新纪念动态" target="_blank">最新纪念动态</a></div>
                <div class="section_content">
                    <ul class="m-list m-list-1">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(59,8,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>                
            </div>
        </div>
        <div class="sidebox right">
            <div class="section pic">
                <div class="section_header">图片文章</div>
                <div id="myFocus" class="scroll">
                    <div class="loading"></div><!--载入画面(可删除)-->
                    <div class="pic"><!--图片列表-->
                        <ul class="scroll_list">
                            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and b.ispic=1 and b.firsttitle>=1 order by b.newstime desc limit 6",6,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <li>
                                <a href="<?=$bqsr['titleurl']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],380,285,1,'')?>" alt="<?=$bqr['title']?>" /></a>
                            </li>
                            <?php
}
}
?>
                        </ul>
                    </div>
                    <div class="scroll_bg"></div>
                </div>
                
                <script type="text/javascript">
                    myFocus.set({
                        id: 'myFocus', //焦点图盒子ID
                        pattern: 'mF_tbhuabao', //风格应用的名称
                        time: 3, //切换时间间隔(秒)
                        trigger: 'click', //触发切换模式:'click'(点击)/'mouseover'(悬停)
                        width: 380, //设置图片区域宽度(像素)
                        height: 285, //设置图片区域高度(像素)
                        txtHeight: 'default'//文字层高度设置(像素),'default'为默认高度，0为隐藏
                    });
                </script>
                
            </div>
            <div class="section video">
                <div class="section_header">视频</div>
                <div class="section_content">
                    <div class="clearfix">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>=1 and b.ispic=1 and ttid=1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                            <a class="zoompic left" href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /><div class="icovideo"></div></a>
                            <div class="titleintro right">
                                <h4><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],20)?></a></h4>
                                <div class="intro"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),54))?> <a href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                            </div>
                        <?php
}
}
?>
                    </div>
                    <ul class="list">
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and ttid=1 order by b.newstime desc limit 7",7,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],48)?></a></li>
                        <?php
}
}
?>
                    </ul>
                </div>                   
            </div>            
        </div>
    </div>
    
    <div class="wrap wrap-7 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type51.html" title="话说毛泽东" target="_blank">话说毛泽东</a></div></div>
        <div class="wrap_content">
            <ul class="textpic">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=51 and b.ispic=1 order by b.newstime desc limit 8",8,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <?
                    $nopadding = $bqno%3==0?" class='s-nopadding'":"";
                ?>
                <li<?=$nopadding?>>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="pic left">
                        <img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" />
                        <h3><?=$bqr['title']?></h3>
                    </a>
                </li>
                <?php
}
}
?>
            </ul>
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type52.html" title="学者论毛泽东" target="_blank">学者论毛泽东</a></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=52 and b.ispic=1 and a.isgood>=5 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /><div class="title"><?=$bqr['title']?></div><div class="opacitybg"></div></a>
                <div class="intro"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),250))?></div>
                <?php
}
}
?>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=52 and b.ispic=1 and a.isgood=2 order by b.newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <h3><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></h3>
                        <div class="picintro clearfix">
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="pic left"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                            <div class="intro right"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),104))?> <a class="readmore" href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <?php
}
}
?>
                </ul>
                <ul class="title">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=52 and a.isgood=1 order by b.newstime desc limit 5",5,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=52 and b.ttid=1 and b.ispic=1 and a.isgood>1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                    <strong class="title"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=$bqr['title']?></a></strong>
                    <?php
}
}
?>
                </div>
                <ul class="pictitle-video">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=52 and b.ttid=1 and b.ispic=1 and a.isgood=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li class="clearfix">
                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic left" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                        <strong class="title right"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=esub($bqr['title'],38)?></a></strong>
                    </li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type53.html" title="网友评毛泽东" target="_blank">网友评毛泽东</a></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=53 and b.ispic=1 and a.isgood>=5 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /><div class="title"><?=$bqr['title']?></div><div class="opacitybg"></div></a>
                <div class="intro"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),250))?></div>
                <?php
}
}
?>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=53 and b.ispic=1 and a.isgood=2 order by b.newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <h3><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></h3>
                        <div class="picintro clearfix">
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="pic left"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                            <div class="intro right"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),104))?> <a class="readmore" href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <?php
}
}
?>
                </ul>
                <ul class="title">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=53 and a.isgood=1 order by b.newstime desc limit 5",5,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=53 and b.ttid=1 and b.ispic=1 and a.isgood>1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                    <strong class="title"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=$bqr['title']?></a></strong>
                    <?php
}
}
?>
                </div>
                <ul class="pictitle-video">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=53 and b.ttid=1 and b.ispic=1 and a.isgood=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li class="clearfix">
                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic left" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                        <strong class="title right"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=esub($bqr['title'],38)?></a></strong>
                    </li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type54.html" title="记忆中的毛泽东" target="_blank">记忆中的毛泽东</a></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=54 and b.ispic=1 and a.isgood>=5 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /><div class="title"><?=$bqr['title']?></div><div class="opacitybg"></div></a>
                <div class="intro"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),250))?></div>
                <?php
}
}
?>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=54 and b.ispic=1 and a.isgood=2 order by b.newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <h3><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></h3>
                        <div class="picintro clearfix">
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="pic left"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                            <div class="intro right"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),104))?> <a class="readmore" href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <?php
}
}
?>
                </ul>
                <ul class="title">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=54 and a.isgood=1 order by b.newstime desc limit 5",5,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=54 and b.ttid=1 and b.ispic=1 and a.isgood>1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                    <strong class="title"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=$bqr['title']?></a></strong>
                    <?php
}
}
?>
                </div>
                <ul class="pictitle-video">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=54 and b.ttid=1 and b.ispic=1 and a.isgood=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li class="clearfix">
                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic left" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                        <strong class="title right"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=esub($bqr['title'],38)?></a></strong>
                    </li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="wrap wrap-1 width clearfix">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type55.html" title="群众纪念毛泽东" target="_blank">群众纪念毛泽东</a></div></div>
        <div class="wrap_content">
            <div class="left textpic-box1">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=55 and b.ispic=1 and a.isgood>=5 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /><div class="title"><?=$bqr['title']?></div><div class="opacitybg"></div></a>
                <div class="intro"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),250))?></div>
                <?php
}
}
?>
            </div>
            <div class="left list1">
                <ul class="textpic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=55 and b.ispic=1 and a.isgood=2 order by b.newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li>
                        <h3><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></h3>
                        <div class="picintro clearfix">
                            <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="pic left"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                            <div class="intro right"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),104))?> <a class="readmore" href="<?=$bqsr['titleurl']?>" title="点此查看详细内容" target="_blank">[详细]</a></div>
                        </div>
                    </li>
                    <?php
}
}
?>
                </ul>
                <ul class="title">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=55 and a.isgood=1 order by b.newstime desc limit 5",5,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div> 
            <div class="right list2">
                <div class="titlepic">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=55 and b.ttid=1 and b.ispic=1 and a.isgood>1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                    <strong class="title"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=$bqr['title']?></a></strong>
                    <?php
}
}
?>
                </div>
                <ul class="pictitle-video">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=55 and b.ttid=1 and b.ispic=1 and a.isgood=1 order by b.newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li class="clearfix">
                        <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" class="pic left" target="_blank"><img class="scrollLoading" data-url="<?=$bqr[titlepic]?>" src="/skin/default/images/pixel.gif" style="background:url(/skin/default/images/loading.gif) no-repeat center;" /></a>
                        <strong class="title right"><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" rel="nofollow"><?=esub($bqr['title'],38)?></a></strong>
                    </li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrap width wrap-6">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type56.html" title="精彩图集" target="_blank">精彩图集</a></div></div>
        <div class="wrap_content rowcollay clearfix">
            <div class="c1 left">
                <div class="c1r1">
                    <div class="colorblock1"></div>
                </div>
                <div class="c1r2">
                    <div class="pictitle-absolute2">
                        <a href="http://www.szhgh.com/Article/news/photo/2014-12-28/80.html" title="" target="_blank">
                            <img src="http://ww4.sinaimg.cn/mw1024/ed020860jw1enmd2kned9j20hs0dcwg7.jpg" />
                            <strong>李北方实拍韶山毛泽东之夜：你想不到的人多</strong>
                        </a>
                    </div>
                </div>
                <div class="c1r3">
                    <div class="colorblank2"><strong><a href="http://www.szhgh.com/Article/news/photo/2014-12-26/79.html" title="" target="_blank">韶山：近10万人迎毛主席诞辰121周年纪念日</a></strong></div>
                    <div class="pic right"><a href="http://www.szhgh.com/Article/news/photo/2014-12-26/79.html" title="" target="_blank"><img src="http://ww3.sinaimg.cn/mw1024/3dc49181jw1enmwu621brj20r80gs431.jpg" /></a></div>
                    <div class="cl"></div>
                </div>
            </div>
            <div class="c2 right">
                <div class="c2r1">
                    <div class="c2r1c1 left">
                        <div class="pictitle-absolute2">
                            <a href="http://www.szhgh.com/Article/news/photo/2014-12-17/75.html" title="" target="_blank">
                                <img src="http://images2.china.com/news/zh_cn/hd/11127798/20141214/19102722_2014121415042526886700.jpg" />
                                <strong>山西太原军迷纪念毛泽东诞辰121周年</strong>
                            </a>
                        </div>
                    </div>
                    <div class="c2r1c2 right">
                        <div class="pic"><a href="http://www.szhgh.com/Article/news/photo/2014-07-25/65.html" title="" target="_blank"><img src="http://img3.wyzxwk.com/p/2014/07/small4af424bf50ebb41158af27f9252f5668.jpg" /></a></div>
                        <div class="colorblank1"><strong><a href="http://www.szhgh.com/Article/news/photo/2014-07-25/65.html" title="" target="_blank">毛时代罕见图集：开幕式</a></strong></div>                        
                    </div>
                    <div class="cl"></div>
                </div>
                <div class="c2r2">
                    <div class="c2r2c1 left">
                        <div class="pic"><a href="http://www.szhgh.com/Article/news/photo/2014-03-18/13.html" title="" target="_blank"><img src="http://img1.gtimg.com/8/824/82477/8247718_980x1200_0.jpg" /></a></div>
                        <div class="colorblank1"><strong><a href="http://www.szhgh.com/Article/news/photo/2014-03-18/13.html" title="" target="_blank">图集：生活在毛主席画像下</a></strong></div> 
                    </div>
                    <div class="c2r2c3 right"><div class="colorblock2"></div></div>
                    <div class="c2r2c2 left">
                        <div class="pictitle-absolute2">
                            <a href="http://www.szhgh.com/Article/news/photo/2014-03-18/12.html" title="" target="_blank">
                                <img src="http://i.ssimg.cn/guancha/News/2013/12/26/635236501758352694.jpg" />
                                <strong>震撼与感动:各地群众奔赴韶山祭拜毛主席</strong>
                            </a>
                        </div>
                    </div>
                    <div class="cl"></div>
                </div>
            </div>
            <div class="cl"></div>
        </div>
    </div>
    
    <div class="wrap width wrap-5">
        <div class="wrap_header clearfix"><div class="txt"><a href="http://www.szhgh.com/s/mao121/type37.html" title="视频报道" target="_blank">视频报道</a></div></div>
        <div class="wrap_content clearfix">
            <div class="left pictitle">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.isgood>=1 and b.ispic=1 and b.ttid=1 order by b.newstime desc limit 1",1,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <a class="zoompic left" href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><img src="<?=sys_ResizeImg($bqr[titlepic],320,240,1,'')?>" /><strong><?=$bqr['title']?></strong><div class="titlebg"></div><div class="icovideo"></div></a>
                <?php
}
}
?>
            </div>
            <ul class="right list3"> 
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid  and a.isgood>=1 and b.ispic=1 and ttid=1 order by b.newstime desc limit 8",8,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li>
                    <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank" class="title-absolute1">
                        <img src="<?=sys_ResizeImg($bqr[titlepic],150,113,1,'')?>" />
                        <div class="title"><?=$bqr['title']?></div>
                        <div class="opacitybg"></div>
                    </a>
                </li>
                <?php
}
}
?>
            </ul>            
        </div>
    </div>
    
    <div class="cont_pl">
        <div id="plpost" class="pl_list">
            <!-- 评论 -->
            <div id="tosaypl" class="pl section">
               <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
            </div>
            <div class="section_content">
                <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
            </div>
        </div>
    </div>
    
    <!--中间结束-->
    
    <!--底部开始--> 
            <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/special">专题中心</a> |  <a href="http://www.szhgh.com/Article/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1962727933</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    
    <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/jquery.scrollLoading.js"></script>
    
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
          
          $(".scrollLoading").scrollLoading();	
        });
    </script>
    <!--底部结束-->

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=65></script>

</body>
</html>