<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><?php
$newsurl=$GLOBALS['public_r']['newsurl'];
$specid=$GLOBALS['navinfor']['specid']; 
?>
<html>
<head>
<meta http-equiv="Content-Language" content="zh-CN">
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<meta http-equiv="expires" content="<?=date("D F d Y",time())?>" />
<?php
if($specid){
	$specr=$empire->fetch1('select ztpath,zttype from '.$dbtbpre.'enewszt where ztid='.$specid);
	$specurl = $newsurl.$specr['ztpath'];
	echo '<meta http-equiv="refresh" content="0.1;url='.$specurl.'">';
}
?>
<title></title>
</head>
<body>
</body>
</html>