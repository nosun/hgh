<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>聚焦三中全会- 红歌会网</title>
        <meta name="description" content="又是一次三中全会。十八届三中全会将于11月9日至12日在北京召开。中共中央政治局向中央委员会报告工作，研究全面深化改革重大问题，举世瞩目。" />
        <meta name="keywords" content="" />
        <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
        <link href="http://www.szhgh.com/skin/default/css/topic183.css" rel="stylesheet" type="text/css" />
        <script>
            function setTab(name,cursel,n){
                for(i=1;i<=n;i++){
                    var menu=document.getElementById(name+i);
                    var con=document.getElementById("con_"+name+"_"+i);
                    menu.className=i==cursel?"current":"";
                    con.style.display=i==cursel?"block":"none";
                }
            }
            function change(id){
                if (typeof(isround)!='undefined') clearTimeout(isround);
                var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
                var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
                var text = document.getElementById("focus_text").getElementsByTagName("li");
                for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
                }
                bigimg[id-1].className="dis";
                smallimg[id-1].className="current";
                text[id-1].className="dis";
                if ((next=id+1) > smallimg.length) next = 1;
                isround=setTimeout('change('+next+')', 5000);
            }
        </script>

    </head>
    <body>

        <!--头部开始-->
        <div class="header">
            <div class="hea_1">
                <div class="hea_logo"><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.gif" width="72" height="53" /></a></div>
                <ul>
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页 </a>|</li>
                    <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/html/special.html" title="专题中心" target="_blank">&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/author/columnist/" title="学者专栏" target="_blank">&nbsp;学者专栏 </a></li>
                </ul>
                <span>
                    <script>
                        document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                    </script>
                </span>
            </div>
        </div>
        <div class="hea_2">
            <p><img src="http://www.szhgh.com/d/file/p/2013/11/6fec36d575e39f19643ff368fa1d282f.jpg" width="1000" height="200" /></p>
        </div>
        <div class="hea_3">
            <ul>
                <?
                $ztid=37;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
                $zt_r = $empire->fetch1("select ztpath from {$dbtbpre}enewszt where ztid=" . $ztid);
                $ztpath = $public_r['newsurl'].$zt_r['ztpath'];
                $sql = "select cid,cname,ttype from {$dbtbpre}enewszttype where ztid=$ztid order by myorder ASC";
                $result=$empire->query($sql);    //根据专题id从“专题子类主表”查询出“专题子类id”和“专题子类名称”；
                while($r=$empire->fetch($result)) {       //循环获取查询记录到数组$r,并循环输出子类信息列表
                $cid=$r['cid'];
                $zttypepath = $ztpath.'/type'.$r['cid'].$r['ttype']
                ?>
                <li><a href="<?=$zttypepath?>" target="_blank" title="<?=$r['cname']?>"><?=$r['cname']?></a></li>
                <?
                }
                ?>
            </ul>
        </div>

        <!--头部结束-->
        <!--中间开始-->
        <div class="cont">
            <div class="le_1">

                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood=4 order by newstime desc limit 2",2,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <h2><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=esub($bqr['title'],52)?></a></h2>
                <div class="smalltext"><?=htmlspecialchars_decode(esub(strip_tags($bqr['smalltext']),180))?>&nbsp;&nbsp;<a href="<?=$bqsr['titleurl']?>" title="点击查看详情" target="_blank">[评细]</a></div>
                <?php
}
}
?>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo where ztid=$ztid and isgood>=1 and isgood<4 order by newstime desc limit 3",3,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>					
                </ul>
            </div>
            <div class="ri_1">
                <div id=focus_pic class=right>
                    <div id=focus_big>
                        <ul>
                            <li class=dis><a href="http://www.szhgh.com/article/news/news/201310/35340.html" title=""383"方案首公开 刘鹤等领衔起草" target=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/8f1e8ce2b67ed33605fe58caab899752.jpg" /></a></li>
                            <li class=undis><a href="http://www.szhgh.com/article/news/top/25925.html" title="习近平:国家强大要靠实体经济" arget=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/485b88b2d6cbbe991dd9320f5774acd2.jpg" /></a></li>
                            <li class=undis><a href="http://www.szhgh.com/article/news/news/201311/36194.html" title="李克强:对民营企业家，政府不仅信任，还要依靠！" target=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/450bf527948010624b8bfe6620fae967.jpg" /></a></li>
                        </ul>
                        <div id=focus_text_bg></div>
                        <div id=focus_text>
                            <ul>
                                <li class=dis><a href="http://www.szhgh.com/article/news/news/201310/35340.html" target=_blank>"383"方案首公开 刘鹤等领衔起草</a></li>
                                <li class=undis><a href="http://www.szhgh.com/article/news/top/25925.html" target=_blank>习近平:国家强大要靠实体经济</a></li>
                                <li class=undis><a href="http://www.szhgh.com/article/news/news/201311/36194.html" target=_blank>李克强:对民营企业家，政府不仅信任，还要依靠！</a></li>
                            </ul>
                        </div>
                    </div>
                    <div id=focus_tip>
                        <ul>
                            <li class=current onmouseover=change(1);><a href="http://www.szhgh.com/article/news/news/201310/35340.html" title=""383"方案首公开 刘鹤等领衔起草" target=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/f0d319101f0b97658b5ed7f5e9d252c5.jpg" /></a> </li>
                            <li class=current onmouseover=change(2);><a href="http://www.szhgh.com/article/news/top/25925.html" title="习近平:国家强大要靠实体经济" target=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/c3a23df1eb1b2ea9be8c28fe2f44919d.jpg" /></a> </li>
                            <li class=current onmouseover=change(3);><a href="http://www.szhgh.com/article/news/news/201311/36194.html" title="李克强:对民营企业家，政府不仅信任，还要依靠！" target=_blank><img src="http://www.szhgh.com/d/file/p/2013/11/74e309f247d6cd52ffed19ec9851f0a3.jpg" /></a></li>
                        </ul>
                    </div>
                    <script>
                        var isround = setTimeout("change(2)",2500);
                    </script>
                </div>
            </div>
        </div>

        <div class="cont">
            <div class="le_2">
                <h3 class="h3"><a href="http://www.szhgh.com/s/szqh/type13.html" title="最新报道" target="_blank">最新报道</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(13,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
            <div class="le_2">
                <h3 class="h3"><a href="http://www.szhgh.com/s/szqh/type16.html" title="学者观点" target="_blank">学者观点</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(16,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
            <div class="le_2 le_2a">
                <h3 class="h3"><a href="http://www.szhgh.com/s/szqh/type19.html" title="高层动态" target="_blank">高层动态</a></h3>
                <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq(19,6,4,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
            </div>
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a>热点聚焦</a></h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <h3 class="h3"><a>土地制度</a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/f04a53d35341dcdc11fe0b1510e37904.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——土地自由流转，逐步向种粮大户和拥有雄厚资金的资本家手中集中。</br>
——资本下乡，农民由土地的占有者变身为雇工。</br>
——土地私有化，农民最终失去对土地的占有。</br>
——土地以各种名目和形式进入市场，农民最终丧失话语权。</br>
——家庭联产承包责任制被不断弱化，小农经济走向尽头。</br></span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：土地私有化是自由主义学者极力推动和鼓吹的一项政策，他们以明晰产权的名义让农民拥有自己的土地，但就像工人在明晰产权的改革中下岗失业一样，私有化只会让农民最终失去土地。土地改革应当从引导农民走合作化道路着手，采用股份制形式，进行规模化、多样化生产经营，做大做长产业链，发展和壮大集体经济，走共同富裕道路。
                         </span>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a>城镇化建设</a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/520f8b0fc4ccab8f6243c4f58cd6aba3.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——农村土地确权政策应先行一步，土地流转速度加快，农民可选择行业，城镇化就起来了。</br>
——破除土地财政，不改变现行土地管理制度，切断地方政府卖地生财动力机制，人的城镇化就永远赶不上土地的城镇化。</br>
——户籍制度改革是关键一环，应推动户籍制度改革，逐步放开城市落户限制。</span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：习近平：即使将来城镇化达到70%以上，还有四五亿人在农村。农村绝不能成为荒芜的农村、 留守的农村、记忆中的故园。城镇化要发展， 农业现代化和新农村建设也要发展，同步发展才能相得益彰，要推进城乡一体化发展。俞正声：推进城镇化建设要坚持以人为本，为人民群众提供更好的生产生活条件；要坚持以产业为基础，推动产业集聚发展和转型升级；要坚持规划约束，着力增强规划的科学性、权威性；[<a href="http://www.szhgh.com/article/news/top/25386.html" target="_blank">评细</a>]
                         </span>
                    </div>
                    <div class="le_5">
                        <h3 class="h3"><a>国企改革</a><a>更多&nbsp;>></a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/62812ae72ae78f1793e06596e36fa23a.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——打破中央企业垄断，放宽进入市场限制，国企逐步退出，减少国有经济在国民经济的比重。</br>
——目前国资监管的责任主体不够明确，存在国资管理的“空白点”。应实现政企分开，改变国有资产管理模式。</br>
——放宽入行门槛，创造公平的投资环境，促进民营经济发展。</span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：社会主义公有制的基本特征是广大劳动者共同平等地占有生产资料。国有企业的产权理应由国家掌管，而不能具体落到每一个人身上。在贯彻落实国家宏观调控政策、保证市场供应、维护国家经济安全，以及抗震救灾、扶贫济困等方面，国有企业都起到带头作用，危难之际顶得上、稳得住。国有企业对国家、对社会做出的积极贡献，无一不是使全民直接、间接得分享的“红利”。
　　国有企业存在的问题只有通过深化改革加以解决，国企改革绝不是要把国企改没，而是要改好。因此，要正确理解坚持“两个毫不动摇”的意义，而不能对国有企业实行私有化。[<a href="http://www.szhgh.com/article/news/news/201308/28597.html" target="_blank">评细</a>]
                         </span>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a>金融改革</a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/cf6b38b8336568940a94764e3358645d.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——加快人民币国际化的步伐，进一步放松资本账户的管制，放松民资投资海外的限制。</br>
——利率市场化将面临最后一步——存款利率市场化。业内认为需要时间，下一个具体步骤很有可能是让银行发行大额可转让存单。</br>
——进一步规范银行表外业务，让民间金融阳光化和合法化，杜绝吴英事件的再度发生。</span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：金融自由化的本质，是国际资本集团对国家主权的否定，是国际资本集团摆脱世界各国行政和法律约束的工具，是国际资本集团在全球范围内统一配置资源和攫取财富的新殖民体系。世界经济一体化就是由此力量推动形成的。虽然世界经济一体化还只是一种发展趋势，但是世界金融一体化已经初步形成。世界金融一体化的形成，标志着国际资本集团已经把国家完全控制在手中，踩在了脚下。国家已经完全成为国际资本集团实现利润和增值扩张的一个简单工具。
                         </span>
                    </div>
                    <div class="le_5">
                        <h3 class="h3"><a>财税改革</a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/58b42dcefdc6788a5f65cb3ee297bf05.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——“营改增”从交通运输和若干现代服务业扩大到电讯、铁路运输和建筑安装业并推广到全国。</br>
——启动个税向综合税改革试点，稳步扩大房产税试点</br>
——大幅度提高资源税税率和环保收费的标准。</br>
——显著提高医疗、社保、环保、新能源等支出占政府支出的比重，降低三公消费的比重。</span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：目前中国财税体制改革的内容，主要是集中在中央与地方的财权关系上，本轮财税体制改革的所谓突破，不过是从原来中央与地方只是单纯划分财权转移到同时划分事权上来。其实当今中国财税体制改革最迫切需要解决的问题，应该是“劫富济贫”和“劫官济民”。一方面，在财税收入方面，加大富人税负，减少老百姓税负，改变目前这种富人不纳税或极少纳税，穷人和一般老百姓成为纳税主体的不合理不公平现象;另一方面，在财政支出方面，应该大幅压缩党政机关支出，扩大公共支出;适度压缩投资支出，扩大民生支出。[<a href="http://www.szhgh.com/article/netizens/201311/36294.html" target="_blank">评细</a>]
                         </span>
                    </div>
                    <div class="le_5 le_2a">
                        <h3 class="h3"><a>收入分配</a></h3>
                        <a><img src="http://www.szhgh.com/d/file/p/2013/11/96ac5d0647176cd4d26ff8a7d27ae737.jpg" width="200" height="150" /></a>
                        <span style="padding-top:10px;">——出台收入分配改革实施细则，提高个税起征点，增加居民收入。</br>
——限制垄断性国企高管权力和薪酬的膨胀，缩小贫富差距。</br>
——由于户籍制度造成“城乡分化”，削弱了经济要素的自由流动，阻碍了农村城市化进程，不利于消费市场的进一步发展。应放宽大城市落户条件，消除在教育就业医疗城乡间的福利差异。实现人口自由流动。</span>
                        <span style="clear:both;  padding-top:10px;  padding-bottom:10px;">
                           点评：当今中国的贫富两极分化已达到极端，正在超出社会的承受能力。自人类进入工业社会以来，贫富两极分化就一直是社会革命爆发的根本原因。当今中国贫富两极分化不仅表现为世界基尼系数最高，更为重要的是财富分配不公，这是比财富分配不均更加可怕的矛盾。
中国富豪不是长期经营的结果，而是对现有社会财富进行再分配的结果，是极少数人对绝大多数人直接抢劫的结果。18大后习近平主席多次指出今后改革的基本原则就是要实行共同富裕，如何缩小贫富差距，实现收入公平，应该成为三中全会的重要议题。
                    </div>

                </div>
                <div class="cl"></div>
            </div>		
        </div>

        <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/szqh/type20.html" title="热议383" target="_blank">热议383</a></h2>
                <div class="cl"></div>
                <div class="ov">
                    <div class="le_5">
                        <a href="http://www.szhgh.com/article/netizens/201310/35483.html" title="“383方案”包藏祸心吗？" target="_blank"><img src="http://img3.wyzxwk.com/p/2013/11/8deaf89b0ef7d9047402a07501b7a105.jpg" width="200" height="150" /></a>
                        <h4><a href="http://www.szhgh.com/article/netizens/201310/35483.html" target="_blank" title="“383方案”包藏祸心吗？">“383方案”包藏祸心吗？</a></h4>
                        <span>为什么383方案会出台呢?日渐坐大的豪强们已经开始试图干政了。 逼仄的经济状况使得管理层乱了阵脚。 中国没有自己经济学的尴尬，使得错把野鬼当仙佛。西风东渐以来，意识形态领域中华固有概念体系全线沦丧失守。[<a href="http://www.szhgh.com/article/netizens/201310/35483.html" target="_blank">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://www.szhgh.com/article/netizens/201310/35585.html" target="_blank" title="抓住刘鹤的黑手，挽救中华民族">抓住刘鹤的黑手，挽救中华民族</a></li>
                            <li><a href="http://www.szhgh.com/article/news/news/201310/35717.html" target="_blank" title="吴辉：看了“383”方案，我哭了">吴辉：看了“383”方案，我哭了</a></li>
                            <li><a href="http://www.szhgh.com/article/netizens/201311/35941.html" target="_blank" title="“383”改革方案被热炒：警惕背后的政治性图谋">“383”改革方案被热炒：警惕背后的政治性图谋</a></li>
                            <li><a href="http://www.szhgh.com/article/netizens/201311/35887.html" target="_blank" title="贺雪峰回应383方案：土地私有化不能搞">贺雪峰回应383方案：土地私有化不能搞</a></li>
                            <li><a href="http://www.szhgh.com/article/netizens/201311/36200.html" target="_blank" title="黎亚彬：从“383”的不足看十八届三中全会的历史功过">黎亚彬：从“383”的不足看十八届三中全会的历史功过</a></li>
                        </ul>
                    </div>
                    <div class="le_5 le_2a">
                        <a href="http://www.szhgh.com/article/news/news/201310/35672.html" title="“383”报告引领改革建议值得关注" target="_blank"><img src="http://www.szhgh.com/d/file/p/2013/11/cd1124fcaa719655543e8c3b8e18873f.jpg" width="200" height="150" /></a>
                        <h4><a href="http://www.szhgh.com/article/news/news/201310/35672.html" target="_blank" title="“383”报告引领改革建议值得关注">“383”报告引领改革建议值得关注</a></h4>
                        <span>没有一个智库可以左右中央的决策。但国研中心对形成国家改革政策的真实影响，在中国所有智库中多年来无疑处于最高之列。“383”路线图涉及行政审批、反腐倡廉、土地制度、财税体制等公众高度关心的领域，很多建议“尺度很大”…[<a href="http://www.szhgh.com/article/news/news/201310/35672.html">评细</a>]</span>
                        <ul class="list">
                            <li><a href="http://www.szhgh.com/article/news/news/201310/35340.html" target="_blank" title="高层智囊"383"改革方案首公开 刘鹤等领衔起草">高层智囊"383"改革方案首公开 刘鹤等领衔起草</a></li>
                            <li><a href="http://www.szhgh.com/article/netizens/201311/35999.html" target="_blank" title="栾中校:谏言习总掺沙子刘鹤课题组">栾中校:谏言习总掺沙子刘鹤课题组</a></li>
                            <li><a href="http://www.szhgh.com/article/news/news/201311/36093.html" target="_blank" title="春秋笔：383方案--新自由主义势力对抗红色中国">春秋笔：383方案--新自由主义势力对抗红色中国</a></li>
                            <li><a href="http://www.szhgh.com/article/netizens/201311/36270.html" target="_blank" title="“383”，一个公开刨祖坟和挖根基的方案">“383”，一个公开刨祖坟和挖根基的方案</a></li>
                            <li><a href="http://www.szhgh.com/article/news/news/201310/35578.html" target="_blank" title="“383”报告全文详解:以扩大开放倒逼国内改革">“383”报告全文详解:以扩大开放倒逼国内改革</a></li>
                        </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>		
        </div>

         <div class="cont">
            <div class="cont_1">
                <h2><a href="http://www.szhgh.com/s/szqh/type18.html" title="历届三中全会回顾" target="_blank">历届三中全会回顾</a></h2>
                <div class="cl"></div>
                <div class="ov">
                  <a><img src="http://www.szhgh.com/d/file/p/2013/11/ec6ca775fcdd0354441f3dee39f55839.gif" width="945" height="885" /></a>
                </div>
                <div class="cl"></div>
            </div>		
        </div>

 
         <div class="cont">
            <div class="cont_1">
                <h2><a>最新文章</a></h2>
                <div class="cl"></div>
                <div class="ov">
                      <div class="le_5">
                   <ul class="list">
                    <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq('selfinfo',15,1,'','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                    <li><a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank"><?=$bqr['title']?></a></li>
                    <?php
}
}
?>
                </ul>
                    </div>
                </div>
                <div class="cl"></div>
            </div>		
        </div>

        <div class="cont_pl">
            <h2>网友评论</h2>
            <div>
                <div class="pl section">
                    <!-- UY BEGIN -->
                    <div id="uyan_frame"></div>
                    <script type="text/javascript" src="http://v2.uyan.cc/code/uyan.js?uid=1686612"></script>
                    <!-- UY END -->
                </div>
            </div>
        </div>
        <!--中间结束-->
        <!--底部开始-->
        <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/html/special.html">专题中心</a> |  <a href="http://www.szhgh.com/article/notice/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1737191719</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>|<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
        <!--底部结束-->
<script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=37></script>
    </body>
</html>