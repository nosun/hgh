<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns:wb="http://open.weibo.com/wb" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>视频中心 - <?=$public_r['sitename']?></title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <link href="http://www.szhgh.com/skin/default/css/base.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" />
        <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js"></script>
        <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/myfocus-2.0.4.min.js"></script>
        <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/mF_tbhuabao_formainclass.js"></script>
        <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/jquery.vticker-min.js"></script>
        <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/custom.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$("#video_e2 ul > li:odd").css("margin-right","0px");
				$(".v").hover(function(){
					$(this).children(".v-meta").show();
					$(this).children(".vb").show();
					},
					function(){
					$(this).children(".v-meta").hide();
					$(this).children(".vb").hide();
				})
			})
		</script>
    </head>
    <body class="video">

            <!-- header -->
            <div class="small header">
    <div class="redlogo">
        <div class="logo">
            <a href="http://www.szhgh.com/" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/logo.png" /></a>
            <div class="top_menu right">
                <a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">网址导航</a>
                <a class='first' href="http://www.szhgh.com/special" title="点此进入专题中心" target="_blank">专题中心</a>
                <a href="http://www.szhgh.com/xuezhe/" title="点此进入学者专栏" target="_blank">学者专栏</a>
                <a href="http://www.szhgh.com/e/member/cp/">会员中心</a>
                <a href="http://www.szhgh.com/e/DoInfo/AddInfo.php?mid=10&enews=MAddInfo&classid=29">我要投稿</a>
            </div> 
            <div class="clear"></div>
        </div>
    </div>
</div>

            <!-- header end -->

        <!-- channelnav -->
        <div class="wrap">
            <div class="channelnav clearfix">
                <div id="ztlogo" class="left"><a href="/video" target="_self"><img src="/skin/default/images/videologo.png" /></a></div>
                <div class="right">
                    <div class="account left">
                        <script>
                            document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t=' + Math.random() + '"><' + '/script>');
                        </script>
                    </div>
                </div>
            </div>
        </div>  
        <!-- channelnav end -->

            <!-- class navigation -->
            <div class="navwrap">
                <div id='js_controlclassid' classid='100' class="navigation">
<div class="right rightwrap">
	<ul id="js_currentclass" class="sonclasslist left">
                <li classid="90"><a title="视频中心首页" href="/video/">首页</a></li>
		<?
			$sql=$empire->query("select classid, classname, classpath from `hgh_enewsclass` where bclassid='90' order by `classid` ASC limit 10");
			while($c=$empire->fetch($sql)){
                        echo '<li classid="'.$c[classid].'"><a title="'.$c[classname].'" href="'.$public_r[newsurl].$c[classpath].'">'.$c[classname].'</a></li>';
                        }
		?>
	</ul>     
	<form class='searchform right' name=search_js1 method=post action='http://www.szhgh.com/e/search/index.php' onsubmit='return search_check(document.search_js1);'>
		<div align="center">
			<input name="show" type="hidden" value="title" />
			<input name="classid" type="hidden" value="90" />
			<input class='inputtext' name="keyboard" type="text" size="13" />
			<input class='submitbutton' type="submit" name="Submit" value="" />
		</div>
	</form>   
</div>
<div class="clear"></div>
                </div>
            </div>
            <!-- class navigation end -->
            
            <!-- main -->
            <div class="container">
				<div id="videoTop" class="clearfix v_section">
					<div class="sidebar">
						<div class="section">
							<div class="section_header">
								<strong>最新视频</strong>
							</div>
							<div class="section_content">
								<ul class="clist14">
									<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('selfinfo',6,0,0,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
									<li><a href="<?=$bqsr[titleurl]?>" title="<?=$bqr[title]?>" target="_blank"><?=$bqr[title]?></a></li>
									<?php
}
}
?>
								</ul>
							</div>
						</div>
						
						<div id="hotclick" class="section mood">
							<div class="section_header">
								<strong><a title="热点文章">心情排行</a></strong>
							</div>
							<div id="js_moodtab">
								<ul class="js_button clearfix">
									<li class="onhover"><a>精彩</a></li>
									<li><a>感动</a></li>
									<li><a>搞笑</a></li>
									<li><a>开心</a></li>
									<li><a>愤怒</a></li> 
									<li><a>无聊</a></li>
									<li><a>难过</a></li>                                
									<li><a>同情</a></li>                                
								</ul>
								<div class="js_con numlist">
									<ul>
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood1 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood1 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood1']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood2 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood2 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood2']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>                                
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood3 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood3 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood3']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>                        
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood4 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood4 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood4']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul> 
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood5 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood5 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood5']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>                        
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood6 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood6 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood6']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>    
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood7 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood7 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood7']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>                        
									<ul style="display: none;">
										<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select a.title,a.titleurl,a.titlepic,a.smalltext,b.mood8 from {$dbtbpre}ecms_video a inner join {$dbtbpre}ecmsextend_mood b on a.id=b.id and a.classid=b.classid  where truetime>UNIX_TIMESTAMP()-86400*7 order by b.mood8 desc limit 10",10,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
										<li class="no<?=$bqno?>"><span class="no"><?=$bqno?></span> <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>  心情数：<?=$bqr['mood8']?>" target="_blank"><?=$bqr['title']?></a></li>
										<?php
}
}
?>
									</ul>  
								</div>
							</div>	
						</div>						
					</div>
					<div class="main" id="video_index_elite">
						<div class="clearfix">
						<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('video',9,18,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
						<? if($bqno==2){?>
								<div id="video_e2">
									<ul class="clearfix videolista">
						<?}elseif($bqno==6){?>
									</ul>
								</div>
						</div>
						<div class="clearfix" id="video_e3">
								<ul class="clearfix videolista">
						<?}?>
						<? if($bqno==1){?>
								<div id="video_e1" class="left ishover v_big">
						<? }else{?>
								<li class="v">
						<?}?>
									<div class="v-thumb">
											<img alt="<?=$bqr[title]?>" src="<?=$bqr[titlepic]?>">
									</div>
									<div class="v-link">
										<a title="<?=$bqr[title]?>" href="<?=$bqsr[titleurl]?>"></a>
									</div>
									<div class="vb">
									</div>
									<div class="v-meta">
										<div class="v-meta-title">
											<a href="<?=$bqsr[titleurl]?>" title="<?=$bqr[title]?>"><?=$bqr[title]?></a>
										</div>
										<div class="v-meta-detail">
											<span class="v-class">[<?=$bqsr[classname]?>]</span><span class="v-hnum"><?=$bqr[onclick]?></span> <span class="v-cnum"><?=$bqr[plnum]?></span>
										</div>
									</div>
									<? if($bqno==1){?>
								</div>
						<? }else{?>
								</li>
						<?}?>	
							<?php
}
}
?>
							</ul>
						</div>	
					</div>		
                </div>
				
				<div id="v_wyhot">
					<h2>网友推荐</h2>
					<ul class="videolistb clearfix">
						<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('video',5,18,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
							<li class="v2">
								<div class="v-thumb">
										<a title="<?=$bqr[title]?>" href="<?=$bqsr[titleurl]?>"><img alt="<?=$bqr[title]?>" src="<?=$bqr[titlepic]?>"></a>
								</div>
								<div class="v-meta">
									<div class="v-meta-title">
										<a href="<?=$bqsr[titleurl]?>" title="<?=$bqr[title]?>"><?=$bqr[title]?></a>
									</div>
									<div class="v-meta-detail">
										<span class="v-class">[<?=$bqsr[classname]?>]</span><span class="v-hnum"><?=$bqr[onclick]?></span> <span class="v-cnum"><?=$bqr[plnum]?></span>
									</div>
								</div>
							</li>
						<?php
}
}
?>							
					</ul>
				</div>

				<?
					$sql=$empire->query("select classid, classname, classpath from `hgh_enewsclass` where bclassid='90' order by `classid` ASC limit 10");
					while($c=$empire->fetch($sql)){
				?>
					
					

				<div class="v_class clearfix">
					<div class="main">
						<div class="section_header">
							<strong><?=$c[classname]?></strong>
							<em><span><a target="_blank" title="点击查看更多" href="<?=$public_r[newsurl].$c[classpath]?>" class="morebutton"></a> </span></em>
							<div class="clear"></div>
						</div>
						<div class="section_content clearfix">
								<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('video',7,18,1,'','newstime DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
								<? if($bqno==1){?>
										<div class="video_c1">
											<div class="v-thumb">
												<a title="<?=$bqr[title]?>" href="<?=$bqsr[titleurl]?>"><img alt="<?=$bqr[title]?>" src="<?=$bqr[titlepic]?>"></a>
											</div>
											<div class="v-meta-title">
												<a href="<?=$bqsr[titleurl]?>" title="<?=$bqr[title]?>"><?=$bqr[title]?></a>
											</div>
											<div class="v-meta-detail">
												<?=$bqr[smalltext]?>
											</div>
										</div>
										<div class="video_c2">
											<ul class="clearfix videolistc">
								<? }else{?>
										<li class="vc">
											<div class="v-thumb">
												<a title="<?=$bqr[title]?>" href="<?=$bqsr[titleurl]?>"><img alt="<?=$bqr[title]?>" src="<?=$bqr[titlepic]?>"></a>
											</div>
											<div class="v-meta-title">
												<a href="<?=$bqsr[titleurl]?>" title="<?=$bqr[title]?>"><?=$bqr[title]?></a>
											</div>
										</li>
								<?}?>	
									<?php
}
}
?>
									</ul>
								</div>
						</div>
					</div>
					<div class="sidebar">
						<div class="section vc_toptab" id="js_hottab_<?=$c[classid]?>">
							<div class="section_header">
								<strong><?=$c[classname]?>排行</strong>
								<em>
									<a class="onhover">24小时</a>
									<a>一周</a>
									<a>一月</a>
								</em>
							</div>
							<div class="section_content">
								<ol class="numlist">
								<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("$c[classid]",10,1,0,'truetime>UNIX_TIMESTAMP()-86400','onclick DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
									<li class="no<?=$bqno?>">
										<span class="no"><?=$bqno?></span> <a href="<?=$bqsr[titleurl]?>" target="_blank" title="<?=$bqr[title]?> 点击:<?=$bqr['onclick']?>"><?=esub($bqr[title],50)?></a>
									</li>
								<?php
}
}
?>
								</ol>
								<ol class="numlist" style="display: none;">
								<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("$c[classid]",10,1,0,'truetime>UNIX_TIMESTAMP()-86400*7','onclick DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
									<li class="no<?=$bqno?>">
										<span class="no"><?=$bqno?></span> <a href="<?=$bqsr[titleurl]?>" target="_blank" title="<?=$bqr[title]?> 点击:<?=$bqr['onclick']?>"><?=esub($bqr[title],50)?></a>
									</li>
								<?php
}
}
?>
								</ol>
								<ol class="numlist" style="display: none;">
								<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("$c[classid]",10,1,0,'truetime>UNIX_TIMESTAMP()-86400*30','onclick DESC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
									<li class="no<?=$bqno?>">
										<span class="no"><?=$bqno?></span> <a href="<?=$bqsr[titleurl]?>" target="_blank" title="<?=$bqr[title]?> 点击:<?=$bqr['onclick']?>"><?=esub($bqr[title],50)?></a>
									</li>
								<?php
}
}
?>
								</ol>    
							</div>
						</div>					
					
					</div>
				</div>
				<?
					}
				?>		
            </div>
            <!-- main end -->
            <script type="text/javascript">
                $(function(){
                  $('#js_moodtab .js_button li').TabTurn({ box:"#js_moodtab",con: ".js_con ul" });
				<?
					$sql=$empire->query("select classid, classname, classpath from `hgh_enewsclass` where bclassid='90' order by `classid` ASC limit 10");
					while($c=$empire->fetch($sql)){
				?>
					$('#js_hottab_<?=$c[classid]?> .section_header em a').TabTurn({ box:"#js_hottab_<?=$c[classid]?>",con: "#js_hottab_<?=$c[classid]?> .section_content ol" });
				 <?}?>
               });
            </script>
            <!-- footer -->
            <script src="http://tjs.sjs.sinajs.cn/open/api/js/wb.js" type="text/javascript" charset="utf-8"></script>
<div class="footer">
    <div class="sitemap">
        <ul class="mapul">
            <li class="mapli first">
                <strong><a href="http://www.szhgh.com/Article/news/" title="资讯中心" target="_blank">资讯中心</a></strong>
                <ul class='specialstyle'>
                    <li><a href="http://www.szhgh.com/gundong/" title="滚动" target="_blank">滚动</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/politics/" title="时政" target="_blank">时政</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/world/" title="国际" target="_blank">国际</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/leaders/" title="高层" target="_blank">高层</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/gangaotai/" title="港澳台" target="_blank">港澳台</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/society/" title="社会" target="_blank">社会</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/fanfu/" title="反腐" target="_blank">反腐</a></li>
                    <li><a href="http://www.szhgh.com/Article/news/chujian/" title="除奸" target="_blank">除奸</a></li>  
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </li>
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/opinion/" title="纵论天下" target="_blank">纵论天下</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/opinion/wp/" title="红歌会网评" target="_blank">红歌会网评</a></li>
                    <li><a href="http://www.szhgh.com/Article/opinion/xuezhe/" title="学者观点" target="_blank">学者观点</a></li>
                    <li><a href="http://www.szhgh.com/Article/opinion/zatan/" title=" 网友杂谈" target="_blank"> 网友杂谈</a></li>
                    <li><a href="http://www.szhgh.com/Article/opinion/weibo/" title="微博天下" target="_blank">微博天下</a></li>
                </ul>
                <div class="clear"></div>
            </li>               
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/red-china/" title="红色中国" target="_blank">红色中国</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/red-china/mzd/" title=" 毛泽东" target="_blank"> 毛泽东</a></li>
                    <li><a href="http://www.szhgh.com/Article/red-china/ideal/" title=" 理想园地" target="_blank"> 理想园地</a></li>
                    <li><a href="http://www.szhgh.com/Article/red-china/redman/" title="红色人物" target="_blank">红色人物</a></li>
                    <li><a href="http://www.szhgh.com/Article/red-china/tour/" title="红色旅游" target="_blank">红色旅游</a></li>
                </ul>
                <div class="clear"></div>
            </li>
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/cdjc/" title="唱读讲传" target="_blank">唱读讲传</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/cdjc/hongge/" title="唱红歌" target="_blank">唱红歌</a></li>
                    <li><a href="http://www.szhgh.com/Article/cdjc/jingdian/" title="读经典" target="_blank">读经典</a></li>
                    <li><a href="http://www.szhgh.com/Article/cdjc/gushi/" title="讲故事" target="_blank">讲故事</a></li>
                    <li><a href="http://www.szhgh.com/Article/cdjc/zhengqi/" title="传正气" target="_blank">传正气</a></li>
                </ul>
                <div class="clear"></div>
            </li>                 
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/health/" title="人民健康" target="_blank">人民健康</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/health/zjy/" title="转基因" target="_blank">转基因</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/zhongyi/" title="中医" target="_blank">中医</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/baojian/" title="保健" target="_blank">保健</a></li>
                    <li><a href="http://www.szhgh.com/Article/health/food/" title="食品安全" target="_blank">食品安全</a></li>
                </ul>
                <div class="clear"></div>
            </li>
             <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/gnzs/" title="工农之声" target="_blank">工农之声</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/gnzs/farmer/" title="农民之声" target="_blank">农民之声</a></li>
                    <li><a href="http://www.szhgh.com/Article/gnzs/worker/" title="工友之家" target="_blank">工友之家</a></li>
                    <li><a href="http://www.szhgh.com/Article/gnzs/gongyi/" title="公益行动" target="_blank">公益行动</a></li>
                </ul>
                <div class="clear"></div>
            </li>               
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/wsds/" title="文史·读书" target="_blank">文史读书</a></strong>
                <ul class="specialstyle">
                    <li><a href="http://www.szhgh.com/Article/wsds/wenyi/" title="文艺" target="_blank">文艺</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/culture/" title="文化" target="_blank">文化</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/history/" title="历史" target="_blank">历史</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/read/" title=" 读书" target="_blank"> 读书</a></li>
                    <li><a href="http://www.szhgh.com/Article/wsds/youth/" title="青年" target="_blank">青年</a></li>
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </li>
            <li class="mapli">
                <strong><a href="http://www.szhgh.com/Article/thirdworld/" title="第三世界" target="_blank">第三世界</a></strong>
                <ul>
                    <li><a href="http://www.szhgh.com/Article/thirdworld/korea/" title="朝鲜" target="_blank">朝鲜</a></li>
                    <li><a href="http://www.szhgh.com/Article/thirdworld/cuba/" title="古巴" target="_blank">古巴</a></li>
                    <li><a href="http://www.szhgh.com/Article/thirdworld/latin-america/" title="拉美" target="_blank">拉美</a></li>
                    <li><a href="http://www.szhgh.com/Article/thirdworld/africa/" title="非洲" target="_blank">非洲</a></li>
                </ul>
                <div class="clear"></div>
            </li>                
            <div class="clear"></div>
        </ul>
    </div>
    <div class="copyright">
        <ul>
            <li class='copy_left'>
                <div>
                    <a href="http://www.szhgh.com/" title="红歌会网" target="_blank">红歌会网</a>
                    | <a href="http://www.szhgh.com/html/sitemap.html" title="网站地图" target="_blank">网站地图</a>
                    | <a href="http://www.szhgh.com/html/rank.html" title="排行榜" target="_blank">排行榜</a>
                    | <a href="http://www.szhgh.com/Article/notice/20257.html" title="联系我们" target="_blank">联系我们</a>
                    | <a href="http://www.szhgh.com/Article/opinion/zatan/13968.html" title="在线提意见" target="_blank">在线提意见</a>
                </div>
                <div>
                    <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>
                    | <script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script>

<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F2e62d7088e3926a4639571ba4c25de10' type='text/javascript'%3E%3C/script%3E"));
</script>
                </div>
            </li>
            <li class="focusbutton">
                <a class="rss" href="http://www.szhgh.com/e/web/?type=rss2" title="欢迎订阅红歌会网" target="_blank"></a>
                <a class="sinaweibo" href="http://weibo.com/szhgh?topnav=1&wvr=5&topsug=1" title="欢迎关注红歌会网新浪微博" target="_blank"></a>
                <a class="qqweibo" href="http://follow.v.t.qq.com/index.php?c=follow&amp;a=quick&amp;name=szhgh001&amp;style=5&amp;t=1737191719&amp;f=1" title="欢迎关注红歌会网腾讯微博" target="_blank"></a>
                <a class="qqmsg" href="http://wpa.qq.com/msgrd?Uin=1962727933" title="欢迎通过QQ联系我们" target="_blank"></a>
                <a class="email" href="mailto:szhgh001@163.com" title="欢迎投稿或反映问题" target="_blank"></a>
            </li>
            <li class="focusmsg">
                <div>网站QQ：<a href="http://wpa.qq.com/msgrd?Uin=1962727933" title="欢迎通过QQ联系我们" target="_blank">1962727933</a>&nbsp;&nbsp;红歌会网粉丝QQ群：35758473</div>
                <div>(投稿)邮箱：<a href="mailto:szhgh001@163.com" title="欢迎投稿或反映问题" target="_blank">szhgh001@163.com</a></div>
            </li>
            <div class="clear"></div>
        </ul>
    </div>
</div>

<script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
<div id="loginmodal" class="loginmodal" style="display:none;">
    <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
    <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
        <div class="login left">
            <strong>会员登录</strong>
            <input type=hidden name=enews value=login>
            <input type=hidden name=ecmsfrom value=9>
            <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
            <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
            <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
            <div class="poploginex"><script type="text/javascript">document.write('<script  type="text/javascript" src="http://www.szhgh.com/e/memberconnect/panjs.php?type=login&dclass=login&t='+Math.random()+'"><'+'/script>');</script></div>
            <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
        </div>
        <div class="reg right">
            <div class="regmsg"><span>还不是会员？</span></div>
            <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
        </div>
    </form>
</div>
<script type="text/javascript">
    $(function(){
      $('#loginform').submit(function(e){
        return false;
      });

      $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
      $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
      
      $('#username input').OnFocus({ box: "#username" });
      $('#password input').OnFocus({ box: "#password" });

    });
</script>

            <!-- footer end -->            
    </body>
</html>