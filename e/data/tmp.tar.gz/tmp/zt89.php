<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>纪念人民英雄 怀念共产党人 - 红歌会网</title>
    <meta name="keywords" content="" />
    <meta name="description" content="五千年的华夏文明，中华民族历来英雄辈出。岳飞、文天祥、郑成功等人，都是人们耳熟能详的民族英雄。但自从有了共产党，有了毛泽东思想，“英雄”的涵义便有了全新的诠释。他们不单要砸碎万恶的旧世界，还要建设一个利于绝大多数劳苦大众的新社会，实现共产主义。
这些“英雄”中，既有杨开慧、赵一曼这样的巾帼英雄，也有黄继光、邱少云这样的钢铁战士；既有焦裕禄、张钦礼这样的模范共产党干部，也有雷锋、张思德这样的普通党员。每一个人的英雄事迹都令人震撼，由衷敬佩。
一位因抗日救国而殉难的爱国作家郁达夫说过：一个没有英雄的民族是不幸的，一个有英雄却不知敬重爱惜的民族是不可救药的，有了伟大的人物，而不知拥护，爱戴，崇仰的国家，是没有希望的奴隶之邦。
在这个稀奇古怪的“特色”时代，一股诋毁、抹黑英雄的歪风邪气竟在我泱泱中华到处肆虐。一场正义与邪恶的较量正在共产党的地盘上激烈地进行着。清醒的人们知道，一旦这些英雄们被推倒，亡党亡国便是必然。
为了人民的幸福、民族的解放，成千上万的革命烈士牺牲了，为了社会主义的伟大建设，一批又一批的共产党人倒下了，他们将永垂不朽，而所有中国人都应当铭记恩情，了解他们的事迹。其中包括那些富有正义的抗日国民党将领。因此有了这样的一个专题，虽然目前只有其中的一部分。
同时也以此庆祝建党94周年、建军88周年及抗日战争胜利90周年。" />
    <link rel="shortcut icon" href="http://www.szhgh.com/skin/default/images/favicon.ico" /> 
    <link href="http://www.szhgh.com/skin/default/css/topic-20150627.css" rel="stylesheet" type="text/css" />
    <link href="http://www.szhgh.com/skin/default/css/topic-20150627-1.css" rel="stylesheet" type="text/css" />
    <script src="http://www.szhgh.com/skin/default/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/myfocus-2.0.4.min.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/mF_tbhuabao_fortopic_sessions.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/newsScroll.js" type="text/javascript"></script>
    <script type="text/javascript" src="http://www.szhgh.com/e/data/js/ajax.js"></script>
    <script src="http://www.szhgh.com/skin/default/js/custom.js" type="text/javascript"></script>
    <script src="http://www.szhgh.com/skin/default/js/jquery.flexisel.js" type="text/javascript"></script>
    <!--[if !IE]>|xGv00|ef6f6f4cf55337e8218c7e4915dd8658<![endif]-->
    <script>
        function setTab(name,cursel,n){
            for(i=1;i<=n;i++){
                var menu=document.getElementById(name+i);
                var con=document.getElementById("con_"+name+"_"+i);
                menu.className=i==cursel?"current":"";
                con.style.display=i==cursel?"block":"none";
            }
        }
        function change(id){
            if (typeof(isround)!='undefined') clearTimeout(isround);
            var bigimg = document.getElementById("focus_big").getElementsByTagName("li");	
            var smallimg = document.getElementById("focus_tip").getElementsByTagName("li");
            var text = document.getElementById("focus_text").getElementsByTagName("li");
            for (var i = 0; i < smallimg.length; i++) {
                    bigimg[i].className="undis";
                    smallimg[i].className="";
                    text[i].className="undis";
            }
            bigimg[id-1].className="dis";
            smallimg[id-1].className="current";
            text[id-1].className="dis";
            if ((next=id+1) > smallimg.length) next = 1;
            isround=setTimeout('change('+next+')', 5000);
        }
    </script>
</head>
<?
        $ztid=89;  //取得当前专题id并赋给变量$ztid，以供SQL查询使用；
        $zt_r = $empire->fetch1("select * from {$dbtbpre}enewszt where ztid=" . $ztid);
        
        $special_r = $empire->fetch1("select id,classid from {$dbtbpre}ecms_special where specid=" . $ztid);
?>
<body closepl="<?=$zt_r['closepl']?>">
    <!--头部开始-->
    <div class="header">
        <div class="hea_1 clearfix">
            <div class="pleft">
                <div class="hea_logo pleft"><a href="http://www.szhgh.com/" target="_blank" title="红歌会网首页"><img src="http://www.szhgh.com/skin/default/images/topic_images/logo.jpg" width="163" height="45" /></a></div>
                <ul class="pleft">
                    <li><a href="http://www.szhgh.com/" title="红歌会网首页" target="_blank">红歌会网首页</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://hao.szhgh.com/" title="点此进入红歌会网址导航" target="_blank">&nbsp;&nbsp;网址导航</a>&nbsp;&nbsp;|</li>
                    <li><a href="http://www.szhgh.com/special/" title="专题中心" target="_blank">&nbsp;&nbsp;专题中心 </a>|</li>
                    <li><a href="http://www.szhgh.com/xuezhe/" title="学者专栏" target="_blank">&nbsp;&nbsp;学者专栏 </a></li>
                </ul>                
            </div>
            <div class="account pright">
                <script>
                    document.write('<script src="http://www.szhgh.com/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');
                </script>
            </div>
        </div>
    </div>
    <!--头部结束-->
    
<!--中间开始-->
    
    <!--顶部大banner-->
    <div class="big-banner">
        <div><?=ReturnZtAddField(0,'customintro')?></div>
    </div>
    
    <!-- 人民英雄 -->
    <div class="m-section">
        <div class="class-title">
            <h2><a href="http://www.szhgh.com/s/yingxiong/type62.html" title="人民英雄" target="_blank">人民英雄</a></h2>
            <a href="http://www.szhgh.com/s/yingxiong/type62.html" title="点击查看更多" target="_blank">更多>></a>
        </div>
        <ul class="list-content">
            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=62 and b.ispic=1 order by a.isgood desc,a.newstime desc limit 24",24,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
            <?
                $nopadding = $bqno%3==0?" class='row-last-li'":"";
            ?>
            <li<?=$nopadding?>>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank">
                    <img src="<?=$bqr[titlepic]?>" />
                    <h3><?=$bqr['wztitle']?></h3>
                </a>
                <span class="count" id="diggnum<?=$bqr['id']?>"><script type="text/javascript" src="http://www.szhgh.com/e/public/ViewClick/?classid=<?=$bqr['classid']?>&id=<?=$bqr['id']?>&down=5"></script></span>
                <a class="toflower" href="JavaScript:makeRequest('http://www.szhgh.com/e/public/digg/?classid=<?=$bqr['classid']?>&id=<?=$bqr['id']?>&dotop=1&doajax=1&ajaxarea=diggnum<?=$bqr['id']?>','EchoReturnedText','GET','');"></a>
            </li>
            <?php
}
}
?>
            
        </ul>
    </div>
    
    <!-- 共产党人 -->
    <div class="m-section">
        <div class="class-title">
            <h2><a href="http://www.szhgh.com/s/yingxiong/type63.html" title="共产党人" target="_blank">共产党人</a></h2>
            <a href="http://www.szhgh.com/s/yingxiong/type63.html" title="点击查看更多" target="_blank">更多>></a>
        </div>
        <ul class="list-content">
            <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsIndexLoopBq("select * from {$dbtbpre}enewsztinfo a inner join {$dbtbpre}ecms_article b on a.id=b.id where a.ztid=$ztid and a.cid=63 and b.ispic=1 order by a.isgood desc,a.newstime desc limit 24",24,11,'','','');
if($ecms_bq_sql){
while($indexbqr=$empire->fetch($ecms_bq_sql)){
if(empty($class_r[$indexbqr['classid']]['tbname'])){continue;}
$bqr=$empire->fetch1("select * from {$dbtbpre}ecms_".$class_r[$indexbqr['classid']]['tbname']." where id='$indexbqr[id]'");
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
            <?
                $nopadding = $bqno%3==0?" class='row-last-li'":"";
            ?>
            <li<?=$nopadding?>>
                <a href="<?=$bqsr['titleurl']?>" title="<?=$bqr['title']?>" target="_blank">
                    <img src="<?=$bqr[titlepic]?>" />
                    <h3><?=$bqr['wztitle']?></h3>
                </a>
                <span class="count" id="diggnum<?=$bqr['id']?>"><script type="text/javascript" src="http://www.szhgh.com/e/public/ViewClick/?classid=<?=$bqr['classid']?>&id=<?=$bqr['id']?>&down=5"></script></span>
                <a class="toflower" href="JavaScript:makeRequest('http://www.szhgh.com/e/public/digg/?classid=<?=$bqr['classid']?>&id=<?=$bqr['id']?>&dotop=1&doajax=1&ajaxarea=diggnum<?=$bqr['id']?>','EchoReturnedText','GET','');"></a>
            </li>
            <?php
}
}
?>
        </ul>
    </div>
    
    
    <div class="cont_pl">
        <div id="plpost" class="pl_list">
            <!-- 评论 -->
            <div id="tosaypl" class="pl section">
               <script>
    function CheckPl(obj) {
        if (obj.saytext.value==""){
            alert("您没什么话要说吗？");
            obj.saytext.focus();
            return false;
        }
        return true;
    }
</script>
<div class="section_header_articlecontent">
    <strong>网友评论</strong>
</div>
<script>
    document.write('<script src="http://www.szhgh.com/e/member/iframe/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&t='+Math.random()+'"><'+'/script>');
</script>
<script type="text/javascript">
    $(function(){
        var $closepl = parseInt($("body").attr("closepl"));
        var $havelogin = $("#plpost").attr("havelogin");

            if($closepl===1){
                $("#saytext").hide();
                $("#statebox").show();
                $("#imageField").addClass("dissubmitbutton").attr("disabled","true");
            } else {
                $("#face .facebutton").toggle(
                    function () {
                      $("#face .facebox").show();
                    },
                    function () {
                      $("#face .facebox").hide();
                    }
                );
            }

    });
</script>
            </div>
            <div class="section_content">
                <script src="http://www.szhgh.com/e/pl/more/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>&num=10"></script>
                <center class="readallpl"><a href="http://www.szhgh.com/e/pl/?classid=<?=$special_r[classid]?>&id=<?=$special_r[id]?>" title="点击查看全部评论" target="_blank">点击查看全部评论</a></center>
            </div>
        </div>
    </div>
    
    <!--中间结束-->
    
    <!--底部开始--> 
            <div class="footer"><a href="http://www.szhgh.com/">红歌会网首页</a> |  <a href="http://www.szhgh.com/special">专题中心</a> |  <a href="http://www.szhgh.com/Article/notice/20257.html">联系我们</a> </div>
        <div class="footer1"><font>红歌会网QQ群：35758473&nbsp;&nbsp;&nbsp;投稿邮箱：<a href="mailto:szhgh001@163.com" target="_blank">szhgh001@163.com</a>&nbsp;&nbsp;&nbsp;站长QQ: <a title="官方QQ" href="http://wpa.qq.com/msgrd?Uin=1737191719" target="_blank">1962727933</a>&nbsp;&nbsp;&nbsp; 备案号： <a href="http://www.miitbeian.gov.cn" target="_blank">粤ICP备12077717号-1</a>&nbsp;&nbsp;&nbsp;<script src="http://s20.cnzz.com/stat.php?id=3051861&web_id=3051861&show=pic1" language="JavaScript"></script></font></div>
    <!--底部结束-->
    
    <!--底部结束-->
    <script src="http://www.szhgh.com/skin/default/js/jquery.leanModal.min.js" type="text/javascript"></script>
    <div id="loginmodal" class="loginmodal" style="display:none;">
        <div class="modaletools"><a class="hidemodal" title="点此关闭">×</a></div>
        <form class="clearfix" name=login method=post action="http://www.szhgh.com/e/member/doaction.php">
            <div class="login pleft">
                <strong>会员登录</strong>
                <input type=hidden name=enews value=login />
                <input type=hidden name=ecmsfrom value=9 />
                <div id="username" class="txtfield username"><input name="username" type="text" size="16" /></div>
                <div id="password" class="txtfield password"><input name="password" type="password" size="16" /></div>
                <div class="forgetmsg"><a href="/e/member/GetPassword/" title="点此取回密码" target="_blank">忘记密码？</a></div>
                <input type="submit" name="Submit" value="登陆" class="inputSub flatbtn-blu" />
            </div>
            <div class="reg pright">
                <div class="regmsg"><span>还不是会员？</span></div>
                <input type="button" name="Submit2" value="立即注册" class="regbutton" onclick="window.open('http://www.szhgh.com/e/member/register/');" />
            </div>
        </form>
    </div>
    
    <script type="text/javascript" src="http://www.szhgh.com/skin/default/js/jquery.scrollLoading.js"></script>
    
    <script type="text/javascript">
        $(function(){
          $('#loginform').submit(function(e){
            return false;
          });

          $('#modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
          $('#modaltrigger_plinput').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });

          $('#username input').OnFocus({ box: "#username" });
          $('#password input').OnFocus({ box: "#password" });
          
          $(".scrollLoading").scrollLoading();	
        });
    </script>
    <!--底部结束-->

    <script src=http://www.szhgh.com/e/public/onclick/?enews=dozt&ztid=89></script>

</body>
</html>